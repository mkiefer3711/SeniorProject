﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace SeniorProjectGUI
{
    // Form 3 allows you to schedule new appointments
    public partial class Form3 : Form
    {

        // Defining a list of allowed room numbers
        private readonly List<string> allowedRoomNumbers = new List<string> {
            "Exam Room 1", "Exam Room 2", "Exam Room 3", "Surgery Room 1", "Surgery Room 2"
        };

        public Form3()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // Go back to form 1 when button is clicked
            Form1 form1 = new Form1();
            form1.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            // Retrieve values from text boxes
            DateTime appointmentDateTime = dateTimePicker1.Value.Date + dateTimePicker2.Value.TimeOfDay;
            string customerName = textCustomerName.Text;
            string petName = textPetName.Text;
            string doctor = textDoctor.Text;
            string room = textRoomNumber.Text;
            string reason = textReasonForAppointment.Text;
            string appointmentLengthInput = textAppointmentLength.Text;

            // Validate appointment date and time
            if (!IsValidAppointmentDateTime(appointmentDateTime))
            {
                MessageBox.Show("Please enter an appointment date and time between 9 AM and 6 PM, Monday to Friday.", "Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return; // Exit the method
            }

            // Validate appointment length input
            if (!IsValidAppointmentLength(appointmentLengthInput))
            {
                // Handle invalid input
                MessageBox.Show("Please enter a valid appointment length that is in 15-minute intervals.", "Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return; // Exit the method
            }

            // Convert the appointment length input to an integer (validated during parsing)
            int appointmentLengthMinutes = int.Parse(appointmentLengthInput);

            // Validate customer name input
            if (!IsValidCustomerName(customerName))
            {
                // Handle invalid input
                MessageBox.Show("Please enter a valid first name in the format 'firstName lastName'.", "Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return; // Exit the method
            }

            if (!IsAllLetters(petName))
            {
                // Handle invalid input
                MessageBox.Show("Please enter a pet name that is only letters", "Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return; // Exit the method
            }

            if (!IsValidDoctorName(doctor))
            {
                MessageBox.Show("Please enter a Doctor's name that starts with 'Dr.' followed by letters only.", "Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return; // Exit the method
            }

            if (!IsRoomNumberValid(room))
            {
                MessageBox.Show("Please enter the correct room, either 'Exam Room 1-3' or 'Surgery Room 1-2'.", "Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return; // Exit the method
            }

            if (!IsValidReason(reason))
            {
                // Handle invalid input
                MessageBox.Show("Please enter a reason that is only letters and spaces.", "Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return; // Exit the method
            }

            if (!IsAppointmentLengthValid(appointmentLengthMinutes))
            {
                // Handle invalid input
                MessageBox.Show("Please enter an appointment length that is in 15 minute intervals.", "Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return; // Exit the method
            }

            // Get CustomerID and PetID based on customer name and pet name
            int customerId = GetCustomerId(customerName);
            int petId = GetPetId(petName);

            // Insert appointment information into the 'Appointment' table
            InsertAppointment(customerId, petId, appointmentDateTime, customerName, petName, doctor, room, reason, appointmentLengthMinutes);

            // Show success message
            MessageBox.Show("Appointment scheduled successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);

            // Clear all text boxes
            ClearTextBoxes();
        }

        private bool IsValidAppointmentDateTime(DateTime appointmentDateTime)
        {
            // Check if appointment is on a Saturday or Sunday
            if (appointmentDateTime.DayOfWeek == DayOfWeek.Saturday || appointmentDateTime.DayOfWeek == DayOfWeek.Sunday)
            {
                return false;
            }

            // Check if appointment time is before 9 AM or after 6 PM
            TimeSpan earliestTime = TimeSpan.FromHours(9);
            TimeSpan latestTime = TimeSpan.FromHours(18);
            TimeSpan appointmentTime = appointmentDateTime.TimeOfDay;
            return appointmentTime >= earliestTime && appointmentTime <= latestTime;
        }

        private bool IsValidCustomerName(string customerName)
        {
            // Regular expression pattern for validating customer name format: 'First Name Last Name'
            string pattern = @"^[a-zA-Z]+\s[a-zA-Z]+$";
            return Regex.IsMatch(customerName, pattern);
        }

        // Checks that the input is only letters
        private bool IsAllLetters(string input)
        {
            return input.All(char.IsLetter);
        }

        private bool IsValidDoctorName(string doctorName)
        {
            // Regular expression pattern to match 'Dr.' followed by letters only
            string pattern = @"^Dr\.\s[a-zA-Z]+$";
            return Regex.IsMatch(doctorName, pattern);
        }

        private bool IsRoomNumberValid(string roomNumber)
        {
            // Convert the input room number to lowercase
            string roomNumberLower = roomNumber.ToLower();

            // Convert all allowed room numbers to lowercase
            List<string> allowedRoomNumbersLower = allowedRoomNumbers.ConvertAll(r => r.ToLower());

            // Check if the lowercase input room number is in the list of lowercase allowed room numbers
            return allowedRoomNumbersLower.Contains(roomNumberLower);
        }

        private bool IsValidReason(string reason)
        {
            // Check if the reason contains only letters and spaces
            foreach (char c in reason)
            {
                if (!char.IsLetter(c) && c != ' ')
                {
                    return false;
                }
            }
            return true;
        }

        private bool IsValidAppointmentLength(string lengthInput)
        {
            int length;
            // Try to parse the length input to an integer
            if (int.TryParse(lengthInput, out length))
            {
                // If parsing succeeds, check if the length is valid
                return IsAppointmentLengthValid(length);
            }
            // If parsing fails, return false
            return false;
        }

        private bool IsAppointmentLengthValid(int length)
        {
            // Check if the length is a multiple of 15 and greater than or equal to 15
            return length >= 15 && length % 15 == 0;
        }

        // Method to clear all text boxes on the form
        private void ClearTextBoxes()
        {
            foreach (Control control in Controls)
            {
                if (control is System.Windows.Forms.TextBox)
                {
                    ((System.Windows.Forms.TextBox)control).Clear();
                }
            }
        }

        public int GetCustomerId(string customerName)
        {
            int customerId = -1; // Initialize with a default value indicating failure

            // Establish connection to your database
            string constring = @"Data Source = MADDISON-PC; Integrated Security = True; Connect Timeout = 30;User Id=MADDISON-PC\Maddison; ";
            using (SqlConnection con = new SqlConnection(constring))
            {
                // Define SQL query to retrieve CustomerID based on customer name
                string query = "SELECT CustomerID FROM Customer.dbo.Customer WHERE FirstName + ' ' + LastName = @CustomerName;";

                // Open connection
                con.Open();

                // Create command object
                using (SqlCommand command = new SqlCommand(query, con))
                {
                    // Add parameter
                    command.Parameters.AddWithValue("@CustomerName", customerName);

                    // Execute the query and get the result
                    object result = command.ExecuteScalar();
                    if (result != null) // Check if the result is not null
                    {
                        customerId = Convert.ToInt32(result); // Convert the result to an integer
                    }
                }
            }

            return customerId;
        }

        public int GetPetId(string petName)
        {
            int petId = -1; // Initialize with a default value indicating failure

            // Establish connection to your database
            string constring = @"Data Source = MADDISON-PC; Integrated Security = True; Connect Timeout = 30;User Id=MADDISON-PC\Maddison; ";
            using (SqlConnection con = new SqlConnection(constring))
            {
                // Define SQL query to retrieve PetID based on pet name
                string query = "SELECT PetID FROM Customer.dbo.Pet WHERE PetName = @PetName;";

                // Open connection
                con.Open();

                // Create command object
                using (SqlCommand command = new SqlCommand(query, con))
                {
                    // Add parameter
                    command.Parameters.AddWithValue("@PetName", petName);

                    // Execute the query and get the result
                    object result = command.ExecuteScalar();
                    if (result != null) // Check if the result is not null
                    {
                        petId = Convert.ToInt32(result); // Convert the result to an integer
                    }
                }
            }

            return petId;
        }

        public void InsertAppointment(int customerId, int petId, DateTime appointmentDateTime, string customerName, string petName, string doctor, string room, string reason, int appointmentLengthMinutes)
        {
            // Validate Date Time input
            if (!IsValidAppointmentDateTime(appointmentDateTime))
            {
                throw new ArgumentException("Appointment date and time should be between 9 AM and 6 PM, Monday to Friday.", nameof(customerName));
            }

            // Validate customer name input
            if (!IsValidCustomerName(customerName))
            {
                throw new ArgumentException("Customer name must only contain letters and be formatted as 'firstName lastName'.", nameof(customerName));
            }

            // Validate pet name input
            if (!IsAllLetters(petName))
            {
                throw new ArgumentException("Pet name must only contain letters.", nameof(petName));
            }

            // Validate doctor name input
            if (!IsValidDoctorName(doctor))
            {
                throw new ArgumentException("Doctor's name must start with 'Dr.' followed by letters only.", nameof(doctor));
            }

            // Validate room number input
            if (!IsRoomNumberValid(room))
            {
                throw new ArgumentException("Invalid room number. Allowed room numbers are 'Exam Room 1', 'Exam Room 2', 'Exam Room 3', 'Surgery Room 1', and 'Surgery Room 2'.", nameof(room));
            }

            // Validate appointment reason input
            if (!IsValidReason(reason))
            {
                throw new ArgumentException("The reason must only contain letters.", nameof(reason));
            }

            // Validate appointment length input
            if (!IsAppointmentLengthValid(appointmentLengthMinutes))
            {
                throw new ArgumentException("The appointment lenght must be in 15 minute intervals", nameof(appointmentLengthMinutes));
            }

            // Establish connection to your database
            string constring = @"Data Source = MADDISON-PC; Integrated Security = True; Connect Timeout = 30;User Id=MADDISON-PC\Maddison; ";
            using (SqlConnection con = new SqlConnection(constring))
            {
                // Define SQL query to insert appointment information
                string query = "INSERT INTO Customer.dbo.Appointment (CustomerID, PetID, AppointmentDateTime, CustomerName, PetName, Doctor, Room, Reason, AppointmentLengthMinutes) VALUES (@CustomerId, @PetId, @AppointmentDateTime, @CustomerName, @PetName, @Doctor, @Room, @Reason, @AppointmentLengthMinutes);";

                // Open connection
                con.Open();

                // Create command object
                using (SqlCommand command = new SqlCommand(query, con))
                {
                    // Add parameters
                    command.Parameters.AddWithValue("@CustomerId", customerId);
                    command.Parameters.AddWithValue("@PetId", petId);
                    command.Parameters.AddWithValue("@AppointmentDateTime", appointmentDateTime);
                    command.Parameters.AddWithValue("@CustomerName", customerName);
                    command.Parameters.AddWithValue("@PetName", petName);
                    command.Parameters.AddWithValue("@Doctor", doctor);
                    command.Parameters.AddWithValue("@Room", room);
                    command.Parameters.AddWithValue("@Reason", reason);
                    command.Parameters.AddWithValue("@AppointmentLengthMinutes", appointmentLengthMinutes);

                    // Execute query
                    command.ExecuteNonQuery();
                }
            }
        }
    }
}
