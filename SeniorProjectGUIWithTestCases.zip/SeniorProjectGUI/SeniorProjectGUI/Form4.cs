﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SeniorProjectGUI
{
    // Form 4 displays all of the information for a customer or pet when you search for them 
    public partial class Form4 : Form
    {
        private string searchQuery;

        // Declare DataGridView properties
        public DataGridView CustomerDataGridView { get; set; }
        public DataGridView PetDataGridView { get; set; }

        public Form4(DataTable customerResults, DataTable petResults, string searchQuery)
        {
            InitializeComponent();

            // Initialize DataGridView controls
            CustomerDataGridView = new DataGridView();
            PetDataGridView = new DataGridView();

            // Populate the DataGridViews with the search results
            PopulateCustomerDataGridView(customerResults);
            PopulatePetDataGridView(petResults, customerResults);
            this.searchQuery = searchQuery;
        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            // Go back to form 1 when button is clicked
            Form1 form1 = new Form1();
            form1.Show();
            this.Hide();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        public void PopulateCustomerDataGridView(DataTable customerDataTable)
        {
            // Bind the DataTable to the DataGridView for customers
            DataView dv = customerDataTable.DefaultView;
            dv.RowFilter = $"FirstName LIKE '%{searchQuery}%' OR LastName LIKE '%{searchQuery}%'";
            customerDataGrid.DataSource = dv.ToTable();
        }

        public void PopulatePetDataGridView(DataTable petDataTable, DataTable customerDataTable)
        {
            // Get the CustomerID from the customer search results
            int customerId = 0; // Initialize to a default value
            if (customerDataTable.Rows.Count > 0)
            {
                customerId = Convert.ToInt32(customerDataTable.Rows[0]["CustomerID"]);
            }

            // Construct the pet query with a parameter for CustomerID
            string petQuery = "SELECT PetName, Species, Breed, Gender, Age, SpayedNeutered FROM Customer.dbo.Pet WHERE CustomerID = @CustomerId";

            // Create a DataTable to store the filtered pet results
            DataTable filteredPetDataTable = new DataTable();

            // Establish connection to your database
            string constring = @"Data Source = MADDISON-PC; Integrated Security = True; Connect Timeout = 30;User Id=MADDISON-PC\Maddison; ";
            using (SqlConnection con = new SqlConnection(constring))
            {
                // Open connection
                con.Open();

                // Create command object
                using (SqlCommand command = new SqlCommand(petQuery, con))
                {
                    // Add parameter
                    command.Parameters.AddWithValue("@CustomerId", customerId);

                    // Fill the DataTable with the results of the SQL query
                    using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                    {
                        adapter.Fill(filteredPetDataTable);
                    }
                }
            }

            // Bind the DataTable to the DataGridView for pets
            petDataGrid.DataSource = filteredPetDataTable;
        }
    }
}
