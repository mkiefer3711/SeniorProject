﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Runtime.InteropServices.JavaScript.JSType;


namespace SeniorProjectGUI
{
    // Form 2 allows you to add a new client to the database
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private bool IsAllLetters(string input)
        {
            return input.All(char.IsLetter);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            // Retrieve values from text boxes
            string firstName = textFirstName.Text;
            string lastName = textLastName.Text;
            string email = textEmail.Text;
            string phoneNumber = textPhoneNumber.Text;
           
            // Validate last name input
            if (!IsAllLetters(firstName))
            {
                // Handle invalid input
                MessageBox.Show("Please enter a first name containing only letters.", "Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return; // Exit the method
            }

            // Validate last name input
            if (!IsAllLetters(lastName))
            {
                // Handle invalid input
                MessageBox.Show("Please enter a last name containing only letters.", "Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return; // Exit the method
            }

            // Validate email input
            if (!IsValidEmail(email))
            {
                // Handle invalid input
                MessageBox.Show("Please enter a valid email address.", "Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return; // Exit the method
            }

            // Validate phone number input
            if (!IsValidPhoneNumber(phoneNumber))
            {
                // Handle invalid input
                MessageBox.Show("Please enter a valid phone number in the format XXX-XXX-XXXX.", "Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return; // Exit the method
            }

            // Insert client information into the 'customers' table
            int customerID;
            try
            {
                customerID = InsertCustomer(firstName, lastName, email, phoneNumber);
            }
            catch (ArgumentException ex)
            {
                // Handle invalid input
                MessageBox.Show(ex.Message, "Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return; // Exit the method
            }

            // If customerID is greater than 0, it means the insertion was successful
            if (customerID > 0)
            {
                // Retrieve values for pet information
                string petName = textPetName.Text;
                string petSpecies = textPetSpecies.Text;
                string petBreed = textPetBreed.Text;
                string petGender = textPetGender.Text;
                string petAgeInput = textPetAge.Text;

                // Validate pet age input
                if (!IsValidPetAge(petAgeInput))
                {
                    // Handle invalid input
                    MessageBox.Show("Please enter a valid pet age as a non-negative integer.", "Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return; // Exit the method
                }

                // Convert the pet age input to an integer (validated during parsing)
                int petAge = int.Parse(petAgeInput);

                string petSpayedNeutered = textSpayedNeutered.Text;

                // Validate pet name input
                if (!IsAllLetters(petName))
                {
                    // Handle invalid input
                    MessageBox.Show("Please enter a pet name containing only letters.", "Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return; // Exit the method
                }

                // Validate pet species input
                if (!IsAllLetters(petSpecies))
                {
                    // Handle invalid input
                    MessageBox.Show("Please enter a pet species containing only letters.", "Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return; // Exit the method
                }

                // Validate pet species input
                if (!IsAllLetters(petBreed))
                {
                    // Handle invalid input
                    MessageBox.Show("Please enter a pet breed containing only letters.", "Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return; // Exit the method
                }

                // Validate pet gender input
                if (!IsValidPetGender(petGender))
                {
                    // Handle invalid input
                    MessageBox.Show("Please enter 'Male' or 'Female' for pet gender.", "Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return; // Exit the method
                }

                // Validate pet spayed or neutered input
                if (!IsValidPetSpayedNeutered(petSpayedNeutered))
                {
                    // Handle invalid input
                    MessageBox.Show("Please enter 'Spayed', 'Neutered', or 'No' for pet spayed or neutered.", "Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return; // Exit the method
                }

                // Insert pet information into the 'pets' table, associating it with the customer
                InsertPet(customerID, petName, petSpecies, petBreed, petGender, petAge, petSpayedNeutered);

                // Show success message
                MessageBox.Show("Client added successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);

                // Clear all text boxes
                ClearTextBoxes();
            }
            else
            {
                // Show error message if customerID is not greater than 0
                MessageBox.Show("Failed to add client.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private bool IsValidEmail(string email)
        {
            // Regular expression pattern for validating email format
            string pattern = @"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$";
            return Regex.IsMatch(email, pattern);
        }

        private bool IsValidPhoneNumber(string phoneNumber)
        {
            // Regular expression pattern for validating phone number format XXX-XXX-XXXX
            string pattern = @"^\d{3}-\d{3}-\d{4}$";
            return Regex.IsMatch(phoneNumber, pattern);
        }

        private bool IsValidPetGender(string gender)
        {
            // Allow only "Male" or "Female" as valid input
            return gender.Equals("Male", StringComparison.OrdinalIgnoreCase) ||
                   gender.Equals("Female", StringComparison.OrdinalIgnoreCase);
        }

        private bool IsValidPetSpayedNeutered(string spayedNeutered)
        {
            // Allow only "Spayed", "Neutered" or "No" as valid inputs
            return spayedNeutered.Equals("Spayed", StringComparison.OrdinalIgnoreCase) ||
                   spayedNeutered.Equals("Neutered", StringComparison.OrdinalIgnoreCase) ||
                   spayedNeutered.Equals("No", StringComparison.OrdinalIgnoreCase);
        }

        private bool IsValidPetAge(string ageInput)
        {
            int age;
            // Try to parse the age input to an integer
            if (int.TryParse(ageInput, out age))
            {
                // If parsing succeeds, ensure the age is non-negative
                return age >= 0;
            }
            // If parsing fails, return false
            return false;
        }

        // Method to clear all text boxes on the form
        private void ClearTextBoxes()
        {
            foreach (Control control in Controls)
            {
                if (control is TextBox)
                {
                    ((TextBox)control).Clear();
                }
            }
        }

        public int InsertCustomer(string firstName, string lastName, string email, string phoneNumber)
        {
            // Validate first name input
            if (!IsAllLetters(firstName))
            {
                throw new ArgumentException("First name must contain only letters.", nameof(firstName));
            }

            // Validate last name input
            if (!IsAllLetters(lastName))
            {
                throw new ArgumentException("Last name must contain only letters.", nameof(lastName));
            }

            // Validate email input
            if (!IsValidEmail(email))
            {
                throw new ArgumentException("Email must contain '@' symbol and '.something' at the end.", nameof(email));
            }

            // Validate phone number input
            if (!IsValidPhoneNumber(phoneNumber))
            {
                throw new ArgumentException("Phone number must be in the format of XXX-XXX-XXXX", nameof(phoneNumber));
            }

            // Establish connection to the database
            string constring = @"Data Source = MADDISON-PC; Integrated Security = True; Connect Timeout = 30;User Id=MADDISON-PC\Maddison; ";
            using (SqlConnection con = new SqlConnection(constring))
            {
                // Define SQL query to insert customer information
                string query = "INSERT INTO Customer.dbo.Customer (FirstName, LastName, Email, PhoneNumber) VALUES (@FirstName, @LastName, @Email, @PhoneNumber); SELECT SCOPE_IDENTITY();";

                // Open connection
                con.Open();

                // Create command object
                using (SqlCommand command = new SqlCommand(query, con))
                {
                    // Add parameters
                    command.Parameters.AddWithValue("@FirstName", firstName);
                    command.Parameters.AddWithValue("@LastName", lastName);
                    command.Parameters.AddWithValue("@Email", email);
                    command.Parameters.AddWithValue("@PhoneNumber", phoneNumber);

                    // Execute query and get the generated customer ID
                    int CustomerID = Convert.ToInt32(command.ExecuteScalar());
                    return CustomerID;
                }
            }
        }

        public void InsertPet(int customerId, string petName, string petSpecies, string petBreed, string petGender, int petAge, string petSpayedNeutered)
        {
            // Validate pet name input
            if (!IsAllLetters(petName))
            {
                throw new ArgumentException("Pet name must contain only letters.", nameof(petName));
            }

            // Validate pet species input
            if (!IsAllLetters(petSpecies))
            {
                throw new ArgumentException("Pet species must contain only letters.", nameof(petSpecies));
            }

            // Validate pet breed input
            if (!IsAllLetters(petBreed))
            {
                throw new ArgumentException("Pet breed must contain only letters.", nameof(petBreed));
            }

            // Validate pet gender input
            if (!IsValidPetGender(petGender))
            {
                throw new ArgumentException("Pet gender must be 'Male' or 'Female'.", nameof(petGender));
            }

            // Validate pet age input
            if (petAge <= 0)
            {
                throw new ArgumentException("Pet age must be a positive integer.", nameof(petAge));
            }

            // Validate pet gender input
            if (!IsValidPetSpayedNeutered(petSpayedNeutered))
            {
                throw new ArgumentException("Pet spayed or neutered must be 'Spayed', 'Neutered', or 'No'.", nameof(petSpayedNeutered));
            }

            // Establish connection to the database
            string constring = @"Data Source = MADDISON-PC; Integrated Security = True; Connect Timeout = 30;User Id=MADDISON-PC\Maddison; ";
            using (SqlConnection connection = new SqlConnection(constring))
            {
                // Define SQL query to insert pet information
                string query = "INSERT INTO Customer.dbo.Pet (CustomerID, PetName, Species, Breed, Gender, Age, SpayedNeutered) VALUES (@CustomerId, @PetName, @PetSpecies, @PetBreed, @PetGender, @PetAge, @PetSpayedNeutered);";

                // Open connection
                connection.Open();

                // Create command object
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    // Add parameters
                    command.Parameters.AddWithValue("@CustomerId", customerId);
                    command.Parameters.AddWithValue("@PetName", petName);
                    command.Parameters.AddWithValue("@PetSpecies", petSpecies);
                    command.Parameters.AddWithValue("@PetBreed", petBreed);
                    command.Parameters.AddWithValue("@PetGender", petGender);
                    command.Parameters.AddWithValue("@PetAge", petAge);
                    command.Parameters.AddWithValue("@PetSpayedNeutered", petSpayedNeutered);

                    // Execute query
                    command.ExecuteNonQuery();
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // Go back to form 1 when button is clicked
            Form1 form1 = new Form1();
            form1.Show();
            this.Hide();
        }
    }
}