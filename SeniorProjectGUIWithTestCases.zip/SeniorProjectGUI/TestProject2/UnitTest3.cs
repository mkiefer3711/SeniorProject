﻿using SeniorProjectGUI;

namespace TestProject
{
    [TestClass]

    // Tests for Form3 (Schedule Appointment)
    public class UnitTest3
    {
        [TestMethod]
        // Testing that GetCustomerId method returns a customer ID for an existing customer
        public void GetCustomerId_ExistingCustomer_ReturnsCustomerId()
        {
            // Arrange
            Form3 form3 = new Form3();
            string existingCustomerName = "John Doe";

            // Act
            int customerId = form3.GetCustomerId(existingCustomerName);

            // Assert
            Assert.IsTrue(customerId > 0);
        }

        [TestMethod]
        // Testing that GetCustomerId method returns negative one for customer that does not exist
        public void GetCustomerId_NonExistingCustomer_ReturnsNegativeOne()
        {
            // Arrange
            Form3 form3 = new Form3();
            string nonExistingCustomerName = "Non Existing Customer";

            // Act
            int customerId = form3.GetCustomerId(nonExistingCustomerName);

            // Assert
            Assert.AreEqual(-1, customerId);
        }

        [TestMethod]
        // Testing that GetPetId method returns a pet ID for an existing pet
        public void GetPetId_ExistingPet_ReturnsPetId()
        {
            // Arrange
            Form3 form3 = new Form3();
            string existingPetName = "Buddy";

            // Act
            int petId = form3.GetPetId(existingPetName);

            // Assert
            Assert.IsTrue(petId > 0);
        }

        [TestMethod]
        // Testing that GetPetId method returns negative one for customer that does not exist
        public void GetPetId_NonExistingPet_ReturnsNegativeOne()
        {
            // Arrange
            Form3 form3 = new Form3();
            string nonExistingPetName = "Non Existing Pet";

            // Act
            int petId = form3.GetPetId(nonExistingPetName);

            // Assert
            Assert.AreEqual(-1, petId);
        }

        [TestMethod]
        // Testing InsertAppointment method with valid inputs
        public void InsertAppointment_ValidInput_ReturnsSuccessful()
        {
            // Arrange
            Form3 form3 = new Form3();
            int customerId = 20; // Existing customer ID
            int petId = 26; // Existing pet ID
            DateTime appointmentDateTime = new DateTime(2024, 2, 20, 10, 0, 0);
            string customerName = "John Doe";
            string petName = "Buddy";
            string doctor = "Dr. Smith";
            string room = "Exam Room 2";
            string reason = "Annual Exam";
            int appointmentLengthMinutes = 30;

            // Act & Assert
            try
            {
                form3.InsertAppointment(customerId, petId, appointmentDateTime, customerName, petName, doctor, room, reason, appointmentLengthMinutes);
            }
            catch (Exception)
            {
                Assert.Fail("Inserting appointment should not throw an exception.");
            }
        }

        [TestMethod]
        // Specify the expected exception type
        [ExpectedException(typeof(ArgumentException))]
        // Testing InsertAppointment method with invalid date time input
        public void InsertAppointment_InvalidInputDateTime_ReturnsSuccessful()
        {
            // Arrange
            Form3 form3 = new Form3();
            int customerId = 20; // Existing customer ID
            int petId = 26; // Existing pet ID
            // Invalid date time input
            DateTime appointmentDateTime = new DateTime(2024, 2, 24, 7, 0, 0);
            string customerName = "John Doe";
            string petName = "Buddy";
            string doctor = "Dr. Smith";
            string room = "Exam Room 2";
            string reason = "Annual Exam";
            int appointmentLengthMinutes = 30;

            form3.InsertAppointment(customerId, petId, appointmentDateTime, customerName, petName, doctor, room, reason, appointmentLengthMinutes);
        }

        [TestMethod]
        // Specify the expected exception type
        [ExpectedException(typeof(ArgumentException))]
        // Testing InsertAppointment method with invalid customer name input
        public void InsertAppointment_InvalidCustomerName_ThrowsException()
        {
            // Arrange
            Form3 form3 = new Form3();
            int customerId = 20; // Existing customer ID
            int petId = 26; // Existing pet ID
            DateTime appointmentDateTime = new DateTime(2024, 2, 20, 10, 0, 0);
            // Invalid customer name input
            string customerName = "John";
            string petName = "Buddy";
            string doctor = "Dr. Smith";
            string room = "Exam Room 2";
            string reason = "Annual Exam";
            int appointmentLengthMinutes = 30;

            // Act
            form3.InsertAppointment(customerId, petId, appointmentDateTime, customerName, petName, doctor, room, reason, appointmentLengthMinutes);
        }

        [TestMethod]
        // Specify the expected exception type
        [ExpectedException(typeof(ArgumentException))]
        // Testing InsertAppointment method with invalid pet name input
        public void InsertAppointment_InvalidPetName_ThrowsException()
        {
            // Arrange
            Form3 form3 = new Form3();
            int customerId = 20; // Existing customer ID
            int petId = 26; // Existing pet ID
            DateTime appointmentDateTime = new DateTime(2024, 2, 20, 10, 0, 0);
            string customerName = "John Doe";
            // Invalid pet name input
            string petName = "B523&^gs";
            string doctor = "Dr. Smith";
            string room = "Exam Room 2";
            string reason = "Annual Exam";
            int appointmentLengthMinutes = 30;

            // Act
            form3.InsertAppointment(customerId, petId, appointmentDateTime, customerName, petName, doctor, room, reason, appointmentLengthMinutes);
        }

        [TestMethod]
        // Specify the expected exception type
        [ExpectedException(typeof(ArgumentException))]
        // Testing InsertAppointment method with invalid doctor name input
        public void InsertAppointment_InvalidDoctor_ThrowsException()
        {
            // Arrange
            Form3 form3 = new Form3();
            int customerId = 20; // Existing customer ID
            int petId = 26; // Existing pet ID
            DateTime appointmentDateTime = new DateTime(2024, 2, 20, 10, 0, 0);
            string customerName = "John Doe";
            string petName = "Buddy";
            // Invalid doctor name input
            string doctor = "Mr. Smith$2@";
            string room = "Exam Room 2";
            string reason = "Annual Exam";
            int appointmentLengthMinutes = 30;

            // Act
            form3.InsertAppointment(customerId, petId, appointmentDateTime, customerName, petName, doctor, room, reason, appointmentLengthMinutes);
        }

        [TestMethod]
        // Specify the expected exception type
        [ExpectedException(typeof(ArgumentException))]
        // Testing InsertAppointment method with invalid room number input
        public void InsertAppointment_InvalidRoomNumber_ThrowsException()
        {
            // Arrange
            Form3 form3 = new Form3();
            int customerId = 20; // Existing customer ID
            int petId = 26; // Existing pet ID
            DateTime appointmentDateTime = new DateTime(2024, 2, 20, 10, 0, 0);
            string customerName = "John Doe";
            string petName = "Buddy";
            string doctor = "Dr. Smith";
            // Invalid room number input
            string room = "Room 2";
            string reason = "Annual Exam";
            int appointmentLengthMinutes = 30;

            // Act
            form3.InsertAppointment(customerId, petId, appointmentDateTime, customerName, petName, doctor, room, reason, appointmentLengthMinutes);
        }

        [TestMethod]
        // Specify the expected exception type
        [ExpectedException(typeof(ArgumentException))]
        // Testing InsertAppointment method with invalid appointment reason input
        public void InsertAppointment_InvalidAppointmentReason_ThrowsException()
        {
            // Arrange
            Form3 form3 = new Form3();
            int customerId = 20; // Existing customer ID
            int petId = 26; // Existing pet ID
            DateTime appointmentDateTime = DateTime.Now;
            string customerName = "John Doe";
            string petName = "Buddy";
            string doctor = "Dr. Smith";
            string room = "Room 2";
            // Invalid appointment reason input
            string reason = "$%6782fhrj";
            int appointmentLengthMinutes = 30;

            // Act
            form3.InsertAppointment(customerId, petId, appointmentDateTime, customerName, petName, doctor, room, reason, appointmentLengthMinutes);
        }

        [TestMethod]
        // Specify the expected exception type
        [ExpectedException(typeof(ArgumentException))]
        // Testing InsertAppointment method with invalid appointment length time input
        public void InsertAppointment_InvalidAppointmentLengthTime_ThrowsException()
        {
            // Arrange
            Form3 form3 = new Form3();
            int customerId = 20; // Existing customer ID
            int petId = 26; // Existing pet ID
            DateTime appointmentDateTime = new DateTime(2024, 2, 20, 10, 0, 0);
            string customerName = "John Doe";
            string petName = "Buddy";
            string doctor = "Dr. Smith";
            string room = "Room 2";
            string reason = "Annual Exam";
            // Invalid appointment length time input
            int appointmentLengthMinutes = 27;

            // Act
            form3.InsertAppointment(customerId, petId, appointmentDateTime, customerName, petName, doctor, room, reason, appointmentLengthMinutes);
        }
    }
}
