﻿using SeniorProjectGUI;
using System.Data;

namespace TestProject
{
    [TestClass]

    // Tests for Form1 and Form4 (Searching Clients)
    public class UnitTest1
    {
        [TestMethod]
        public void PerformSearch_WithValidFirstName_ReturnsResults()
        {
            // Arrange
            Form1 form1 = new Form1();
            form1.searchBar.Text = "John"; // Valid first name
            DataTable customerResults = GetMockCustomerDataTable();
            DataTable petResults = new DataTable();

            // Act
            form1.PerformSearch();

            // Assert
            Assert.IsTrue(customerResults.Rows.Count > 0 || petResults.Rows.Count > 0);
        }

        [TestMethod]
        public void PerformSearch_WithValidLastName_ReturnsResults()
        {
            // Arrange
            Form1 form1 = new Form1();
            form1.searchBar.Text = "Doe"; // Valid last name
            DataTable customerResults = GetMockCustomerDataTable();
            DataTable petResults = new DataTable();

            // Act
            form1.PerformSearch();

            // Assert
            Assert.IsTrue(customerResults.Rows.Count > 0 || petResults.Rows.Count > 0);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void PerformSearch_WithInvalidInput_ThrowsException()
        {
            // Arrange
            Form1 form1 = new Form1();
            form1.searchBar.Text = "John Doe"; // Invalid input (combination of first and last name)
            DataTable customerResults = GetMockCustomerDataTable();
            DataTable petResults = new DataTable();

            // Act
            form1.PerformSearch();
        }

        // Helper method to create a mock DataTable for customers
        private DataTable GetMockCustomerDataTable()
        {
            DataTable dataTable = new DataTable();
            dataTable.Columns.Add("FirstName", typeof(string));
            dataTable.Columns.Add("LastName", typeof(string));
            // Add mock customer data
            dataTable.Rows.Add("John", "Doe");
            return dataTable;
        }
    }
}
