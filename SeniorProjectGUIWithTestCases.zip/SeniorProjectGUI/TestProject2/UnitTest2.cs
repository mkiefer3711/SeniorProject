using SeniorProjectGUI;

namespace TestProject
{
    [TestClass]

    // Tests for Form2 (Adding Client)
    public class UnitTest2
    {
        [TestMethod]
        // Testing InsertCustomer method with correct inputs
        public void InsertCustomer_ValidInput_ReturnsValidCustomerId()
        {
            // Arrange
            Form2 form2 = new Form2();
            string firstName = "John";
            string lastName = "Doe";
            string email = "john.doe@example.com";
            string phoneNumber = "123-456-7890";

            // Act
            int customerId = form2.InsertCustomer(firstName, lastName, email, phoneNumber);
            // Assert
            Assert.IsTrue(customerId > 0);
        }

        [TestMethod]
        // Specify the expected exception type
        [ExpectedException(typeof(ArgumentException))]
        // Testing InsertCustomer method with number inputs for first name
        public void InsertCustomer_InvalidFirstNameInput_ThrowsException()
        {
            // Arrange
            Form2 form2 = new Form2();
            // Invalid input: numbers and symbols instead of letters
            string firstName = "123@#g";
            string lastName = "Doe";
            string email = "john.doe@example.com";
            string phoneNumber = "123-456-7890";

            // Act
            int customerId = form2.InsertCustomer(firstName, lastName, email, phoneNumber);
        }

        [TestMethod]
        // Specify the expected exception type
        [ExpectedException(typeof(ArgumentException))]
        // Testing InsertCustomer method with number inputs for first name
        public void InsertCustomer_InvalidLastNameInput_ThrowsException()
        {
            // Arrange
            Form2 form2 = new Form2();
            // Invalid input: numbers and symbols instead of letters
            string firstName = "John";
            string lastName = "123g@#hs";
            string email = "john.doe@example.com";
            string phoneNumber = "123-456-7890";

            // Act
            int customerId = form2.InsertCustomer(firstName, lastName, email, phoneNumber);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        // Testing InsertCustomer method with invalid email input
        public void InsertCustomer_InvalidEmail_ThrowsArgumentException()
        {
            // Arrange
            Form2 form2 = new Form2();
            string firstName = "John";
            string lastName = "Doe";
            // Invalid email without '@' symbol and '.something'
            string email = "invalid-email";
            string phoneNumber = "123-456-7890";

            // Act
            int customerId = form2.InsertCustomer(firstName, lastName, email, phoneNumber);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        // Testing InsertCustomer method with invalid phone number format
        public void InsertCustomer_InvalidPhoneNumber_ThrowsArgumentException()
        {
            // Arrange
            Form2 form2 = new Form2();
            string firstName = "John";
            string lastName = "Doe";
            string email = "john.doe@example.com";
            // Invalid phone number: not in the format of XXX-XXX-XXXX
            string phoneNumber = "1234567890";

            // Act
            int customerId = form2.InsertCustomer(firstName, lastName, email, phoneNumber);
        }

        [TestMethod]
        // Testing InsertPet method with correct inputs
        public void TestInsertPet()
        {
            // Arrange
            var form2 = new Form2();
            int customerId = 20;
            string petName = "Buddy";
            string petSpecies = "Dog";
            string petBreed = "Labrador";
            string petGender = "Male";
            int petAge = 3;
            string petSpayedNeutered = "Neutered";

            // Act & Assert
            try
            {
                form2.InsertPet(customerId, petName, petSpecies, petBreed, petGender, petAge, petSpayedNeutered);
            }
            catch (Exception)
            {
                Assert.Fail("Inserting pet should not throw an exception.");
            }
        }

        [TestMethod]
        // Specify the expected exception type
        [ExpectedException(typeof(ArgumentException))]
        // Testing InsertPet method with number inputs for pet name
        public void InsertPet_InvalidPetNameInput_ThrowsException()
        {
            // Arrange
            Form2 form2 = new Form2();
            int customerId = 20;
            // Invalid input: numbers and symbols instead of letters
            string petName = "123g6#@";
            string petSpecies = "Dog";
            string petBreed = "Labrador";
            string petGender = "Male";
            int petAge = 3;
            string petSpayedNeutered = "Neutered";

            // Act
            form2.InsertPet(customerId, petName, petSpecies, petBreed, petGender, petAge, petSpayedNeutered);
        }

        [TestMethod]
        // Specify the expected exception type
        [ExpectedException(typeof(ArgumentException))]
        // Testing InsertPet method with number inputs for pet breed
        public void InsertPet_InvalidPetSpeciesInput_ThrowsException()
        {
            // Arrange
            Form2 form2 = new Form2();
            int customerId = 20;
            string petName = "Buddy";
            // Invalid input: numbers and symbols instead of letters
            string petSpecies = "47695#$b$";
            string petBreed = "Labrador";
            string petGender = "Male";
            int petAge = 3;
            string petSpayedNeutered = "Neutered";

            // Act
            form2.InsertPet(customerId, petName, petSpecies, petBreed, petGender, petAge, petSpayedNeutered);
        }

        [TestMethod]
        // Specify the expected exception type
        [ExpectedException(typeof(ArgumentException))]
        // Testing InsertPet method with number inputs for pet breed
        public void InsertPet_InvalidPetBreedInput_ThrowsException()
        {
            // Arrange
            Form2 form2 = new Form2();
            int customerId = 20;
            string petName = "Buddy";
            string petSpecies = "Dog";
            // Invalid input: numbers and symbols instead of letters
            string petBreed = "67i78&#4$";
            string petGender = "Male";
            int petAge = 3;
            string petSpayedNeutered = "Neutered";

            // Act
            form2.InsertPet(customerId, petName, petSpecies, petBreed, petGender, petAge, petSpayedNeutered);
        }

        [TestMethod]
        // Specify the expected exception type
        [ExpectedException(typeof(ArgumentException))]
        // Testing InsertPet method with incorrect inputs for gender
        public void InsertPet_InvalidPetGenderInput_ThrowsException()
        {
            // Arrange
            Form2 form2 = new Form2();
            int customerId = 20;
            string petName = "Buddy";
            string petSpecies = "Dog";
            string petBreed = "Labrador";
            // Gender input that is not 'Male' or 'Female'
            string petGender = "Cat";
            int petAge = 3;
            string petSpayedNeutered = "Neutered";

            // Act
            form2.InsertPet(customerId, petName, petSpecies, petBreed, petGender, petAge, petSpayedNeutered);
        }

        [TestMethod]
        // Specify the expected exception type
        [ExpectedException(typeof(ArgumentException))]
        // Testing InsertPet method with incorrect inputs for age
        public void InsertPet_InvalidPetAgeInput_ThrowsException()
        {
            // Arrange
            Form2 form2 = new Form2();
            int customerId = 20;
            string petName = "Buddy";
            string petSpecies = "Dog";
            string petBreed = "Labrador";
            string petGender = "Male";
            // Age must be a positive integer
            int petAge = -3;
            string petSpayedNeutered = "Neutered";

            // Act
            form2.InsertPet(customerId, petName, petSpecies, petBreed, petGender, petAge, petSpayedNeutered);
        }

        [TestMethod]
        // Specify the expected exception type
        [ExpectedException(typeof(ArgumentException))]
        // Testing InsertPet method with incorrect inputs for spayed or neutered
        public void InsertPet_InvalidPetSpayedNeuteredInput_ThrowsException()
        {
            // Arrange
            Form2 form2 = new Form2();
            int customerId = 20;
            string petName = "Buddy";
            string petSpecies = "Dog";
            string petBreed = "Labrador";
            string petGender = "Male";
            int petAge = 3;
            // Input must be 'Spayed', 'Neutered', or 'No'
            string petSpayedNeutered = "Yes";

            // Act
            form2.InsertPet(customerId, petName, petSpecies, petBreed, petGender, petAge, petSpayedNeutered);
        }
    }
}