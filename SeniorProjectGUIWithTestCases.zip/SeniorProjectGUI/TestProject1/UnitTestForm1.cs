using Microsoft.VisualStudio.TestTools.UnitTesting;
using SeniorProjectGUI;

namespace TestProject1
{
    [TestClass]
    public class UnitTestForm1
    {
        [TestMethod]
        public void TestMethod1()
        {
        }
    }
}