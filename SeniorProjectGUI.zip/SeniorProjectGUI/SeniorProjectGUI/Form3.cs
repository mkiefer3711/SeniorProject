﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace SeniorProjectGUI
{
    // Form 3 allows you to schedule new appointments
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // Go back to form 1 when button is clicked
            Form1 form1 = new Form1();
            form1.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            // Retrieve values from text boxes
            DateTime appointmentDateTime = dateTimePicker1.Value.Date + dateTimePicker2.Value.TimeOfDay;
            string customerName = textCustomerName.Text;
            string petName = textPetName.Text;
            string doctor = textDoctor.Text;
            string room = textRoomNumber.Text;
            string reason = textReasonForAppointment.Text;
            int appointmentLengthMinutes;
            if (!int.TryParse(textAppointmentLength.Text, out appointmentLengthMinutes))
            {
                // Handle invalid input
                MessageBox.Show("Please enter a valid appointment length.", "Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return; // Exit the method
            }

            // Get CustomerID and PetID based on customer name and pet name
            int customerId = GetCustomerId(customerName);
            int petId = GetPetId(petName);

            // Insert appointment information into the 'Appointment' table
            InsertAppointment(customerId, petId, appointmentDateTime, customerName, petName, doctor, room, reason, appointmentLengthMinutes);

            // Show success message
            MessageBox.Show("Appointment scheduled successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);

            // Clear all text boxes
            ClearTextBoxes();
        }

        // Method to clear all text boxes on the form
        private void ClearTextBoxes()
        {
            foreach (Control control in Controls)
            {
                if (control is System.Windows.Forms.TextBox)
                {
                    ((System.Windows.Forms.TextBox)control).Clear();
                }
            }
        }



        private int GetCustomerId(string customerName)
        {
            int customerId = -1; // Initialize with a default value indicating failure

            // Establish connection to your database
            string constring = @"Data Source = MADDISON-PC; Integrated Security = True; Connect Timeout = 30;User Id=MADDISON-PC\Maddison; ";
            using (SqlConnection con = new SqlConnection(constring))
            {
                // Define SQL query to retrieve CustomerID based on customer name
                string query = "SELECT CustomerID FROM Customer.dbo.Customer WHERE FirstName + ' ' + LastName = @CustomerName;";

                // Open connection
                con.Open();

                // Create command object
                using (SqlCommand command = new SqlCommand(query, con))
                {
                    // Add parameter
                    command.Parameters.AddWithValue("@CustomerName", customerName);

                    // Execute the query and get the result
                    object result = command.ExecuteScalar();
                    if (result != null) // Check if the result is not null
                    {
                        customerId = Convert.ToInt32(result); // Convert the result to an integer
                    }
                }
            }

            return customerId;
        }

        private int GetPetId(string petName)
        {
            int petId = -1; // Initialize with a default value indicating failure

            // Establish connection to your database
            string constring = @"Data Source = MADDISON-PC; Integrated Security = True; Connect Timeout = 30;User Id=MADDISON-PC\Maddison; ";
            using (SqlConnection con = new SqlConnection(constring))
            {
                // Define SQL query to retrieve PetID based on pet name
                string query = "SELECT PetID FROM Customer.dbo.Pet WHERE PetName = @PetName;";

                // Open connection
                con.Open();

                // Create command object
                using (SqlCommand command = new SqlCommand(query, con))
                {
                    // Add parameter
                    command.Parameters.AddWithValue("@PetName", petName);

                    // Execute the query and get the result
                    object result = command.ExecuteScalar();
                    if (result != null) // Check if the result is not null
                    {
                        petId = Convert.ToInt32(result); // Convert the result to an integer
                    }
                }
            }

            return petId;
        }

        private void InsertAppointment(int customerId, int petId, DateTime appointmentDateTime, string customerName, string petName, string doctor, string room, string reason, int appointmentLengthMinutes)
        {
            // Establish connection to your database
            string constring = @"Data Source = MADDISON-PC; Integrated Security = True; Connect Timeout = 30;User Id=MADDISON-PC\Maddison; ";
            using (SqlConnection con = new SqlConnection(constring))
            {
                // Define SQL query to insert appointment information
                string query = "INSERT INTO Customer.dbo.Appointment (CustomerID, PetID, AppointmentDateTime, CustomerName, PetName, Doctor, Room, Reason, AppointmentLengthMinutes) VALUES (@CustomerId, @PetId, @AppointmentDateTime, @CustomerName, @PetName, @Doctor, @Room, @Reason, @AppointmentLengthMinutes);";

                // Open connection
                con.Open();

                // Create command object
                using (SqlCommand command = new SqlCommand(query, con))
                {
                    // Add parameters
                    command.Parameters.AddWithValue("@CustomerId", customerId);
                    command.Parameters.AddWithValue("@PetId", petId);
                    command.Parameters.AddWithValue("@AppointmentDateTime", appointmentDateTime);
                    command.Parameters.AddWithValue("@CustomerName", customerName);
                    command.Parameters.AddWithValue("@PetName", petName);
                    command.Parameters.AddWithValue("@Doctor", doctor);
                    command.Parameters.AddWithValue("@Room", room);
                    command.Parameters.AddWithValue("@Reason", reason);
                    command.Parameters.AddWithValue("@AppointmentLengthMinutes", appointmentLengthMinutes);

                    // Execute query
                    command.ExecuteNonQuery();
                }
            }
        }
    }
}
