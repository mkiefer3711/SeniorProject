﻿namespace SeniorProjectGUI
{
    partial class Form4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            button1 = new Button();
            customerDataGrid = new DataGridView();
            label2 = new Label();
            petDataGrid = new DataGridView();
            ((System.ComponentModel.ISupportInitialize)customerDataGrid).BeginInit();
            ((System.ComponentModel.ISupportInitialize)petDataGrid).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 12F);
            label1.Location = new Point(280, 41);
            label1.Name = "label1";
            label1.Size = new Size(78, 21);
            label1.TabIndex = 0;
            label1.Text = "Customer";
            // 
            // button1
            // 
            button1.Location = new Point(12, 7);
            button1.Name = "button1";
            button1.Size = new Size(75, 23);
            button1.TabIndex = 1;
            button1.Text = "Back";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // customerDataGrid
            // 
            customerDataGrid.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            customerDataGrid.Location = new Point(12, 65);
            customerDataGrid.Name = "customerDataGrid";
            customerDataGrid.Size = new Size(644, 134);
            customerDataGrid.TabIndex = 30;
            customerDataGrid.CellContentClick += dataGridView1_CellContentClick;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 12F);
            label2.Location = new Point(295, 213);
            label2.Name = "label2";
            label2.Size = new Size(38, 21);
            label2.TabIndex = 31;
            label2.Text = "Pets";
            // 
            // petDataGrid
            // 
            petDataGrid.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            petDataGrid.Location = new Point(12, 237);
            petDataGrid.Name = "petDataGrid";
            petDataGrid.Size = new Size(644, 203);
            petDataGrid.TabIndex = 32;
            // 
            // Form4
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(689, 486);
            Controls.Add(petDataGrid);
            Controls.Add(label2);
            Controls.Add(customerDataGrid);
            Controls.Add(button1);
            Controls.Add(label1);
            Name = "Form4";
            Text = "Form4";
            ((System.ComponentModel.ISupportInitialize)customerDataGrid).EndInit();
            ((System.ComponentModel.ISupportInitialize)petDataGrid).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Button button1;
        private TextBox textCustomerFirstName;
        private TextBox textCustomerLastName;
        private TextBox textCustomerEmail;
        private TextBox textCustomerPhone;
        private TextBox textBox1;
        private TextBox textBox2;
        private TextBox textBox3;
        private TextBox textBox4;
        private TextBox textBox5;
        private TextBox textBox6;
        private TextBox textBox7;
        private TextBox textBox8;
        private TextBox textBox9;
        private TextBox textBox10;
        private TextBox textBox11;
        private TextBox textBox12;
        private TextBox textBox13;
        private TextBox textBox14;
        private TextBox textBox15;
        private TextBox textBox16;
        private TextBox textBox17;
        private TextBox textBox18;
        private TextBox textBox19;
        private TextBox textBox20;
        private DataGridView customerDataGrid;
        private Label label2;
        private DataGridView petDataGrid;
    }
}