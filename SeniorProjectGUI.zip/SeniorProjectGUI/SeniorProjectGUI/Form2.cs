﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Runtime.InteropServices.JavaScript.JSType;


namespace SeniorProjectGUI
{
    // Form 2 allows you to add a new client to the database
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            // Retrieve values from text boxes
            string firstName = textFirstName.Text;
            string lastName = textLastName.Text;
            string email = textEmail.Text;
            long phoneNumber;
            if (!long.TryParse(textPhoneNumber.Text, out phoneNumber))
            {
                // Handle invalid input
                MessageBox.Show("Please enter a valid phone number.", "Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return; // Exit the method
            }

            // Insert client information into the 'customers' table
            int customerID = InsertCustomer(firstName, lastName, email, phoneNumber);

            // If customerID is greater than 0, it means the insertion was successful
            if (customerID > 0)
            {
                // Retrieve values for pet information
                string petName = textPetName.Text;
                string petSpecies = textPetSpecies.Text;
                string petBreed = textPetBreed.Text;
                string petGender = textPetGender.Text;
                int petAge;
                if (!int.TryParse(textPetAge.Text, out petAge))
                {
                    // Handle invalid input
                    MessageBox.Show("Please enter a valid pet age.", "Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return; // Exit the method
                }
                string petSpayedNeutered = textSpayedNeutered.Text;

                // Insert pet information into the 'pets' table, associating it with the customer
                InsertPet(customerID, petName, petSpecies, petBreed, petGender, petAge, petSpayedNeutered);

                // Show success message
                MessageBox.Show("Client added successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);

                // Clear all text boxes
                ClearTextBoxes();

            }
            else
            {
                // Show error message if customerID is not greater than 0
                MessageBox.Show("Failed to add client.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Method to clear all text boxes on the form
        private void ClearTextBoxes()
        {
            foreach (Control control in Controls)
            {
                if (control is TextBox)
                {
                    ((TextBox)control).Clear();
                }
            }
        }

        private int InsertCustomer(string firstName, string lastName, string email, long phoneNumber)
        {
            // Establish connection to your database
            string constring = @"Data Source = MADDISON-PC; Integrated Security = True; Connect Timeout = 30;User Id=MADDISON-PC\Maddison; ";
            using (SqlConnection con = new SqlConnection(constring))
            {
                // Define SQL query to insert customer information
                string query = "INSERT INTO Customer.dbo.Customer (FirstName, LastName, Email, PhoneNumber) VALUES (@FirstName, @LastName, @Email, @PhoneNumber); SELECT SCOPE_IDENTITY();";

                // Open connection
                con.Open();

                // Create command object
                using (SqlCommand command = new SqlCommand(query, con))
                {
                    // Add parameters
                    command.Parameters.AddWithValue("@FirstName", firstName);
                    command.Parameters.AddWithValue("@LastName", lastName);
                    command.Parameters.AddWithValue("@Email", email);
                    command.Parameters.AddWithValue("@PhoneNumber", phoneNumber);

                    // Execute query and get the generated customer ID
                    int CustomerID = Convert.ToInt32(command.ExecuteScalar());
                    return CustomerID;
                }
            }
        }

        private void InsertPet(int customerId, string petName, string petSpecies, string petBreed, string petGender, int petAge, string petSpayedNeutered)
        {
            // Establish connection to your database
            string constring = @"Data Source = MADDISON-PC; Integrated Security = True; Connect Timeout = 30;User Id=MADDISON-PC\Maddison; ";
            using (SqlConnection connection = new SqlConnection(constring))
            {
                // Define SQL query to insert pet information
                string query = "INSERT INTO Customer.dbo.Pet (CustomerID, PetName, Species, Breed, Gender, Age, SpayedNeutered) VALUES (@CustomerId, @PetName, @PetSpecies, @PetBreed, @PetGender, @PetAge, @PetSpayedNeutered);";

                // Open connection
                connection.Open();

                // Create command object
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    // Add parameters
                    command.Parameters.AddWithValue("@CustomerId", customerId);
                    command.Parameters.AddWithValue("@PetName", petName);
                    command.Parameters.AddWithValue("@PetSpecies", petSpecies);
                    command.Parameters.AddWithValue("@PetBreed", petBreed);
                    command.Parameters.AddWithValue("@PetGender", petGender);
                    command.Parameters.AddWithValue("@PetAge", petAge);
                    command.Parameters.AddWithValue("@PetSpayedNeutered", petSpayedNeutered);

                    // Execute query
                    command.ExecuteNonQuery();
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // Go back to form 1 when button is clicked
            Form1 form1 = new Form1();
            form1.Show();
            this.Hide();
        }
    }
}