using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.Globalization;
using System;
using System.Drawing;
using System.Numerics;
using static SeniorProjectGUI.Form1;
using System.Security.Cryptography;

namespace SeniorProjectGUI
{
    // Form 1 is the main schedule and where you can search the database, schedule appointments, and add new clients
    public partial class Form1 : Form
    {
        // Creating Appointment class
        public class Appointment
        {
            public int AppointmentID { get; set; }
            public int CustomerID { get; set; }
            public int PetID { get; set; }
            public DateTime AppointmentDateTime { get; set; }
            public string CustomerName { get; set; }
            public string PetName { get; set; }
            public string Doctor { get; set; }
            public string Room { get; set; }
            public string Reason { get; set; }
            public int AppointmentLengthMinutes { get; set; }
        }

        // Creating a list for todaysAppointments
        List<Appointment> todaysAppointments = new List<Appointment>() { };

        // Creating a list for the rooms that appointments occur in
        List<string> rooms = new List<string>() { "exam room 1", "exam room 2", "exam room 3", "surgery room 1", "surgery room 2" };

        // Setting the calenderDate variable
        DateTime calenderDate = DateTime.Now;

        // Creating a list of colors for labeling appointment times
        List<Color> colors = new List<Color>() { Color.LightBlue, Color.LightPink, Color.LightGoldenrodYellow, Color.LightSalmon };
        public Form1()
        {
            InitializeComponent();
            // Calling drawCalender function
            drawCalender();

            // Subscribe to the KeyPress event of the search bar
            searchBar.TextChanged += searchBar_TextChanged;
            searchBar.KeyPress += searchBar_KeyPress;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // Dispaly Form 2 when button is clicked
            Form2 form2 = new Form2();
            form2.Show();
            this.Hide();
        }

        // Function called fillGrid()
        private void fillGrid()
        {
            var colorcount = 0;
            // Goes through each appointment
            foreach (var app in todaysAppointments)
            {
                // Setting each needed variable
                var appColor = colors[colorcount];
                var room = rooms.IndexOf(app.Room.ToLower());
                var hour = app.AppointmentDateTime.Hour - 9;
                var min = app.AppointmentDateTime.Minute / 15;
                var length = app.AppointmentLengthMinutes / 15;
                var loops = length;

                while (loops > 0)
                {
                    TableLayoutPanel hourblock = (TableLayoutPanel)this.MainSchedulerTable.GetControlFromPosition(room, hour);

                    // Loops through each panel in the appointment time and colors them, then adds the customer name and pet name to
                    // the first panel for the appointment
                    for (int i = min; i < 4; i++)
                    {
                        var minblock = hourblock.GetControlFromPosition(0, i);
                        minblock.BackColor = appColor;
                        if (loops == length)
                        {
                            minblock.Controls.Add(new Label { Text = $"{app.CustomerName}, {app.PetName}", Anchor = AnchorStyles.Left, AutoSize = true });
                        }
                        loops--;
                    }
                    hour++;
                    min = 0;
                }

                colorcount++;
                if (colorcount > 4)
                {
                    colorcount = 0;
                };
            }
        }

        // Method to clear the grid
        private void clearGrid()
        {
            // Loops through the schedule and changes each colored block back to light gray and clears the text
            for (int i = 0; i < this.MainSchedulerTable.ColumnCount; i++)
            {
                for (int j = 0; j < this.MainSchedulerTable.RowCount; j++)
                {
                    TableLayoutPanel cell = (TableLayoutPanel)this.MainSchedulerTable.GetControlFromPosition(i, j);
                    for (int k = 0; k < 4; k++)
                    {
                        var minBlock = cell.GetControlFromPosition(0, k);
                        minBlock.BackColor = Color.LightGray;
                        minBlock.Controls.Clear();

                    }
                }
            }
        }

        // Method to get Appointments
        private void getAppointments(DateTime date)
        {
            // Creates a new list
            this.todaysAppointments = new List<Appointment>();
            string constring = @"Data Source = MADDISON-PC; Integrated Security = True; Connect Timeout = 30;User Id=MADDISON-PC\Maddison; ";
            using (SqlConnection con = new SqlConnection(constring))
            {
                // Define SQL query to insert appointment information
                string query = "select * from Customer.dbo.Appointment where datediff(dd, AppointmentDateTime, @date) = 0 ";

                // Open connection
                con.Open();

                // Create command object
                using (SqlCommand command = new SqlCommand(query, con))
                {
                    var table = new DataTable();
                    // Add parameters
                    command.Parameters.AddWithValue("@date", date.Date.ToString());
                    //SqlDataAdapter da = new SqlDataAdapter(command);

                    SqlDataReader dr = command.ExecuteReader();

                    // Saves all information to variables and adds them to the todaysAppointments list
                    while (dr.Read())
                    {
                        var app = new Appointment()
                        {
                            AppointmentID = (int)dr["AppointmentID"],
                            CustomerID = (int)dr["CustomerID"],
                            PetID = (int)dr["PetID"],
                            AppointmentDateTime = (DateTime)dr["AppointmentDateTime"],
                            CustomerName = dr["CustomerName"].ToString(),
                            PetName = dr["PetName"].ToString(),
                            Doctor = dr["Doctor"].ToString(),
                            Room = dr["Room"].ToString(),
                            Reason = dr["Reason"].ToString(),
                            AppointmentLengthMinutes = (int)dr["AppointmentLengthMinutes"]
                        };

                        todaysAppointments.Add(app);
                    }
                }
            }
        }

        // Method to draw the calendar
        private void drawCalender()
        {
            CalenderDateLabel.Text = calenderDate.ToString("D");
            getAppointments(calenderDate);
            clearGrid();
            fillGrid();
        }


        // Method to go to form 3 when the schedule appointment button is clicked
        private void button2_Click(object sender, EventArgs e)
        {
            Form3 form3 = new Form3();
            form3.Show();
            this.Hide();
        }

        // Method for the Previous button to function
        private void PrevButton_Click(object sender, EventArgs e)
        {
            calenderDate = calenderDate.AddDays(-1);
            drawCalender();
        }

        // Method for the Next button to function
        private void NextButton_Click(object sender, EventArgs e)
        {
            calenderDate = calenderDate.AddDays(1);
            drawCalender();
        }

        private void searchBar_TextChanged(object sender, EventArgs e)
        {

        }

        private void PerformSearch()
        {
            string searchQuery = searchBar.Text.Trim();
            DataTable customerResults = new DataTable();
            DataTable petResults = new DataTable();

            string constring = @"Data Source = MADDISON-PC; Integrated Security = True; Connect Timeout = 30;User Id=MADDISON-PC\Maddison; ";

            // Construct SQL query to search for matching customers
            string customerQuery = "SELECT * FROM Customer.dbo.Customer WHERE FirstName LIKE @searchQuery OR LastName LIKE @searchQuery;";

            // Construct SQL query to search for matching pets
            string petQuery = "SELECT * FROM Customer.dbo.Pet WHERE PetName LIKE @searchQuery;";

            using (SqlConnection con = new SqlConnection(constring))
            {
                // Open connection
                con.Open();

                // Search for matching customers
                using (SqlCommand customerCommand = new SqlCommand(customerQuery, con))
                {
                    // Add parameter
                    customerCommand.Parameters.AddWithValue("@searchQuery", "%" + searchQuery + "%");

                    // Fill the DataTable with customer search results
                    using (SqlDataAdapter adapter = new SqlDataAdapter(customerCommand))
                    {
                        adapter.Fill(customerResults);
                    }
                }

                // Search for matching pets
                using (SqlCommand petCommand = new SqlCommand(petQuery, con))
                {
                    // Add parameter
                    petCommand.Parameters.AddWithValue("@searchQuery", "%" + searchQuery + "%");

                    // Fill the DataTable with pet search results
                    using (SqlDataAdapter adapter = new SqlDataAdapter(petCommand))
                    {
                        adapter.Fill(petResults);
                    }
                }
            }

            // Check if any results were found
            if (customerResults.Rows.Count == 0 && petResults.Rows.Count == 0)
            {
                MessageBox.Show("No results found.", "Search Results", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                // Open Form4 and pass the search results
                Form4 form4 = new Form4(customerResults, petResults, searchQuery);
                form4.Show();
                this.Hide();
            }
        }

        private void searchBar_KeyPress(object sender, KeyPressEventArgs e)
        {
            // Check if the Enter key is pressed
            if (e.KeyChar == (char)Keys.Enter)
            {
                // Perform the search
                PerformSearch();

                // Suppress the Enter key from being processed further
                e.Handled = true;


            }
        }
    }
}
