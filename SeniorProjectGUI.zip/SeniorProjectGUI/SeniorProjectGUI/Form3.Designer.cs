﻿namespace SeniorProjectGUI
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            button2 = new Button();
            textRoomNumber = new TextBox();
            textDoctor = new TextBox();
            textReasonForAppointment = new TextBox();
            textPetName = new TextBox();
            textCustomerName = new TextBox();
            label7 = new Label();
            label6 = new Label();
            label5 = new Label();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            button1 = new Button();
            label1 = new Label();
            dateTimePicker1 = new DateTimePicker();
            dateTimePicker2 = new DateTimePicker();
            label8 = new Label();
            textAppointmentLength = new TextBox();
            SuspendLayout();
            // 
            // button2
            // 
            button2.Font = new Font("Segoe UI", 11F);
            button2.Location = new Point(203, 475);
            button2.Name = "button2";
            button2.Size = new Size(103, 28);
            button2.TabIndex = 45;
            button2.Text = "Schedule";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // textRoomNumber
            // 
            textRoomNumber.Location = new Point(312, 285);
            textRoomNumber.Name = "textRoomNumber";
            textRoomNumber.Size = new Size(166, 23);
            textRoomNumber.TabIndex = 40;
            // 
            // textDoctor
            // 
            textDoctor.Location = new Point(179, 417);
            textDoctor.Name = "textDoctor";
            textDoctor.Size = new Size(166, 23);
            textDoctor.TabIndex = 39;
            // 
            // textReasonForAppointment
            // 
            textReasonForAppointment.Location = new Point(312, 353);
            textReasonForAppointment.Name = "textReasonForAppointment";
            textReasonForAppointment.Size = new Size(166, 23);
            textReasonForAppointment.TabIndex = 38;
            // 
            // textPetName
            // 
            textPetName.Location = new Point(49, 353);
            textPetName.Name = "textPetName";
            textPetName.Size = new Size(166, 23);
            textPetName.TabIndex = 37;
            // 
            // textCustomerName
            // 
            textCustomerName.Location = new Point(49, 285);
            textCustomerName.Name = "textCustomerName";
            textCustomerName.Size = new Size(166, 23);
            textCustomerName.TabIndex = 36;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Segoe UI", 11F);
            label7.Location = new Point(312, 330);
            label7.Name = "label7";
            label7.Size = new Size(172, 20);
            label7.TabIndex = 30;
            label7.Text = "Reason for Appointment";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI", 11F);
            label6.Location = new Point(344, 262);
            label6.Name = "label6";
            label6.Size = new Size(107, 20);
            label6.TabIndex = 29;
            label6.Text = "Room Number";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 11F);
            label5.Location = new Point(233, 394);
            label5.Name = "label5";
            label5.Size = new Size(55, 20);
            label5.TabIndex = 28;
            label5.Text = "Doctor";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 11F);
            label4.Location = new Point(83, 330);
            label4.Name = "label4";
            label4.Size = new Size(73, 20);
            label4.TabIndex = 27;
            label4.Text = "Pet Name";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 11F);
            label3.Location = new Point(68, 262);
            label3.Name = "label3";
            label3.Size = new Size(116, 20);
            label3.TabIndex = 26;
            label3.Text = "Customer Name";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 11F);
            label2.Location = new Point(179, 108);
            label2.Name = "label2";
            label2.Size = new Size(172, 20);
            label2.TabIndex = 25;
            label2.Text = "Appointment Date/Time";
            // 
            // button1
            // 
            button1.Location = new Point(18, 9);
            button1.Name = "button1";
            button1.Size = new Size(75, 23);
            button1.TabIndex = 24;
            button1.Text = "Back";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 24F);
            label1.Location = new Point(98, 43);
            label1.Name = "label1";
            label1.Size = new Size(347, 45);
            label1.TabIndex = 23;
            label1.Text = "Schedule Appointment";
            // 
            // dateTimePicker1
            // 
            dateTimePicker1.Location = new Point(97, 141);
            dateTimePicker1.Name = "dateTimePicker1";
            dateTimePicker1.Size = new Size(209, 23);
            dateTimePicker1.TabIndex = 46;
            // 
            // dateTimePicker2
            // 
            dateTimePicker2.Format = DateTimePickerFormat.Time;
            dateTimePicker2.Location = new Point(312, 141);
            dateTimePicker2.Name = "dateTimePicker2";
            dateTimePicker2.ShowUpDown = true;
            dateTimePicker2.Size = new Size(102, 23);
            dateTimePicker2.TabIndex = 47;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Segoe UI", 11F);
            label8.Location = new Point(189, 194);
            label8.Name = "label8";
            label8.Size = new Size(146, 20);
            label8.TabIndex = 48;
            label8.Text = "Appointment Length";
            // 
            // textAppointmentLength
            // 
            textAppointmentLength.Location = new Point(179, 217);
            textAppointmentLength.Name = "textAppointmentLength";
            textAppointmentLength.Size = new Size(166, 23);
            textAppointmentLength.TabIndex = 49;
            // 
            // Form3
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(546, 564);
            Controls.Add(textAppointmentLength);
            Controls.Add(label8);
            Controls.Add(dateTimePicker2);
            Controls.Add(dateTimePicker1);
            Controls.Add(button2);
            Controls.Add(textRoomNumber);
            Controls.Add(textDoctor);
            Controls.Add(textReasonForAppointment);
            Controls.Add(textPetName);
            Controls.Add(textCustomerName);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(button1);
            Controls.Add(label1);
            Name = "Form3";
            Text = "Form3";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button button2;
        private TextBox textRoomNumber;
        private TextBox textDoctor;
        private TextBox textReasonForAppointment;
        private TextBox textPetName;
        private TextBox textCustomerName;
        private Label label7;
        private Label label6;
        private Label label5;
        private Label label4;
        private Label label3;
        private Label label2;
        private Button button1;
        private Label label1;
        private DateTimePicker dateTimePicker1;
        private DateTimePicker dateTimePicker2;
        private Label label8;
        private TextBox textAppointmentLength;
    }
}