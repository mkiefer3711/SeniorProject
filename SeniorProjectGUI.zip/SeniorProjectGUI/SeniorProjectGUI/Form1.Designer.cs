﻿namespace SeniorProjectGUI
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            button1 = new Button();
            button2 = new Button();
            label1 = new Label();
            tableLayoutPanel26 = new TableLayoutPanel();
            label8 = new Label();
            label7 = new Label();
            label6 = new Label();
            label5 = new Label();
            label4 = new Label();
            label3 = new Label();
            MainSchedulerTable = new TableLayoutPanel();
            tableLayoutPanel51 = new TableLayoutPanel();
            panel185 = new Panel();
            panel186 = new Panel();
            panel187 = new Panel();
            panel188 = new Panel();
            tableLayoutPanel50 = new TableLayoutPanel();
            panel181 = new Panel();
            panel182 = new Panel();
            panel183 = new Panel();
            panel184 = new Panel();
            tableLayoutPanel49 = new TableLayoutPanel();
            panel177 = new Panel();
            panel178 = new Panel();
            panel179 = new Panel();
            panel180 = new Panel();
            tableLayoutPanel48 = new TableLayoutPanel();
            panel173 = new Panel();
            panel174 = new Panel();
            panel175 = new Panel();
            panel176 = new Panel();
            tableLayoutPanel47 = new TableLayoutPanel();
            panel169 = new Panel();
            panel170 = new Panel();
            panel171 = new Panel();
            panel172 = new Panel();
            tableLayoutPanel46 = new TableLayoutPanel();
            panel165 = new Panel();
            panel166 = new Panel();
            panel167 = new Panel();
            panel168 = new Panel();
            tableLayoutPanel45 = new TableLayoutPanel();
            panel161 = new Panel();
            panel162 = new Panel();
            panel163 = new Panel();
            panel164 = new Panel();
            tableLayoutPanel44 = new TableLayoutPanel();
            panel157 = new Panel();
            panel158 = new Panel();
            panel159 = new Panel();
            panel160 = new Panel();
            tableLayoutPanel43 = new TableLayoutPanel();
            panel153 = new Panel();
            panel154 = new Panel();
            panel155 = new Panel();
            panel156 = new Panel();
            tableLayoutPanel42 = new TableLayoutPanel();
            panel149 = new Panel();
            panel150 = new Panel();
            panel151 = new Panel();
            panel152 = new Panel();
            tableLayoutPanel41 = new TableLayoutPanel();
            panel145 = new Panel();
            panel146 = new Panel();
            panel147 = new Panel();
            panel148 = new Panel();
            tableLayoutPanel40 = new TableLayoutPanel();
            panel141 = new Panel();
            panel142 = new Panel();
            panel143 = new Panel();
            panel144 = new Panel();
            tableLayoutPanel39 = new TableLayoutPanel();
            panel137 = new Panel();
            panel138 = new Panel();
            panel139 = new Panel();
            panel140 = new Panel();
            tableLayoutPanel38 = new TableLayoutPanel();
            panel133 = new Panel();
            panel134 = new Panel();
            panel135 = new Panel();
            panel136 = new Panel();
            tableLayoutPanel37 = new TableLayoutPanel();
            panel129 = new Panel();
            panel130 = new Panel();
            panel131 = new Panel();
            panel132 = new Panel();
            tableLayoutPanel36 = new TableLayoutPanel();
            panel125 = new Panel();
            panel126 = new Panel();
            panel127 = new Panel();
            panel128 = new Panel();
            tableLayoutPanel35 = new TableLayoutPanel();
            panel121 = new Panel();
            panel122 = new Panel();
            panel123 = new Panel();
            panel124 = new Panel();
            tableLayoutPanel34 = new TableLayoutPanel();
            panel117 = new Panel();
            panel118 = new Panel();
            panel119 = new Panel();
            panel120 = new Panel();
            tableLayoutPanel33 = new TableLayoutPanel();
            panel113 = new Panel();
            panel114 = new Panel();
            panel115 = new Panel();
            panel116 = new Panel();
            tableLayoutPanel32 = new TableLayoutPanel();
            panel109 = new Panel();
            panel110 = new Panel();
            panel111 = new Panel();
            panel112 = new Panel();
            tableLayoutPanel31 = new TableLayoutPanel();
            panel105 = new Panel();
            panel106 = new Panel();
            panel107 = new Panel();
            panel108 = new Panel();
            tableLayoutPanel29 = new TableLayoutPanel();
            panel101 = new Panel();
            panel102 = new Panel();
            panel103 = new Panel();
            panel104 = new Panel();
            tableLayoutPanel28 = new TableLayoutPanel();
            panel97 = new Panel();
            panel98 = new Panel();
            panel99 = new Panel();
            panel100 = new Panel();
            tableLayoutPanel27 = new TableLayoutPanel();
            panel93 = new Panel();
            panel94 = new Panel();
            panel95 = new Panel();
            panel96 = new Panel();
            tableLayoutPanel25 = new TableLayoutPanel();
            panel89 = new Panel();
            panel90 = new Panel();
            panel91 = new Panel();
            panel92 = new Panel();
            tableLayoutPanel18 = new TableLayoutPanel();
            panel65 = new Panel();
            panel66 = new Panel();
            panel67 = new Panel();
            panel68 = new Panel();
            tableLayoutPanel24 = new TableLayoutPanel();
            panel85 = new Panel();
            panel86 = new Panel();
            panel87 = new Panel();
            panel88 = new Panel();
            tableLayoutPanel23 = new TableLayoutPanel();
            panel81 = new Panel();
            panel82 = new Panel();
            panel83 = new Panel();
            panel84 = new Panel();
            tableLayoutPanel21 = new TableLayoutPanel();
            panel77 = new Panel();
            panel78 = new Panel();
            panel79 = new Panel();
            panel80 = new Panel();
            tableLayoutPanel20 = new TableLayoutPanel();
            panel73 = new Panel();
            panel74 = new Panel();
            panel75 = new Panel();
            panel76 = new Panel();
            tableLayoutPanel8 = new TableLayoutPanel();
            panel35 = new Panel();
            panel36 = new Panel();
            panel37 = new Panel();
            panel38 = new Panel();
            tableLayoutPanel7 = new TableLayoutPanel();
            panel31 = new Panel();
            panel32 = new Panel();
            panel33 = new Panel();
            panel34 = new Panel();
            tableLayoutPanel6 = new TableLayoutPanel();
            panel27 = new Panel();
            panel28 = new Panel();
            panel29 = new Panel();
            panel30 = new Panel();
            tableLayoutPanel9 = new TableLayoutPanel();
            panel19 = new Panel();
            panel20 = new Panel();
            panel21 = new Panel();
            panel22 = new Panel();
            tableLayoutPanel5 = new TableLayoutPanel();
            panel4 = new Panel();
            panel3 = new Panel();
            panel2 = new Panel();
            panel1 = new Panel();
            tableLayoutPanel116 = new TableLayoutPanel();
            panel15 = new Panel();
            panel16 = new Panel();
            panel17 = new Panel();
            panel18 = new Panel();
            tableLayoutPanel2 = new TableLayoutPanel();
            panel11 = new Panel();
            panel12 = new Panel();
            panel13 = new Panel();
            panel14 = new Panel();
            tableLayoutPanel4 = new TableLayoutPanel();
            panel23 = new Panel();
            panel24 = new Panel();
            panel25 = new Panel();
            panel26 = new Panel();
            tableLayoutPanel10 = new TableLayoutPanel();
            panel39 = new Panel();
            panel40 = new Panel();
            panel41 = new Panel();
            panel42 = new Panel();
            tableLayoutPanel12 = new TableLayoutPanel();
            panel45 = new Panel();
            panel46 = new Panel();
            panel47 = new Panel();
            panel48 = new Panel();
            tableLayoutPanel13 = new TableLayoutPanel();
            panel49 = new Panel();
            panel50 = new Panel();
            panel51 = new Panel();
            panel52 = new Panel();
            tableLayoutPanel14 = new TableLayoutPanel();
            panel53 = new Panel();
            panel54 = new Panel();
            panel55 = new Panel();
            panel56 = new Panel();
            tableLayoutPanel15 = new TableLayoutPanel();
            panel57 = new Panel();
            panel58 = new Panel();
            panel59 = new Panel();
            panel60 = new Panel();
            tableLayoutPanel16 = new TableLayoutPanel();
            panel61 = new Panel();
            panel62 = new Panel();
            panel63 = new Panel();
            panel64 = new Panel();
            tableLayoutPanel19 = new TableLayoutPanel();
            panel69 = new Panel();
            panel70 = new Panel();
            panel71 = new Panel();
            panel72 = new Panel();
            label2 = new Label();
            searchBar = new TextBox();
            tableLayoutPanel17 = new TableLayoutPanel();
            tableLayoutPanel30 = new TableLayoutPanel();
            tableLayoutPanel59 = new TableLayoutPanel();
            label17 = new Label();
            label16 = new Label();
            label15 = new Label();
            label14 = new Label();
            label13 = new Label();
            label12 = new Label();
            label11 = new Label();
            label10 = new Label();
            label9 = new Label();
            NextButton = new Button();
            PrevButton = new Button();
            CalenderDateLabel = new Label();
            tableLayoutPanel3 = new TableLayoutPanel();
            tableLayoutPanel22 = new TableLayoutPanel();
            tableLayoutPanel61 = new TableLayoutPanel();
            panel5 = new Panel();
            panel6 = new Panel();
            panel7 = new Panel();
            panel8 = new Panel();
            tableLayoutPanel62 = new TableLayoutPanel();
            tableLayoutPanel63 = new TableLayoutPanel();
            tableLayoutPanel64 = new TableLayoutPanel();
            tableLayoutPanel65 = new TableLayoutPanel();
            tableLayoutPanel66 = new TableLayoutPanel();
            tableLayoutPanel67 = new TableLayoutPanel();
            tableLayoutPanel68 = new TableLayoutPanel();
            tableLayoutPanel69 = new TableLayoutPanel();
            tableLayoutPanel70 = new TableLayoutPanel();
            tableLayoutPanel71 = new TableLayoutPanel();
            tableLayoutPanel72 = new TableLayoutPanel();
            tableLayoutPanel73 = new TableLayoutPanel();
            tableLayoutPanel74 = new TableLayoutPanel();
            tableLayoutPanel75 = new TableLayoutPanel();
            tableLayoutPanel76 = new TableLayoutPanel();
            tableLayoutPanel77 = new TableLayoutPanel();
            tableLayoutPanel78 = new TableLayoutPanel();
            tableLayoutPanel79 = new TableLayoutPanel();
            tableLayoutPanel80 = new TableLayoutPanel();
            tableLayoutPanel81 = new TableLayoutPanel();
            tableLayoutPanel82 = new TableLayoutPanel();
            tableLayoutPanel83 = new TableLayoutPanel();
            tableLayoutPanel84 = new TableLayoutPanel();
            tableLayoutPanel85 = new TableLayoutPanel();
            tableLayoutPanel86 = new TableLayoutPanel();
            tableLayoutPanel87 = new TableLayoutPanel();
            tableLayoutPanel88 = new TableLayoutPanel();
            tableLayoutPanel89 = new TableLayoutPanel();
            tableLayoutPanel90 = new TableLayoutPanel();
            tableLayoutPanel91 = new TableLayoutPanel();
            tableLayoutPanel92 = new TableLayoutPanel();
            tableLayoutPanel93 = new TableLayoutPanel();
            tableLayoutPanel94 = new TableLayoutPanel();
            tableLayoutPanel95 = new TableLayoutPanel();
            tableLayoutPanel96 = new TableLayoutPanel();
            tableLayoutPanel97 = new TableLayoutPanel();
            tableLayoutPanel98 = new TableLayoutPanel();
            tableLayoutPanel99 = new TableLayoutPanel();
            tableLayoutPanel100 = new TableLayoutPanel();
            tableLayoutPanel101 = new TableLayoutPanel();
            tableLayoutPanel102 = new TableLayoutPanel();
            tableLayoutPanel103 = new TableLayoutPanel();
            tableLayoutPanel104 = new TableLayoutPanel();
            tableLayoutPanel105 = new TableLayoutPanel();
            tableLayoutPanel106 = new TableLayoutPanel();
            tableLayoutPanel107 = new TableLayoutPanel();
            tableLayoutPanel108 = new TableLayoutPanel();
            tableLayoutPanel109 = new TableLayoutPanel();
            tableLayoutPanel110 = new TableLayoutPanel();
            tableLayoutPanel111 = new TableLayoutPanel();
            tableLayoutPanel112 = new TableLayoutPanel();
            tableLayoutPanel113 = new TableLayoutPanel();
            tableLayoutPanel114 = new TableLayoutPanel();
            panel9 = new Panel();
            panel10 = new Panel();
            tableLayoutPanel11 = new TableLayoutPanel();
            panel43 = new Panel();
            panel44 = new Panel();
            tableLayoutPanel26.SuspendLayout();
            MainSchedulerTable.SuspendLayout();
            tableLayoutPanel51.SuspendLayout();
            tableLayoutPanel50.SuspendLayout();
            tableLayoutPanel49.SuspendLayout();
            tableLayoutPanel48.SuspendLayout();
            tableLayoutPanel47.SuspendLayout();
            tableLayoutPanel46.SuspendLayout();
            tableLayoutPanel45.SuspendLayout();
            tableLayoutPanel44.SuspendLayout();
            tableLayoutPanel43.SuspendLayout();
            tableLayoutPanel42.SuspendLayout();
            tableLayoutPanel41.SuspendLayout();
            tableLayoutPanel40.SuspendLayout();
            tableLayoutPanel39.SuspendLayout();
            tableLayoutPanel38.SuspendLayout();
            tableLayoutPanel37.SuspendLayout();
            tableLayoutPanel36.SuspendLayout();
            tableLayoutPanel35.SuspendLayout();
            tableLayoutPanel34.SuspendLayout();
            tableLayoutPanel33.SuspendLayout();
            tableLayoutPanel32.SuspendLayout();
            tableLayoutPanel31.SuspendLayout();
            tableLayoutPanel29.SuspendLayout();
            tableLayoutPanel28.SuspendLayout();
            tableLayoutPanel27.SuspendLayout();
            tableLayoutPanel25.SuspendLayout();
            tableLayoutPanel18.SuspendLayout();
            tableLayoutPanel24.SuspendLayout();
            tableLayoutPanel23.SuspendLayout();
            tableLayoutPanel21.SuspendLayout();
            tableLayoutPanel20.SuspendLayout();
            tableLayoutPanel8.SuspendLayout();
            tableLayoutPanel7.SuspendLayout();
            tableLayoutPanel6.SuspendLayout();
            tableLayoutPanel9.SuspendLayout();
            tableLayoutPanel5.SuspendLayout();
            tableLayoutPanel116.SuspendLayout();
            tableLayoutPanel2.SuspendLayout();
            tableLayoutPanel4.SuspendLayout();
            tableLayoutPanel10.SuspendLayout();
            tableLayoutPanel12.SuspendLayout();
            tableLayoutPanel13.SuspendLayout();
            tableLayoutPanel14.SuspendLayout();
            tableLayoutPanel15.SuspendLayout();
            tableLayoutPanel16.SuspendLayout();
            tableLayoutPanel19.SuspendLayout();
            tableLayoutPanel59.SuspendLayout();
            tableLayoutPanel22.SuspendLayout();
            tableLayoutPanel61.SuspendLayout();
            tableLayoutPanel114.SuspendLayout();
            tableLayoutPanel11.SuspendLayout();
            SuspendLayout();
            // 
            // button1
            // 
            button1.Font = new Font("Segoe UI", 14F);
            button1.Location = new Point(237, 63);
            button1.Name = "button1";
            button1.Size = new Size(129, 40);
            button1.TabIndex = 1;
            button1.Text = "Add Client";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // button2
            // 
            button2.Font = new Font("Segoe UI", 14F);
            button2.Location = new Point(372, 63);
            button2.Name = "button2";
            button2.Size = new Size(221, 40);
            button2.TabIndex = 2;
            button2.Text = "Schedule Appointment";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 12F);
            label1.Location = new Point(46, 138);
            label1.Name = "label1";
            label1.Size = new Size(174, 21);
            label1.TabIndex = 4;
            label1.Text = "Appointment Scheduler";
            // 
            // tableLayoutPanel26
            // 
            tableLayoutPanel26.CellBorderStyle = TableLayoutPanelCellBorderStyle.Single;
            tableLayoutPanel26.ColumnCount = 6;
            tableLayoutPanel26.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 66F));
            tableLayoutPanel26.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 204F));
            tableLayoutPanel26.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 202F));
            tableLayoutPanel26.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 197F));
            tableLayoutPanel26.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 197F));
            tableLayoutPanel26.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 184F));
            tableLayoutPanel26.Controls.Add(label8, 5, 0);
            tableLayoutPanel26.Controls.Add(label7, 4, 0);
            tableLayoutPanel26.Controls.Add(label6, 3, 0);
            tableLayoutPanel26.Controls.Add(label5, 2, 0);
            tableLayoutPanel26.Controls.Add(label4, 1, 0);
            tableLayoutPanel26.Controls.Add(label3, 0, 0);
            tableLayoutPanel26.Location = new Point(45, 165);
            tableLayoutPanel26.Margin = new Padding(0);
            tableLayoutPanel26.Name = "tableLayoutPanel26";
            tableLayoutPanel26.RowCount = 1;
            tableLayoutPanel26.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
            tableLayoutPanel26.Size = new Size(1078, 30);
            tableLayoutPanel26.TabIndex = 5;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Segoe UI", 11F);
            label8.Location = new Point(872, 1);
            label8.Margin = new Padding(0);
            label8.Name = "label8";
            label8.Size = new Size(115, 20);
            label8.TabIndex = 13;
            label8.Text = "Surgery Room 2";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Segoe UI", 11F);
            label7.Location = new Point(674, 1);
            label7.Margin = new Padding(0);
            label7.Name = "label7";
            label7.Size = new Size(115, 20);
            label7.TabIndex = 13;
            label7.Text = "Surgery Room 1";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI", 11F);
            label6.Location = new Point(476, 1);
            label6.Margin = new Padding(0);
            label6.Name = "label6";
            label6.Size = new Size(101, 20);
            label6.TabIndex = 13;
            label6.Text = "Exam Room 3";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 11F);
            label5.Location = new Point(273, 1);
            label5.Margin = new Padding(0);
            label5.Name = "label5";
            label5.Size = new Size(101, 20);
            label5.TabIndex = 13;
            label5.Text = "Exam Room 2";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 11F);
            label4.Location = new Point(68, 1);
            label4.Margin = new Padding(0);
            label4.Name = "label4";
            label4.Size = new Size(101, 20);
            label4.TabIndex = 12;
            label4.Text = "Exam Room 1";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 11F);
            label3.Location = new Point(1, 1);
            label3.Margin = new Padding(0);
            label3.Name = "label3";
            label3.Size = new Size(42, 20);
            label3.TabIndex = 0;
            label3.Text = "Time";
            // 
            // MainSchedulerTable
            // 
            MainSchedulerTable.CellBorderStyle = TableLayoutPanelCellBorderStyle.Single;
            MainSchedulerTable.ColumnCount = 5;
            MainSchedulerTable.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 200F));
            MainSchedulerTable.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 200F));
            MainSchedulerTable.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 200F));
            MainSchedulerTable.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 200F));
            MainSchedulerTable.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 200F));
            MainSchedulerTable.Controls.Add(tableLayoutPanel51, 4, 8);
            MainSchedulerTable.Controls.Add(tableLayoutPanel50, 3, 8);
            MainSchedulerTable.Controls.Add(tableLayoutPanel49, 2, 8);
            MainSchedulerTable.Controls.Add(tableLayoutPanel48, 1, 8);
            MainSchedulerTable.Controls.Add(tableLayoutPanel47, 0, 8);
            MainSchedulerTable.Controls.Add(tableLayoutPanel46, 4, 7);
            MainSchedulerTable.Controls.Add(tableLayoutPanel45, 3, 7);
            MainSchedulerTable.Controls.Add(tableLayoutPanel44, 2, 7);
            MainSchedulerTable.Controls.Add(tableLayoutPanel43, 1, 7);
            MainSchedulerTable.Controls.Add(tableLayoutPanel42, 0, 7);
            MainSchedulerTable.Controls.Add(tableLayoutPanel41, 4, 6);
            MainSchedulerTable.Controls.Add(tableLayoutPanel40, 3, 6);
            MainSchedulerTable.Controls.Add(tableLayoutPanel39, 2, 6);
            MainSchedulerTable.Controls.Add(tableLayoutPanel38, 1, 6);
            MainSchedulerTable.Controls.Add(tableLayoutPanel37, 0, 6);
            MainSchedulerTable.Controls.Add(tableLayoutPanel36, 4, 5);
            MainSchedulerTable.Controls.Add(tableLayoutPanel35, 3, 5);
            MainSchedulerTable.Controls.Add(tableLayoutPanel34, 2, 5);
            MainSchedulerTable.Controls.Add(tableLayoutPanel33, 1, 5);
            MainSchedulerTable.Controls.Add(tableLayoutPanel32, 0, 5);
            MainSchedulerTable.Controls.Add(tableLayoutPanel31, 4, 4);
            MainSchedulerTable.Controls.Add(tableLayoutPanel29, 3, 4);
            MainSchedulerTable.Controls.Add(tableLayoutPanel28, 2, 4);
            MainSchedulerTable.Controls.Add(tableLayoutPanel27, 1, 4);
            MainSchedulerTable.Controls.Add(tableLayoutPanel25, 0, 4);
            MainSchedulerTable.Controls.Add(tableLayoutPanel18, 4, 2);
            MainSchedulerTable.Controls.Add(tableLayoutPanel24, 4, 3);
            MainSchedulerTable.Controls.Add(tableLayoutPanel23, 3, 3);
            MainSchedulerTable.Controls.Add(tableLayoutPanel21, 2, 3);
            MainSchedulerTable.Controls.Add(tableLayoutPanel20, 1, 3);
            MainSchedulerTable.Controls.Add(tableLayoutPanel8, 1, 1);
            MainSchedulerTable.Controls.Add(tableLayoutPanel7, 4, 0);
            MainSchedulerTable.Controls.Add(tableLayoutPanel6, 3, 0);
            MainSchedulerTable.Controls.Add(tableLayoutPanel9, 0, 2);
            MainSchedulerTable.Controls.Add(tableLayoutPanel5, 0, 0);
            MainSchedulerTable.Controls.Add(tableLayoutPanel116, 0, 1);
            MainSchedulerTable.Controls.Add(tableLayoutPanel2, 1, 0);
            MainSchedulerTable.Controls.Add(tableLayoutPanel4, 2, 0);
            MainSchedulerTable.Controls.Add(tableLayoutPanel10, 2, 1);
            MainSchedulerTable.Controls.Add(tableLayoutPanel12, 3, 1);
            MainSchedulerTable.Controls.Add(tableLayoutPanel13, 4, 1);
            MainSchedulerTable.Controls.Add(tableLayoutPanel14, 1, 2);
            MainSchedulerTable.Controls.Add(tableLayoutPanel15, 2, 2);
            MainSchedulerTable.Controls.Add(tableLayoutPanel16, 3, 2);
            MainSchedulerTable.Controls.Add(tableLayoutPanel19, 0, 3);
            MainSchedulerTable.Location = new Point(114, 198);
            MainSchedulerTable.Margin = new Padding(0);
            MainSchedulerTable.Name = "MainSchedulerTable";
            MainSchedulerTable.RowCount = 9;
            MainSchedulerTable.RowStyles.Add(new RowStyle(SizeType.Absolute, 100F));
            MainSchedulerTable.RowStyles.Add(new RowStyle(SizeType.Absolute, 100F));
            MainSchedulerTable.RowStyles.Add(new RowStyle(SizeType.Absolute, 100F));
            MainSchedulerTable.RowStyles.Add(new RowStyle(SizeType.Absolute, 100F));
            MainSchedulerTable.RowStyles.Add(new RowStyle(SizeType.Absolute, 100F));
            MainSchedulerTable.RowStyles.Add(new RowStyle(SizeType.Absolute, 100F));
            MainSchedulerTable.RowStyles.Add(new RowStyle(SizeType.Absolute, 100F));
            MainSchedulerTable.RowStyles.Add(new RowStyle(SizeType.Absolute, 100F));
            MainSchedulerTable.RowStyles.Add(new RowStyle(SizeType.Absolute, 100F));
            MainSchedulerTable.Size = new Size(1009, 915);
            MainSchedulerTable.TabIndex = 6;
            // 
            // tableLayoutPanel51
            // 
            tableLayoutPanel51.BackColor = Color.White;
            tableLayoutPanel51.CellBorderStyle = TableLayoutPanelCellBorderStyle.Single;
            tableLayoutPanel51.ColumnCount = 1;
            tableLayoutPanel51.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tableLayoutPanel51.Controls.Add(panel185, 0, 3);
            tableLayoutPanel51.Controls.Add(panel186, 0, 2);
            tableLayoutPanel51.Controls.Add(panel187, 0, 1);
            tableLayoutPanel51.Controls.Add(panel188, 0, 0);
            tableLayoutPanel51.Location = new Point(805, 809);
            tableLayoutPanel51.Margin = new Padding(0);
            tableLayoutPanel51.Name = "tableLayoutPanel51";
            tableLayoutPanel51.RowCount = 4;
            tableLayoutPanel51.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel51.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel51.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel51.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel51.Size = new Size(190, 90);
            tableLayoutPanel51.TabIndex = 99;
            // 
            // panel185
            // 
            panel185.Dock = DockStyle.Fill;
            panel185.Location = new Point(1, 67);
            panel185.Margin = new Padding(0);
            panel185.Name = "panel185";
            panel185.Size = new Size(188, 22);
            panel185.TabIndex = 18;
            // 
            // panel186
            // 
            panel186.Dock = DockStyle.Fill;
            panel186.Location = new Point(1, 45);
            panel186.Margin = new Padding(0);
            panel186.Name = "panel186";
            panel186.Size = new Size(188, 21);
            panel186.TabIndex = 17;
            // 
            // panel187
            // 
            panel187.Dock = DockStyle.Fill;
            panel187.Location = new Point(1, 23);
            panel187.Margin = new Padding(0);
            panel187.Name = "panel187";
            panel187.Size = new Size(188, 21);
            panel187.TabIndex = 16;
            // 
            // panel188
            // 
            panel188.Dock = DockStyle.Fill;
            panel188.Location = new Point(1, 1);
            panel188.Margin = new Padding(0);
            panel188.Name = "panel188";
            panel188.Size = new Size(188, 21);
            panel188.TabIndex = 15;
            // 
            // tableLayoutPanel50
            // 
            tableLayoutPanel50.BackColor = Color.White;
            tableLayoutPanel50.CellBorderStyle = TableLayoutPanelCellBorderStyle.Single;
            tableLayoutPanel50.ColumnCount = 1;
            tableLayoutPanel50.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tableLayoutPanel50.Controls.Add(panel181, 0, 3);
            tableLayoutPanel50.Controls.Add(panel182, 0, 2);
            tableLayoutPanel50.Controls.Add(panel183, 0, 1);
            tableLayoutPanel50.Controls.Add(panel184, 0, 0);
            tableLayoutPanel50.Location = new Point(604, 809);
            tableLayoutPanel50.Margin = new Padding(0);
            tableLayoutPanel50.Name = "tableLayoutPanel50";
            tableLayoutPanel50.RowCount = 4;
            tableLayoutPanel50.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel50.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel50.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel50.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel50.Size = new Size(190, 90);
            tableLayoutPanel50.TabIndex = 98;
            // 
            // panel181
            // 
            panel181.Dock = DockStyle.Fill;
            panel181.Location = new Point(1, 67);
            panel181.Margin = new Padding(0);
            panel181.Name = "panel181";
            panel181.Size = new Size(188, 22);
            panel181.TabIndex = 18;
            // 
            // panel182
            // 
            panel182.Dock = DockStyle.Fill;
            panel182.Location = new Point(1, 45);
            panel182.Margin = new Padding(0);
            panel182.Name = "panel182";
            panel182.Size = new Size(188, 21);
            panel182.TabIndex = 17;
            // 
            // panel183
            // 
            panel183.Dock = DockStyle.Fill;
            panel183.Location = new Point(1, 23);
            panel183.Margin = new Padding(0);
            panel183.Name = "panel183";
            panel183.Size = new Size(188, 21);
            panel183.TabIndex = 16;
            // 
            // panel184
            // 
            panel184.Dock = DockStyle.Fill;
            panel184.Location = new Point(1, 1);
            panel184.Margin = new Padding(0);
            panel184.Name = "panel184";
            panel184.Size = new Size(188, 21);
            panel184.TabIndex = 15;
            // 
            // tableLayoutPanel49
            // 
            tableLayoutPanel49.BackColor = Color.White;
            tableLayoutPanel49.CellBorderStyle = TableLayoutPanelCellBorderStyle.Single;
            tableLayoutPanel49.ColumnCount = 1;
            tableLayoutPanel49.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tableLayoutPanel49.Controls.Add(panel177, 0, 3);
            tableLayoutPanel49.Controls.Add(panel178, 0, 2);
            tableLayoutPanel49.Controls.Add(panel179, 0, 1);
            tableLayoutPanel49.Controls.Add(panel180, 0, 0);
            tableLayoutPanel49.Location = new Point(403, 809);
            tableLayoutPanel49.Margin = new Padding(0);
            tableLayoutPanel49.Name = "tableLayoutPanel49";
            tableLayoutPanel49.RowCount = 4;
            tableLayoutPanel49.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel49.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel49.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel49.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel49.Size = new Size(190, 90);
            tableLayoutPanel49.TabIndex = 97;
            // 
            // panel177
            // 
            panel177.Dock = DockStyle.Fill;
            panel177.Location = new Point(1, 67);
            panel177.Margin = new Padding(0);
            panel177.Name = "panel177";
            panel177.Size = new Size(188, 22);
            panel177.TabIndex = 18;
            // 
            // panel178
            // 
            panel178.Dock = DockStyle.Fill;
            panel178.Location = new Point(1, 45);
            panel178.Margin = new Padding(0);
            panel178.Name = "panel178";
            panel178.Size = new Size(188, 21);
            panel178.TabIndex = 17;
            // 
            // panel179
            // 
            panel179.Dock = DockStyle.Fill;
            panel179.Location = new Point(1, 23);
            panel179.Margin = new Padding(0);
            panel179.Name = "panel179";
            panel179.Size = new Size(188, 21);
            panel179.TabIndex = 16;
            // 
            // panel180
            // 
            panel180.Dock = DockStyle.Fill;
            panel180.Location = new Point(1, 1);
            panel180.Margin = new Padding(0);
            panel180.Name = "panel180";
            panel180.Size = new Size(188, 21);
            panel180.TabIndex = 15;
            // 
            // tableLayoutPanel48
            // 
            tableLayoutPanel48.BackColor = Color.White;
            tableLayoutPanel48.CellBorderStyle = TableLayoutPanelCellBorderStyle.Single;
            tableLayoutPanel48.ColumnCount = 1;
            tableLayoutPanel48.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tableLayoutPanel48.Controls.Add(panel173, 0, 3);
            tableLayoutPanel48.Controls.Add(panel174, 0, 2);
            tableLayoutPanel48.Controls.Add(panel175, 0, 1);
            tableLayoutPanel48.Controls.Add(panel176, 0, 0);
            tableLayoutPanel48.Location = new Point(202, 809);
            tableLayoutPanel48.Margin = new Padding(0);
            tableLayoutPanel48.Name = "tableLayoutPanel48";
            tableLayoutPanel48.RowCount = 4;
            tableLayoutPanel48.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel48.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel48.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel48.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel48.Size = new Size(190, 90);
            tableLayoutPanel48.TabIndex = 96;
            // 
            // panel173
            // 
            panel173.Dock = DockStyle.Fill;
            panel173.Location = new Point(1, 67);
            panel173.Margin = new Padding(0);
            panel173.Name = "panel173";
            panel173.Size = new Size(188, 22);
            panel173.TabIndex = 18;
            // 
            // panel174
            // 
            panel174.Dock = DockStyle.Fill;
            panel174.Location = new Point(1, 45);
            panel174.Margin = new Padding(0);
            panel174.Name = "panel174";
            panel174.Size = new Size(188, 21);
            panel174.TabIndex = 17;
            // 
            // panel175
            // 
            panel175.Dock = DockStyle.Fill;
            panel175.Location = new Point(1, 23);
            panel175.Margin = new Padding(0);
            panel175.Name = "panel175";
            panel175.Size = new Size(188, 21);
            panel175.TabIndex = 16;
            // 
            // panel176
            // 
            panel176.Dock = DockStyle.Fill;
            panel176.Location = new Point(1, 1);
            panel176.Margin = new Padding(0);
            panel176.Name = "panel176";
            panel176.Size = new Size(188, 21);
            panel176.TabIndex = 15;
            // 
            // tableLayoutPanel47
            // 
            tableLayoutPanel47.BackColor = Color.White;
            tableLayoutPanel47.CellBorderStyle = TableLayoutPanelCellBorderStyle.Single;
            tableLayoutPanel47.ColumnCount = 1;
            tableLayoutPanel47.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tableLayoutPanel47.Controls.Add(panel169, 0, 3);
            tableLayoutPanel47.Controls.Add(panel170, 0, 2);
            tableLayoutPanel47.Controls.Add(panel171, 0, 1);
            tableLayoutPanel47.Controls.Add(panel172, 0, 0);
            tableLayoutPanel47.Location = new Point(1, 809);
            tableLayoutPanel47.Margin = new Padding(0);
            tableLayoutPanel47.Name = "tableLayoutPanel47";
            tableLayoutPanel47.RowCount = 4;
            tableLayoutPanel47.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel47.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel47.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel47.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel47.Size = new Size(190, 90);
            tableLayoutPanel47.TabIndex = 95;
            // 
            // panel169
            // 
            panel169.Dock = DockStyle.Fill;
            panel169.Location = new Point(1, 67);
            panel169.Margin = new Padding(0);
            panel169.Name = "panel169";
            panel169.Size = new Size(188, 22);
            panel169.TabIndex = 18;
            // 
            // panel170
            // 
            panel170.Dock = DockStyle.Fill;
            panel170.Location = new Point(1, 45);
            panel170.Margin = new Padding(0);
            panel170.Name = "panel170";
            panel170.Size = new Size(188, 21);
            panel170.TabIndex = 17;
            // 
            // panel171
            // 
            panel171.Dock = DockStyle.Fill;
            panel171.Location = new Point(1, 23);
            panel171.Margin = new Padding(0);
            panel171.Name = "panel171";
            panel171.Size = new Size(188, 21);
            panel171.TabIndex = 16;
            // 
            // panel172
            // 
            panel172.Dock = DockStyle.Fill;
            panel172.Location = new Point(1, 1);
            panel172.Margin = new Padding(0);
            panel172.Name = "panel172";
            panel172.Size = new Size(188, 21);
            panel172.TabIndex = 15;
            // 
            // tableLayoutPanel46
            // 
            tableLayoutPanel46.BackColor = Color.White;
            tableLayoutPanel46.CellBorderStyle = TableLayoutPanelCellBorderStyle.Single;
            tableLayoutPanel46.ColumnCount = 1;
            tableLayoutPanel46.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tableLayoutPanel46.Controls.Add(panel165, 0, 3);
            tableLayoutPanel46.Controls.Add(panel166, 0, 2);
            tableLayoutPanel46.Controls.Add(panel167, 0, 1);
            tableLayoutPanel46.Controls.Add(panel168, 0, 0);
            tableLayoutPanel46.Location = new Point(805, 708);
            tableLayoutPanel46.Margin = new Padding(0);
            tableLayoutPanel46.Name = "tableLayoutPanel46";
            tableLayoutPanel46.RowCount = 4;
            tableLayoutPanel46.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel46.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel46.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel46.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel46.Size = new Size(190, 90);
            tableLayoutPanel46.TabIndex = 94;
            // 
            // panel165
            // 
            panel165.Dock = DockStyle.Fill;
            panel165.Location = new Point(1, 67);
            panel165.Margin = new Padding(0);
            panel165.Name = "panel165";
            panel165.Size = new Size(188, 22);
            panel165.TabIndex = 18;
            // 
            // panel166
            // 
            panel166.Dock = DockStyle.Fill;
            panel166.Location = new Point(1, 45);
            panel166.Margin = new Padding(0);
            panel166.Name = "panel166";
            panel166.Size = new Size(188, 21);
            panel166.TabIndex = 17;
            // 
            // panel167
            // 
            panel167.Dock = DockStyle.Fill;
            panel167.Location = new Point(1, 23);
            panel167.Margin = new Padding(0);
            panel167.Name = "panel167";
            panel167.Size = new Size(188, 21);
            panel167.TabIndex = 16;
            // 
            // panel168
            // 
            panel168.Dock = DockStyle.Fill;
            panel168.Location = new Point(1, 1);
            panel168.Margin = new Padding(0);
            panel168.Name = "panel168";
            panel168.Size = new Size(188, 21);
            panel168.TabIndex = 15;
            // 
            // tableLayoutPanel45
            // 
            tableLayoutPanel45.BackColor = Color.White;
            tableLayoutPanel45.CellBorderStyle = TableLayoutPanelCellBorderStyle.Single;
            tableLayoutPanel45.ColumnCount = 1;
            tableLayoutPanel45.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tableLayoutPanel45.Controls.Add(panel161, 0, 3);
            tableLayoutPanel45.Controls.Add(panel162, 0, 2);
            tableLayoutPanel45.Controls.Add(panel163, 0, 1);
            tableLayoutPanel45.Controls.Add(panel164, 0, 0);
            tableLayoutPanel45.Location = new Point(604, 708);
            tableLayoutPanel45.Margin = new Padding(0);
            tableLayoutPanel45.Name = "tableLayoutPanel45";
            tableLayoutPanel45.RowCount = 4;
            tableLayoutPanel45.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel45.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel45.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel45.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel45.Size = new Size(190, 90);
            tableLayoutPanel45.TabIndex = 93;
            // 
            // panel161
            // 
            panel161.Dock = DockStyle.Fill;
            panel161.Location = new Point(1, 67);
            panel161.Margin = new Padding(0);
            panel161.Name = "panel161";
            panel161.Size = new Size(188, 22);
            panel161.TabIndex = 18;
            // 
            // panel162
            // 
            panel162.Dock = DockStyle.Fill;
            panel162.Location = new Point(1, 45);
            panel162.Margin = new Padding(0);
            panel162.Name = "panel162";
            panel162.Size = new Size(188, 21);
            panel162.TabIndex = 17;
            // 
            // panel163
            // 
            panel163.Dock = DockStyle.Fill;
            panel163.Location = new Point(1, 23);
            panel163.Margin = new Padding(0);
            panel163.Name = "panel163";
            panel163.Size = new Size(188, 21);
            panel163.TabIndex = 16;
            // 
            // panel164
            // 
            panel164.Dock = DockStyle.Fill;
            panel164.Location = new Point(1, 1);
            panel164.Margin = new Padding(0);
            panel164.Name = "panel164";
            panel164.Size = new Size(188, 21);
            panel164.TabIndex = 15;
            // 
            // tableLayoutPanel44
            // 
            tableLayoutPanel44.BackColor = Color.White;
            tableLayoutPanel44.CellBorderStyle = TableLayoutPanelCellBorderStyle.Single;
            tableLayoutPanel44.ColumnCount = 1;
            tableLayoutPanel44.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tableLayoutPanel44.Controls.Add(panel157, 0, 3);
            tableLayoutPanel44.Controls.Add(panel158, 0, 2);
            tableLayoutPanel44.Controls.Add(panel159, 0, 1);
            tableLayoutPanel44.Controls.Add(panel160, 0, 0);
            tableLayoutPanel44.Location = new Point(403, 708);
            tableLayoutPanel44.Margin = new Padding(0);
            tableLayoutPanel44.Name = "tableLayoutPanel44";
            tableLayoutPanel44.RowCount = 4;
            tableLayoutPanel44.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel44.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel44.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel44.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel44.Size = new Size(190, 90);
            tableLayoutPanel44.TabIndex = 92;
            // 
            // panel157
            // 
            panel157.Dock = DockStyle.Fill;
            panel157.Location = new Point(1, 67);
            panel157.Margin = new Padding(0);
            panel157.Name = "panel157";
            panel157.Size = new Size(188, 22);
            panel157.TabIndex = 18;
            // 
            // panel158
            // 
            panel158.Dock = DockStyle.Fill;
            panel158.Location = new Point(1, 45);
            panel158.Margin = new Padding(0);
            panel158.Name = "panel158";
            panel158.Size = new Size(188, 21);
            panel158.TabIndex = 17;
            // 
            // panel159
            // 
            panel159.Dock = DockStyle.Fill;
            panel159.Location = new Point(1, 23);
            panel159.Margin = new Padding(0);
            panel159.Name = "panel159";
            panel159.Size = new Size(188, 21);
            panel159.TabIndex = 16;
            // 
            // panel160
            // 
            panel160.Dock = DockStyle.Fill;
            panel160.Location = new Point(1, 1);
            panel160.Margin = new Padding(0);
            panel160.Name = "panel160";
            panel160.Size = new Size(188, 21);
            panel160.TabIndex = 15;
            // 
            // tableLayoutPanel43
            // 
            tableLayoutPanel43.BackColor = Color.White;
            tableLayoutPanel43.CellBorderStyle = TableLayoutPanelCellBorderStyle.Single;
            tableLayoutPanel43.ColumnCount = 1;
            tableLayoutPanel43.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tableLayoutPanel43.Controls.Add(panel153, 0, 3);
            tableLayoutPanel43.Controls.Add(panel154, 0, 2);
            tableLayoutPanel43.Controls.Add(panel155, 0, 1);
            tableLayoutPanel43.Controls.Add(panel156, 0, 0);
            tableLayoutPanel43.Location = new Point(202, 708);
            tableLayoutPanel43.Margin = new Padding(0);
            tableLayoutPanel43.Name = "tableLayoutPanel43";
            tableLayoutPanel43.RowCount = 4;
            tableLayoutPanel43.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel43.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel43.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel43.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel43.Size = new Size(190, 90);
            tableLayoutPanel43.TabIndex = 91;
            // 
            // panel153
            // 
            panel153.Dock = DockStyle.Fill;
            panel153.Location = new Point(1, 67);
            panel153.Margin = new Padding(0);
            panel153.Name = "panel153";
            panel153.Size = new Size(188, 22);
            panel153.TabIndex = 18;
            // 
            // panel154
            // 
            panel154.Dock = DockStyle.Fill;
            panel154.Location = new Point(1, 45);
            panel154.Margin = new Padding(0);
            panel154.Name = "panel154";
            panel154.Size = new Size(188, 21);
            panel154.TabIndex = 17;
            // 
            // panel155
            // 
            panel155.Dock = DockStyle.Fill;
            panel155.Location = new Point(1, 23);
            panel155.Margin = new Padding(0);
            panel155.Name = "panel155";
            panel155.Size = new Size(188, 21);
            panel155.TabIndex = 16;
            // 
            // panel156
            // 
            panel156.Dock = DockStyle.Fill;
            panel156.Location = new Point(1, 1);
            panel156.Margin = new Padding(0);
            panel156.Name = "panel156";
            panel156.Size = new Size(188, 21);
            panel156.TabIndex = 15;
            // 
            // tableLayoutPanel42
            // 
            tableLayoutPanel42.BackColor = Color.White;
            tableLayoutPanel42.CellBorderStyle = TableLayoutPanelCellBorderStyle.Single;
            tableLayoutPanel42.ColumnCount = 1;
            tableLayoutPanel42.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tableLayoutPanel42.Controls.Add(panel149, 0, 3);
            tableLayoutPanel42.Controls.Add(panel150, 0, 2);
            tableLayoutPanel42.Controls.Add(panel151, 0, 1);
            tableLayoutPanel42.Controls.Add(panel152, 0, 0);
            tableLayoutPanel42.Location = new Point(1, 708);
            tableLayoutPanel42.Margin = new Padding(0);
            tableLayoutPanel42.Name = "tableLayoutPanel42";
            tableLayoutPanel42.RowCount = 4;
            tableLayoutPanel42.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel42.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel42.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel42.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel42.Size = new Size(190, 90);
            tableLayoutPanel42.TabIndex = 90;
            // 
            // panel149
            // 
            panel149.Dock = DockStyle.Fill;
            panel149.Location = new Point(1, 67);
            panel149.Margin = new Padding(0);
            panel149.Name = "panel149";
            panel149.Size = new Size(188, 22);
            panel149.TabIndex = 18;
            // 
            // panel150
            // 
            panel150.Dock = DockStyle.Fill;
            panel150.Location = new Point(1, 45);
            panel150.Margin = new Padding(0);
            panel150.Name = "panel150";
            panel150.Size = new Size(188, 21);
            panel150.TabIndex = 17;
            // 
            // panel151
            // 
            panel151.Dock = DockStyle.Fill;
            panel151.Location = new Point(1, 23);
            panel151.Margin = new Padding(0);
            panel151.Name = "panel151";
            panel151.Size = new Size(188, 21);
            panel151.TabIndex = 16;
            // 
            // panel152
            // 
            panel152.Dock = DockStyle.Fill;
            panel152.Location = new Point(1, 1);
            panel152.Margin = new Padding(0);
            panel152.Name = "panel152";
            panel152.Size = new Size(188, 21);
            panel152.TabIndex = 15;
            // 
            // tableLayoutPanel41
            // 
            tableLayoutPanel41.BackColor = Color.White;
            tableLayoutPanel41.CellBorderStyle = TableLayoutPanelCellBorderStyle.Single;
            tableLayoutPanel41.ColumnCount = 1;
            tableLayoutPanel41.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tableLayoutPanel41.Controls.Add(panel145, 0, 3);
            tableLayoutPanel41.Controls.Add(panel146, 0, 2);
            tableLayoutPanel41.Controls.Add(panel147, 0, 1);
            tableLayoutPanel41.Controls.Add(panel148, 0, 0);
            tableLayoutPanel41.Location = new Point(805, 607);
            tableLayoutPanel41.Margin = new Padding(0);
            tableLayoutPanel41.Name = "tableLayoutPanel41";
            tableLayoutPanel41.RowCount = 4;
            tableLayoutPanel41.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel41.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel41.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel41.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel41.Size = new Size(190, 90);
            tableLayoutPanel41.TabIndex = 89;
            // 
            // panel145
            // 
            panel145.Dock = DockStyle.Fill;
            panel145.Location = new Point(1, 67);
            panel145.Margin = new Padding(0);
            panel145.Name = "panel145";
            panel145.Size = new Size(188, 22);
            panel145.TabIndex = 18;
            // 
            // panel146
            // 
            panel146.Dock = DockStyle.Fill;
            panel146.Location = new Point(1, 45);
            panel146.Margin = new Padding(0);
            panel146.Name = "panel146";
            panel146.Size = new Size(188, 21);
            panel146.TabIndex = 17;
            // 
            // panel147
            // 
            panel147.Dock = DockStyle.Fill;
            panel147.Location = new Point(1, 23);
            panel147.Margin = new Padding(0);
            panel147.Name = "panel147";
            panel147.Size = new Size(188, 21);
            panel147.TabIndex = 16;
            // 
            // panel148
            // 
            panel148.Dock = DockStyle.Fill;
            panel148.Location = new Point(1, 1);
            panel148.Margin = new Padding(0);
            panel148.Name = "panel148";
            panel148.Size = new Size(188, 21);
            panel148.TabIndex = 15;
            // 
            // tableLayoutPanel40
            // 
            tableLayoutPanel40.BackColor = Color.White;
            tableLayoutPanel40.CellBorderStyle = TableLayoutPanelCellBorderStyle.Single;
            tableLayoutPanel40.ColumnCount = 1;
            tableLayoutPanel40.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tableLayoutPanel40.Controls.Add(panel141, 0, 3);
            tableLayoutPanel40.Controls.Add(panel142, 0, 2);
            tableLayoutPanel40.Controls.Add(panel143, 0, 1);
            tableLayoutPanel40.Controls.Add(panel144, 0, 0);
            tableLayoutPanel40.Location = new Point(604, 607);
            tableLayoutPanel40.Margin = new Padding(0);
            tableLayoutPanel40.Name = "tableLayoutPanel40";
            tableLayoutPanel40.RowCount = 4;
            tableLayoutPanel40.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel40.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel40.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel40.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel40.Size = new Size(190, 90);
            tableLayoutPanel40.TabIndex = 88;
            // 
            // panel141
            // 
            panel141.Dock = DockStyle.Fill;
            panel141.Location = new Point(1, 67);
            panel141.Margin = new Padding(0);
            panel141.Name = "panel141";
            panel141.Size = new Size(188, 22);
            panel141.TabIndex = 18;
            // 
            // panel142
            // 
            panel142.Dock = DockStyle.Fill;
            panel142.Location = new Point(1, 45);
            panel142.Margin = new Padding(0);
            panel142.Name = "panel142";
            panel142.Size = new Size(188, 21);
            panel142.TabIndex = 17;
            // 
            // panel143
            // 
            panel143.Dock = DockStyle.Fill;
            panel143.Location = new Point(1, 23);
            panel143.Margin = new Padding(0);
            panel143.Name = "panel143";
            panel143.Size = new Size(188, 21);
            panel143.TabIndex = 16;
            // 
            // panel144
            // 
            panel144.Dock = DockStyle.Fill;
            panel144.Location = new Point(1, 1);
            panel144.Margin = new Padding(0);
            panel144.Name = "panel144";
            panel144.Size = new Size(188, 21);
            panel144.TabIndex = 15;
            // 
            // tableLayoutPanel39
            // 
            tableLayoutPanel39.BackColor = Color.White;
            tableLayoutPanel39.CellBorderStyle = TableLayoutPanelCellBorderStyle.Single;
            tableLayoutPanel39.ColumnCount = 1;
            tableLayoutPanel39.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tableLayoutPanel39.Controls.Add(panel137, 0, 3);
            tableLayoutPanel39.Controls.Add(panel138, 0, 2);
            tableLayoutPanel39.Controls.Add(panel139, 0, 1);
            tableLayoutPanel39.Controls.Add(panel140, 0, 0);
            tableLayoutPanel39.Location = new Point(403, 607);
            tableLayoutPanel39.Margin = new Padding(0);
            tableLayoutPanel39.Name = "tableLayoutPanel39";
            tableLayoutPanel39.RowCount = 4;
            tableLayoutPanel39.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel39.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel39.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel39.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel39.Size = new Size(190, 90);
            tableLayoutPanel39.TabIndex = 87;
            // 
            // panel137
            // 
            panel137.Dock = DockStyle.Fill;
            panel137.Location = new Point(1, 67);
            panel137.Margin = new Padding(0);
            panel137.Name = "panel137";
            panel137.Size = new Size(188, 22);
            panel137.TabIndex = 18;
            // 
            // panel138
            // 
            panel138.Dock = DockStyle.Fill;
            panel138.Location = new Point(1, 45);
            panel138.Margin = new Padding(0);
            panel138.Name = "panel138";
            panel138.Size = new Size(188, 21);
            panel138.TabIndex = 17;
            // 
            // panel139
            // 
            panel139.Dock = DockStyle.Fill;
            panel139.Location = new Point(1, 23);
            panel139.Margin = new Padding(0);
            panel139.Name = "panel139";
            panel139.Size = new Size(188, 21);
            panel139.TabIndex = 16;
            // 
            // panel140
            // 
            panel140.Dock = DockStyle.Fill;
            panel140.Location = new Point(1, 1);
            panel140.Margin = new Padding(0);
            panel140.Name = "panel140";
            panel140.Size = new Size(188, 21);
            panel140.TabIndex = 15;
            // 
            // tableLayoutPanel38
            // 
            tableLayoutPanel38.BackColor = Color.White;
            tableLayoutPanel38.CellBorderStyle = TableLayoutPanelCellBorderStyle.Single;
            tableLayoutPanel38.ColumnCount = 1;
            tableLayoutPanel38.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tableLayoutPanel38.Controls.Add(panel133, 0, 3);
            tableLayoutPanel38.Controls.Add(panel134, 0, 2);
            tableLayoutPanel38.Controls.Add(panel135, 0, 1);
            tableLayoutPanel38.Controls.Add(panel136, 0, 0);
            tableLayoutPanel38.Location = new Point(202, 607);
            tableLayoutPanel38.Margin = new Padding(0);
            tableLayoutPanel38.Name = "tableLayoutPanel38";
            tableLayoutPanel38.RowCount = 4;
            tableLayoutPanel38.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel38.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel38.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel38.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel38.Size = new Size(190, 90);
            tableLayoutPanel38.TabIndex = 86;
            // 
            // panel133
            // 
            panel133.Dock = DockStyle.Fill;
            panel133.Location = new Point(1, 67);
            panel133.Margin = new Padding(0);
            panel133.Name = "panel133";
            panel133.Size = new Size(188, 22);
            panel133.TabIndex = 18;
            // 
            // panel134
            // 
            panel134.Dock = DockStyle.Fill;
            panel134.Location = new Point(1, 45);
            panel134.Margin = new Padding(0);
            panel134.Name = "panel134";
            panel134.Size = new Size(188, 21);
            panel134.TabIndex = 17;
            // 
            // panel135
            // 
            panel135.Dock = DockStyle.Fill;
            panel135.Location = new Point(1, 23);
            panel135.Margin = new Padding(0);
            panel135.Name = "panel135";
            panel135.Size = new Size(188, 21);
            panel135.TabIndex = 16;
            // 
            // panel136
            // 
            panel136.Dock = DockStyle.Fill;
            panel136.Location = new Point(1, 1);
            panel136.Margin = new Padding(0);
            panel136.Name = "panel136";
            panel136.Size = new Size(188, 21);
            panel136.TabIndex = 15;
            // 
            // tableLayoutPanel37
            // 
            tableLayoutPanel37.BackColor = Color.White;
            tableLayoutPanel37.CellBorderStyle = TableLayoutPanelCellBorderStyle.Single;
            tableLayoutPanel37.ColumnCount = 1;
            tableLayoutPanel37.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tableLayoutPanel37.Controls.Add(panel129, 0, 3);
            tableLayoutPanel37.Controls.Add(panel130, 0, 2);
            tableLayoutPanel37.Controls.Add(panel131, 0, 1);
            tableLayoutPanel37.Controls.Add(panel132, 0, 0);
            tableLayoutPanel37.Location = new Point(1, 607);
            tableLayoutPanel37.Margin = new Padding(0);
            tableLayoutPanel37.Name = "tableLayoutPanel37";
            tableLayoutPanel37.RowCount = 4;
            tableLayoutPanel37.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel37.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel37.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel37.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel37.Size = new Size(190, 90);
            tableLayoutPanel37.TabIndex = 85;
            // 
            // panel129
            // 
            panel129.Dock = DockStyle.Fill;
            panel129.Location = new Point(1, 67);
            panel129.Margin = new Padding(0);
            panel129.Name = "panel129";
            panel129.Size = new Size(188, 22);
            panel129.TabIndex = 18;
            // 
            // panel130
            // 
            panel130.Dock = DockStyle.Fill;
            panel130.Location = new Point(1, 45);
            panel130.Margin = new Padding(0);
            panel130.Name = "panel130";
            panel130.Size = new Size(188, 21);
            panel130.TabIndex = 17;
            // 
            // panel131
            // 
            panel131.Dock = DockStyle.Fill;
            panel131.Location = new Point(1, 23);
            panel131.Margin = new Padding(0);
            panel131.Name = "panel131";
            panel131.Size = new Size(188, 21);
            panel131.TabIndex = 16;
            // 
            // panel132
            // 
            panel132.Dock = DockStyle.Fill;
            panel132.Location = new Point(1, 1);
            panel132.Margin = new Padding(0);
            panel132.Name = "panel132";
            panel132.Size = new Size(188, 21);
            panel132.TabIndex = 15;
            // 
            // tableLayoutPanel36
            // 
            tableLayoutPanel36.BackColor = Color.White;
            tableLayoutPanel36.CellBorderStyle = TableLayoutPanelCellBorderStyle.Single;
            tableLayoutPanel36.ColumnCount = 1;
            tableLayoutPanel36.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tableLayoutPanel36.Controls.Add(panel125, 0, 3);
            tableLayoutPanel36.Controls.Add(panel126, 0, 2);
            tableLayoutPanel36.Controls.Add(panel127, 0, 1);
            tableLayoutPanel36.Controls.Add(panel128, 0, 0);
            tableLayoutPanel36.Location = new Point(805, 506);
            tableLayoutPanel36.Margin = new Padding(0);
            tableLayoutPanel36.Name = "tableLayoutPanel36";
            tableLayoutPanel36.RowCount = 4;
            tableLayoutPanel36.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel36.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel36.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel36.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel36.Size = new Size(190, 90);
            tableLayoutPanel36.TabIndex = 84;
            // 
            // panel125
            // 
            panel125.Dock = DockStyle.Fill;
            panel125.Location = new Point(1, 67);
            panel125.Margin = new Padding(0);
            panel125.Name = "panel125";
            panel125.Size = new Size(188, 22);
            panel125.TabIndex = 18;
            // 
            // panel126
            // 
            panel126.Dock = DockStyle.Fill;
            panel126.Location = new Point(1, 45);
            panel126.Margin = new Padding(0);
            panel126.Name = "panel126";
            panel126.Size = new Size(188, 21);
            panel126.TabIndex = 17;
            // 
            // panel127
            // 
            panel127.Dock = DockStyle.Fill;
            panel127.Location = new Point(1, 23);
            panel127.Margin = new Padding(0);
            panel127.Name = "panel127";
            panel127.Size = new Size(188, 21);
            panel127.TabIndex = 16;
            // 
            // panel128
            // 
            panel128.Dock = DockStyle.Fill;
            panel128.Location = new Point(1, 1);
            panel128.Margin = new Padding(0);
            panel128.Name = "panel128";
            panel128.Size = new Size(188, 21);
            panel128.TabIndex = 15;
            // 
            // tableLayoutPanel35
            // 
            tableLayoutPanel35.BackColor = Color.White;
            tableLayoutPanel35.CellBorderStyle = TableLayoutPanelCellBorderStyle.Single;
            tableLayoutPanel35.ColumnCount = 1;
            tableLayoutPanel35.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tableLayoutPanel35.Controls.Add(panel121, 0, 3);
            tableLayoutPanel35.Controls.Add(panel122, 0, 2);
            tableLayoutPanel35.Controls.Add(panel123, 0, 1);
            tableLayoutPanel35.Controls.Add(panel124, 0, 0);
            tableLayoutPanel35.Location = new Point(604, 506);
            tableLayoutPanel35.Margin = new Padding(0);
            tableLayoutPanel35.Name = "tableLayoutPanel35";
            tableLayoutPanel35.RowCount = 4;
            tableLayoutPanel35.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel35.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel35.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel35.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel35.Size = new Size(190, 90);
            tableLayoutPanel35.TabIndex = 83;
            // 
            // panel121
            // 
            panel121.Dock = DockStyle.Fill;
            panel121.Location = new Point(1, 67);
            panel121.Margin = new Padding(0);
            panel121.Name = "panel121";
            panel121.Size = new Size(188, 22);
            panel121.TabIndex = 18;
            // 
            // panel122
            // 
            panel122.Dock = DockStyle.Fill;
            panel122.Location = new Point(1, 45);
            panel122.Margin = new Padding(0);
            panel122.Name = "panel122";
            panel122.Size = new Size(188, 21);
            panel122.TabIndex = 17;
            // 
            // panel123
            // 
            panel123.Dock = DockStyle.Fill;
            panel123.Location = new Point(1, 23);
            panel123.Margin = new Padding(0);
            panel123.Name = "panel123";
            panel123.Size = new Size(188, 21);
            panel123.TabIndex = 16;
            // 
            // panel124
            // 
            panel124.Dock = DockStyle.Fill;
            panel124.Location = new Point(1, 1);
            panel124.Margin = new Padding(0);
            panel124.Name = "panel124";
            panel124.Size = new Size(188, 21);
            panel124.TabIndex = 15;
            // 
            // tableLayoutPanel34
            // 
            tableLayoutPanel34.BackColor = Color.White;
            tableLayoutPanel34.CellBorderStyle = TableLayoutPanelCellBorderStyle.Single;
            tableLayoutPanel34.ColumnCount = 1;
            tableLayoutPanel34.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tableLayoutPanel34.Controls.Add(panel117, 0, 3);
            tableLayoutPanel34.Controls.Add(panel118, 0, 2);
            tableLayoutPanel34.Controls.Add(panel119, 0, 1);
            tableLayoutPanel34.Controls.Add(panel120, 0, 0);
            tableLayoutPanel34.Location = new Point(403, 506);
            tableLayoutPanel34.Margin = new Padding(0);
            tableLayoutPanel34.Name = "tableLayoutPanel34";
            tableLayoutPanel34.RowCount = 4;
            tableLayoutPanel34.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel34.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel34.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel34.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel34.Size = new Size(190, 90);
            tableLayoutPanel34.TabIndex = 82;
            // 
            // panel117
            // 
            panel117.Dock = DockStyle.Fill;
            panel117.Location = new Point(1, 67);
            panel117.Margin = new Padding(0);
            panel117.Name = "panel117";
            panel117.Size = new Size(188, 22);
            panel117.TabIndex = 18;
            // 
            // panel118
            // 
            panel118.Dock = DockStyle.Fill;
            panel118.Location = new Point(1, 45);
            panel118.Margin = new Padding(0);
            panel118.Name = "panel118";
            panel118.Size = new Size(188, 21);
            panel118.TabIndex = 17;
            // 
            // panel119
            // 
            panel119.Dock = DockStyle.Fill;
            panel119.Location = new Point(1, 23);
            panel119.Margin = new Padding(0);
            panel119.Name = "panel119";
            panel119.Size = new Size(188, 21);
            panel119.TabIndex = 16;
            // 
            // panel120
            // 
            panel120.Dock = DockStyle.Fill;
            panel120.Location = new Point(1, 1);
            panel120.Margin = new Padding(0);
            panel120.Name = "panel120";
            panel120.Size = new Size(188, 21);
            panel120.TabIndex = 15;
            // 
            // tableLayoutPanel33
            // 
            tableLayoutPanel33.BackColor = Color.White;
            tableLayoutPanel33.CellBorderStyle = TableLayoutPanelCellBorderStyle.Single;
            tableLayoutPanel33.ColumnCount = 1;
            tableLayoutPanel33.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tableLayoutPanel33.Controls.Add(panel113, 0, 3);
            tableLayoutPanel33.Controls.Add(panel114, 0, 2);
            tableLayoutPanel33.Controls.Add(panel115, 0, 1);
            tableLayoutPanel33.Controls.Add(panel116, 0, 0);
            tableLayoutPanel33.Location = new Point(202, 506);
            tableLayoutPanel33.Margin = new Padding(0);
            tableLayoutPanel33.Name = "tableLayoutPanel33";
            tableLayoutPanel33.RowCount = 4;
            tableLayoutPanel33.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel33.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel33.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel33.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel33.Size = new Size(190, 90);
            tableLayoutPanel33.TabIndex = 81;
            // 
            // panel113
            // 
            panel113.Dock = DockStyle.Fill;
            panel113.Location = new Point(1, 67);
            panel113.Margin = new Padding(0);
            panel113.Name = "panel113";
            panel113.Size = new Size(188, 22);
            panel113.TabIndex = 18;
            // 
            // panel114
            // 
            panel114.Dock = DockStyle.Fill;
            panel114.Location = new Point(1, 45);
            panel114.Margin = new Padding(0);
            panel114.Name = "panel114";
            panel114.Size = new Size(188, 21);
            panel114.TabIndex = 17;
            // 
            // panel115
            // 
            panel115.Dock = DockStyle.Fill;
            panel115.Location = new Point(1, 23);
            panel115.Margin = new Padding(0);
            panel115.Name = "panel115";
            panel115.Size = new Size(188, 21);
            panel115.TabIndex = 16;
            // 
            // panel116
            // 
            panel116.Dock = DockStyle.Fill;
            panel116.Location = new Point(1, 1);
            panel116.Margin = new Padding(0);
            panel116.Name = "panel116";
            panel116.Size = new Size(188, 21);
            panel116.TabIndex = 15;
            // 
            // tableLayoutPanel32
            // 
            tableLayoutPanel32.BackColor = Color.White;
            tableLayoutPanel32.CellBorderStyle = TableLayoutPanelCellBorderStyle.Single;
            tableLayoutPanel32.ColumnCount = 1;
            tableLayoutPanel32.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tableLayoutPanel32.Controls.Add(panel109, 0, 3);
            tableLayoutPanel32.Controls.Add(panel110, 0, 2);
            tableLayoutPanel32.Controls.Add(panel111, 0, 1);
            tableLayoutPanel32.Controls.Add(panel112, 0, 0);
            tableLayoutPanel32.Location = new Point(1, 506);
            tableLayoutPanel32.Margin = new Padding(0);
            tableLayoutPanel32.Name = "tableLayoutPanel32";
            tableLayoutPanel32.RowCount = 4;
            tableLayoutPanel32.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel32.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel32.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel32.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel32.Size = new Size(190, 90);
            tableLayoutPanel32.TabIndex = 80;
            // 
            // panel109
            // 
            panel109.Dock = DockStyle.Fill;
            panel109.Location = new Point(1, 67);
            panel109.Margin = new Padding(0);
            panel109.Name = "panel109";
            panel109.Size = new Size(188, 22);
            panel109.TabIndex = 18;
            // 
            // panel110
            // 
            panel110.Dock = DockStyle.Fill;
            panel110.Location = new Point(1, 45);
            panel110.Margin = new Padding(0);
            panel110.Name = "panel110";
            panel110.Size = new Size(188, 21);
            panel110.TabIndex = 17;
            // 
            // panel111
            // 
            panel111.Dock = DockStyle.Fill;
            panel111.Location = new Point(1, 23);
            panel111.Margin = new Padding(0);
            panel111.Name = "panel111";
            panel111.Size = new Size(188, 21);
            panel111.TabIndex = 16;
            // 
            // panel112
            // 
            panel112.Dock = DockStyle.Fill;
            panel112.Location = new Point(1, 1);
            panel112.Margin = new Padding(0);
            panel112.Name = "panel112";
            panel112.Size = new Size(188, 21);
            panel112.TabIndex = 15;
            // 
            // tableLayoutPanel31
            // 
            tableLayoutPanel31.BackColor = Color.White;
            tableLayoutPanel31.CellBorderStyle = TableLayoutPanelCellBorderStyle.Single;
            tableLayoutPanel31.ColumnCount = 1;
            tableLayoutPanel31.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tableLayoutPanel31.Controls.Add(panel105, 0, 3);
            tableLayoutPanel31.Controls.Add(panel106, 0, 2);
            tableLayoutPanel31.Controls.Add(panel107, 0, 1);
            tableLayoutPanel31.Controls.Add(panel108, 0, 0);
            tableLayoutPanel31.Location = new Point(805, 405);
            tableLayoutPanel31.Margin = new Padding(0);
            tableLayoutPanel31.Name = "tableLayoutPanel31";
            tableLayoutPanel31.RowCount = 4;
            tableLayoutPanel31.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel31.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel31.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel31.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel31.Size = new Size(190, 90);
            tableLayoutPanel31.TabIndex = 79;
            // 
            // panel105
            // 
            panel105.Dock = DockStyle.Fill;
            panel105.Location = new Point(1, 67);
            panel105.Margin = new Padding(0);
            panel105.Name = "panel105";
            panel105.Size = new Size(188, 22);
            panel105.TabIndex = 18;
            // 
            // panel106
            // 
            panel106.Dock = DockStyle.Fill;
            panel106.Location = new Point(1, 45);
            panel106.Margin = new Padding(0);
            panel106.Name = "panel106";
            panel106.Size = new Size(188, 21);
            panel106.TabIndex = 17;
            // 
            // panel107
            // 
            panel107.Dock = DockStyle.Fill;
            panel107.Location = new Point(1, 23);
            panel107.Margin = new Padding(0);
            panel107.Name = "panel107";
            panel107.Size = new Size(188, 21);
            panel107.TabIndex = 16;
            // 
            // panel108
            // 
            panel108.Dock = DockStyle.Fill;
            panel108.Location = new Point(1, 1);
            panel108.Margin = new Padding(0);
            panel108.Name = "panel108";
            panel108.Size = new Size(188, 21);
            panel108.TabIndex = 15;
            // 
            // tableLayoutPanel29
            // 
            tableLayoutPanel29.BackColor = Color.White;
            tableLayoutPanel29.CellBorderStyle = TableLayoutPanelCellBorderStyle.Single;
            tableLayoutPanel29.ColumnCount = 1;
            tableLayoutPanel29.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tableLayoutPanel29.Controls.Add(panel101, 0, 3);
            tableLayoutPanel29.Controls.Add(panel102, 0, 2);
            tableLayoutPanel29.Controls.Add(panel103, 0, 1);
            tableLayoutPanel29.Controls.Add(panel104, 0, 0);
            tableLayoutPanel29.Location = new Point(604, 405);
            tableLayoutPanel29.Margin = new Padding(0);
            tableLayoutPanel29.Name = "tableLayoutPanel29";
            tableLayoutPanel29.RowCount = 4;
            tableLayoutPanel29.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel29.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel29.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel29.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel29.Size = new Size(190, 90);
            tableLayoutPanel29.TabIndex = 78;
            // 
            // panel101
            // 
            panel101.Dock = DockStyle.Fill;
            panel101.Location = new Point(1, 67);
            panel101.Margin = new Padding(0);
            panel101.Name = "panel101";
            panel101.Size = new Size(188, 22);
            panel101.TabIndex = 18;
            // 
            // panel102
            // 
            panel102.Dock = DockStyle.Fill;
            panel102.Location = new Point(1, 45);
            panel102.Margin = new Padding(0);
            panel102.Name = "panel102";
            panel102.Size = new Size(188, 21);
            panel102.TabIndex = 17;
            // 
            // panel103
            // 
            panel103.Dock = DockStyle.Fill;
            panel103.Location = new Point(1, 23);
            panel103.Margin = new Padding(0);
            panel103.Name = "panel103";
            panel103.Size = new Size(188, 21);
            panel103.TabIndex = 16;
            // 
            // panel104
            // 
            panel104.Dock = DockStyle.Fill;
            panel104.Location = new Point(1, 1);
            panel104.Margin = new Padding(0);
            panel104.Name = "panel104";
            panel104.Size = new Size(188, 21);
            panel104.TabIndex = 15;
            // 
            // tableLayoutPanel28
            // 
            tableLayoutPanel28.BackColor = Color.White;
            tableLayoutPanel28.CellBorderStyle = TableLayoutPanelCellBorderStyle.Single;
            tableLayoutPanel28.ColumnCount = 1;
            tableLayoutPanel28.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tableLayoutPanel28.Controls.Add(panel97, 0, 3);
            tableLayoutPanel28.Controls.Add(panel98, 0, 2);
            tableLayoutPanel28.Controls.Add(panel99, 0, 1);
            tableLayoutPanel28.Controls.Add(panel100, 0, 0);
            tableLayoutPanel28.Location = new Point(403, 405);
            tableLayoutPanel28.Margin = new Padding(0);
            tableLayoutPanel28.Name = "tableLayoutPanel28";
            tableLayoutPanel28.RowCount = 4;
            tableLayoutPanel28.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel28.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel28.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel28.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel28.Size = new Size(190, 90);
            tableLayoutPanel28.TabIndex = 77;
            // 
            // panel97
            // 
            panel97.Dock = DockStyle.Fill;
            panel97.Location = new Point(1, 67);
            panel97.Margin = new Padding(0);
            panel97.Name = "panel97";
            panel97.Size = new Size(188, 22);
            panel97.TabIndex = 18;
            // 
            // panel98
            // 
            panel98.Dock = DockStyle.Fill;
            panel98.Location = new Point(1, 45);
            panel98.Margin = new Padding(0);
            panel98.Name = "panel98";
            panel98.Size = new Size(188, 21);
            panel98.TabIndex = 17;
            // 
            // panel99
            // 
            panel99.Dock = DockStyle.Fill;
            panel99.Location = new Point(1, 23);
            panel99.Margin = new Padding(0);
            panel99.Name = "panel99";
            panel99.Size = new Size(188, 21);
            panel99.TabIndex = 16;
            // 
            // panel100
            // 
            panel100.Dock = DockStyle.Fill;
            panel100.Location = new Point(1, 1);
            panel100.Margin = new Padding(0);
            panel100.Name = "panel100";
            panel100.Size = new Size(188, 21);
            panel100.TabIndex = 15;
            // 
            // tableLayoutPanel27
            // 
            tableLayoutPanel27.BackColor = Color.White;
            tableLayoutPanel27.CellBorderStyle = TableLayoutPanelCellBorderStyle.Single;
            tableLayoutPanel27.ColumnCount = 1;
            tableLayoutPanel27.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tableLayoutPanel27.Controls.Add(panel93, 0, 3);
            tableLayoutPanel27.Controls.Add(panel94, 0, 2);
            tableLayoutPanel27.Controls.Add(panel95, 0, 1);
            tableLayoutPanel27.Controls.Add(panel96, 0, 0);
            tableLayoutPanel27.Location = new Point(202, 405);
            tableLayoutPanel27.Margin = new Padding(0);
            tableLayoutPanel27.Name = "tableLayoutPanel27";
            tableLayoutPanel27.RowCount = 4;
            tableLayoutPanel27.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel27.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel27.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel27.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel27.Size = new Size(190, 90);
            tableLayoutPanel27.TabIndex = 76;
            // 
            // panel93
            // 
            panel93.Dock = DockStyle.Fill;
            panel93.Location = new Point(1, 67);
            panel93.Margin = new Padding(0);
            panel93.Name = "panel93";
            panel93.Size = new Size(188, 22);
            panel93.TabIndex = 18;
            // 
            // panel94
            // 
            panel94.Dock = DockStyle.Fill;
            panel94.Location = new Point(1, 45);
            panel94.Margin = new Padding(0);
            panel94.Name = "panel94";
            panel94.Size = new Size(188, 21);
            panel94.TabIndex = 17;
            // 
            // panel95
            // 
            panel95.Dock = DockStyle.Fill;
            panel95.Location = new Point(1, 23);
            panel95.Margin = new Padding(0);
            panel95.Name = "panel95";
            panel95.Size = new Size(188, 21);
            panel95.TabIndex = 16;
            // 
            // panel96
            // 
            panel96.Dock = DockStyle.Fill;
            panel96.Location = new Point(1, 1);
            panel96.Margin = new Padding(0);
            panel96.Name = "panel96";
            panel96.Size = new Size(188, 21);
            panel96.TabIndex = 15;
            // 
            // tableLayoutPanel25
            // 
            tableLayoutPanel25.BackColor = Color.White;
            tableLayoutPanel25.CellBorderStyle = TableLayoutPanelCellBorderStyle.Single;
            tableLayoutPanel25.ColumnCount = 1;
            tableLayoutPanel25.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tableLayoutPanel25.Controls.Add(panel89, 0, 3);
            tableLayoutPanel25.Controls.Add(panel90, 0, 2);
            tableLayoutPanel25.Controls.Add(panel91, 0, 1);
            tableLayoutPanel25.Controls.Add(panel92, 0, 0);
            tableLayoutPanel25.Location = new Point(1, 405);
            tableLayoutPanel25.Margin = new Padding(0);
            tableLayoutPanel25.Name = "tableLayoutPanel25";
            tableLayoutPanel25.RowCount = 4;
            tableLayoutPanel25.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel25.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel25.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel25.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel25.Size = new Size(190, 90);
            tableLayoutPanel25.TabIndex = 75;
            // 
            // panel89
            // 
            panel89.Dock = DockStyle.Fill;
            panel89.Location = new Point(1, 67);
            panel89.Margin = new Padding(0);
            panel89.Name = "panel89";
            panel89.Size = new Size(188, 22);
            panel89.TabIndex = 18;
            // 
            // panel90
            // 
            panel90.Dock = DockStyle.Fill;
            panel90.Location = new Point(1, 45);
            panel90.Margin = new Padding(0);
            panel90.Name = "panel90";
            panel90.Size = new Size(188, 21);
            panel90.TabIndex = 17;
            // 
            // panel91
            // 
            panel91.Dock = DockStyle.Fill;
            panel91.Location = new Point(1, 23);
            panel91.Margin = new Padding(0);
            panel91.Name = "panel91";
            panel91.Size = new Size(188, 21);
            panel91.TabIndex = 16;
            // 
            // panel92
            // 
            panel92.Dock = DockStyle.Fill;
            panel92.Location = new Point(1, 1);
            panel92.Margin = new Padding(0);
            panel92.Name = "panel92";
            panel92.Size = new Size(188, 21);
            panel92.TabIndex = 15;
            // 
            // tableLayoutPanel18
            // 
            tableLayoutPanel18.BackColor = Color.White;
            tableLayoutPanel18.CellBorderStyle = TableLayoutPanelCellBorderStyle.Single;
            tableLayoutPanel18.ColumnCount = 1;
            tableLayoutPanel18.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tableLayoutPanel18.Controls.Add(panel65, 0, 3);
            tableLayoutPanel18.Controls.Add(panel66, 0, 2);
            tableLayoutPanel18.Controls.Add(panel67, 0, 1);
            tableLayoutPanel18.Controls.Add(panel68, 0, 0);
            tableLayoutPanel18.Location = new Point(805, 203);
            tableLayoutPanel18.Margin = new Padding(0);
            tableLayoutPanel18.Name = "tableLayoutPanel18";
            tableLayoutPanel18.RowCount = 4;
            tableLayoutPanel18.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel18.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel18.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel18.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel18.Size = new Size(190, 90);
            tableLayoutPanel18.TabIndex = 74;
            // 
            // panel65
            // 
            panel65.Dock = DockStyle.Fill;
            panel65.Location = new Point(1, 67);
            panel65.Margin = new Padding(0);
            panel65.Name = "panel65";
            panel65.Size = new Size(188, 22);
            panel65.TabIndex = 18;
            // 
            // panel66
            // 
            panel66.Dock = DockStyle.Fill;
            panel66.Location = new Point(1, 45);
            panel66.Margin = new Padding(0);
            panel66.Name = "panel66";
            panel66.Size = new Size(188, 21);
            panel66.TabIndex = 17;
            // 
            // panel67
            // 
            panel67.Dock = DockStyle.Fill;
            panel67.Location = new Point(1, 23);
            panel67.Margin = new Padding(0);
            panel67.Name = "panel67";
            panel67.Size = new Size(188, 21);
            panel67.TabIndex = 16;
            // 
            // panel68
            // 
            panel68.Dock = DockStyle.Fill;
            panel68.Location = new Point(1, 1);
            panel68.Margin = new Padding(0);
            panel68.Name = "panel68";
            panel68.Size = new Size(188, 21);
            panel68.TabIndex = 15;
            // 
            // tableLayoutPanel24
            // 
            tableLayoutPanel24.BackColor = Color.White;
            tableLayoutPanel24.CellBorderStyle = TableLayoutPanelCellBorderStyle.Single;
            tableLayoutPanel24.ColumnCount = 1;
            tableLayoutPanel24.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tableLayoutPanel24.Controls.Add(panel85, 0, 3);
            tableLayoutPanel24.Controls.Add(panel86, 0, 2);
            tableLayoutPanel24.Controls.Add(panel87, 0, 1);
            tableLayoutPanel24.Controls.Add(panel88, 0, 0);
            tableLayoutPanel24.Location = new Point(805, 304);
            tableLayoutPanel24.Margin = new Padding(0);
            tableLayoutPanel24.Name = "tableLayoutPanel24";
            tableLayoutPanel24.RowCount = 4;
            tableLayoutPanel24.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel24.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel24.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel24.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel24.Size = new Size(190, 90);
            tableLayoutPanel24.TabIndex = 73;
            // 
            // panel85
            // 
            panel85.Dock = DockStyle.Fill;
            panel85.Location = new Point(1, 67);
            panel85.Margin = new Padding(0);
            panel85.Name = "panel85";
            panel85.Size = new Size(188, 22);
            panel85.TabIndex = 18;
            // 
            // panel86
            // 
            panel86.Dock = DockStyle.Fill;
            panel86.Location = new Point(1, 45);
            panel86.Margin = new Padding(0);
            panel86.Name = "panel86";
            panel86.Size = new Size(188, 21);
            panel86.TabIndex = 17;
            // 
            // panel87
            // 
            panel87.Dock = DockStyle.Fill;
            panel87.Location = new Point(1, 23);
            panel87.Margin = new Padding(0);
            panel87.Name = "panel87";
            panel87.Size = new Size(188, 21);
            panel87.TabIndex = 16;
            // 
            // panel88
            // 
            panel88.Dock = DockStyle.Fill;
            panel88.Location = new Point(1, 1);
            panel88.Margin = new Padding(0);
            panel88.Name = "panel88";
            panel88.Size = new Size(188, 21);
            panel88.TabIndex = 15;
            // 
            // tableLayoutPanel23
            // 
            tableLayoutPanel23.BackColor = Color.White;
            tableLayoutPanel23.CellBorderStyle = TableLayoutPanelCellBorderStyle.Single;
            tableLayoutPanel23.ColumnCount = 1;
            tableLayoutPanel23.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tableLayoutPanel23.Controls.Add(panel81, 0, 3);
            tableLayoutPanel23.Controls.Add(panel82, 0, 2);
            tableLayoutPanel23.Controls.Add(panel83, 0, 1);
            tableLayoutPanel23.Controls.Add(panel84, 0, 0);
            tableLayoutPanel23.Location = new Point(604, 304);
            tableLayoutPanel23.Margin = new Padding(0);
            tableLayoutPanel23.Name = "tableLayoutPanel23";
            tableLayoutPanel23.RowCount = 4;
            tableLayoutPanel23.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel23.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel23.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel23.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel23.Size = new Size(190, 90);
            tableLayoutPanel23.TabIndex = 72;
            // 
            // panel81
            // 
            panel81.Dock = DockStyle.Fill;
            panel81.Location = new Point(1, 67);
            panel81.Margin = new Padding(0);
            panel81.Name = "panel81";
            panel81.Size = new Size(188, 22);
            panel81.TabIndex = 18;
            // 
            // panel82
            // 
            panel82.Dock = DockStyle.Fill;
            panel82.Location = new Point(1, 45);
            panel82.Margin = new Padding(0);
            panel82.Name = "panel82";
            panel82.Size = new Size(188, 21);
            panel82.TabIndex = 17;
            // 
            // panel83
            // 
            panel83.Dock = DockStyle.Fill;
            panel83.Location = new Point(1, 23);
            panel83.Margin = new Padding(0);
            panel83.Name = "panel83";
            panel83.Size = new Size(188, 21);
            panel83.TabIndex = 16;
            // 
            // panel84
            // 
            panel84.Dock = DockStyle.Fill;
            panel84.Location = new Point(1, 1);
            panel84.Margin = new Padding(0);
            panel84.Name = "panel84";
            panel84.Size = new Size(188, 21);
            panel84.TabIndex = 15;
            // 
            // tableLayoutPanel21
            // 
            tableLayoutPanel21.BackColor = Color.White;
            tableLayoutPanel21.CellBorderStyle = TableLayoutPanelCellBorderStyle.Single;
            tableLayoutPanel21.ColumnCount = 1;
            tableLayoutPanel21.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tableLayoutPanel21.Controls.Add(panel77, 0, 3);
            tableLayoutPanel21.Controls.Add(panel78, 0, 2);
            tableLayoutPanel21.Controls.Add(panel79, 0, 1);
            tableLayoutPanel21.Controls.Add(panel80, 0, 0);
            tableLayoutPanel21.Location = new Point(403, 304);
            tableLayoutPanel21.Margin = new Padding(0);
            tableLayoutPanel21.Name = "tableLayoutPanel21";
            tableLayoutPanel21.RowCount = 4;
            tableLayoutPanel21.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel21.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel21.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel21.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel21.Size = new Size(190, 90);
            tableLayoutPanel21.TabIndex = 71;
            // 
            // panel77
            // 
            panel77.Dock = DockStyle.Fill;
            panel77.Location = new Point(1, 67);
            panel77.Margin = new Padding(0);
            panel77.Name = "panel77";
            panel77.Size = new Size(188, 22);
            panel77.TabIndex = 18;
            // 
            // panel78
            // 
            panel78.Dock = DockStyle.Fill;
            panel78.Location = new Point(1, 45);
            panel78.Margin = new Padding(0);
            panel78.Name = "panel78";
            panel78.Size = new Size(188, 21);
            panel78.TabIndex = 17;
            // 
            // panel79
            // 
            panel79.Dock = DockStyle.Fill;
            panel79.Location = new Point(1, 23);
            panel79.Margin = new Padding(0);
            panel79.Name = "panel79";
            panel79.Size = new Size(188, 21);
            panel79.TabIndex = 16;
            // 
            // panel80
            // 
            panel80.Dock = DockStyle.Fill;
            panel80.Location = new Point(1, 1);
            panel80.Margin = new Padding(0);
            panel80.Name = "panel80";
            panel80.Size = new Size(188, 21);
            panel80.TabIndex = 15;
            // 
            // tableLayoutPanel20
            // 
            tableLayoutPanel20.BackColor = Color.White;
            tableLayoutPanel20.CellBorderStyle = TableLayoutPanelCellBorderStyle.Single;
            tableLayoutPanel20.ColumnCount = 1;
            tableLayoutPanel20.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tableLayoutPanel20.Controls.Add(panel73, 0, 3);
            tableLayoutPanel20.Controls.Add(panel74, 0, 2);
            tableLayoutPanel20.Controls.Add(panel75, 0, 1);
            tableLayoutPanel20.Controls.Add(panel76, 0, 0);
            tableLayoutPanel20.Location = new Point(202, 304);
            tableLayoutPanel20.Margin = new Padding(0);
            tableLayoutPanel20.Name = "tableLayoutPanel20";
            tableLayoutPanel20.RowCount = 4;
            tableLayoutPanel20.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel20.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel20.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel20.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel20.Size = new Size(190, 90);
            tableLayoutPanel20.TabIndex = 70;
            // 
            // panel73
            // 
            panel73.Dock = DockStyle.Fill;
            panel73.Location = new Point(1, 67);
            panel73.Margin = new Padding(0);
            panel73.Name = "panel73";
            panel73.Size = new Size(188, 22);
            panel73.TabIndex = 18;
            // 
            // panel74
            // 
            panel74.Dock = DockStyle.Fill;
            panel74.Location = new Point(1, 45);
            panel74.Margin = new Padding(0);
            panel74.Name = "panel74";
            panel74.Size = new Size(188, 21);
            panel74.TabIndex = 17;
            // 
            // panel75
            // 
            panel75.Dock = DockStyle.Fill;
            panel75.Location = new Point(1, 23);
            panel75.Margin = new Padding(0);
            panel75.Name = "panel75";
            panel75.Size = new Size(188, 21);
            panel75.TabIndex = 16;
            // 
            // panel76
            // 
            panel76.Dock = DockStyle.Fill;
            panel76.Location = new Point(1, 1);
            panel76.Margin = new Padding(0);
            panel76.Name = "panel76";
            panel76.Size = new Size(188, 21);
            panel76.TabIndex = 15;
            // 
            // tableLayoutPanel8
            // 
            tableLayoutPanel8.BackColor = Color.White;
            tableLayoutPanel8.CellBorderStyle = TableLayoutPanelCellBorderStyle.Single;
            tableLayoutPanel8.ColumnCount = 1;
            tableLayoutPanel8.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tableLayoutPanel8.Controls.Add(panel35, 0, 3);
            tableLayoutPanel8.Controls.Add(panel36, 0, 2);
            tableLayoutPanel8.Controls.Add(panel37, 0, 1);
            tableLayoutPanel8.Controls.Add(panel38, 0, 0);
            tableLayoutPanel8.Location = new Point(202, 102);
            tableLayoutPanel8.Margin = new Padding(0);
            tableLayoutPanel8.Name = "tableLayoutPanel8";
            tableLayoutPanel8.RowCount = 4;
            tableLayoutPanel8.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel8.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel8.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel8.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel8.Size = new Size(190, 90);
            tableLayoutPanel8.TabIndex = 62;
            // 
            // panel35
            // 
            panel35.Dock = DockStyle.Fill;
            panel35.Location = new Point(1, 67);
            panel35.Margin = new Padding(0);
            panel35.Name = "panel35";
            panel35.Size = new Size(188, 22);
            panel35.TabIndex = 18;
            // 
            // panel36
            // 
            panel36.Dock = DockStyle.Fill;
            panel36.Location = new Point(1, 45);
            panel36.Margin = new Padding(0);
            panel36.Name = "panel36";
            panel36.Size = new Size(188, 21);
            panel36.TabIndex = 17;
            // 
            // panel37
            // 
            panel37.Dock = DockStyle.Fill;
            panel37.Location = new Point(1, 23);
            panel37.Margin = new Padding(0);
            panel37.Name = "panel37";
            panel37.Size = new Size(188, 21);
            panel37.TabIndex = 16;
            // 
            // panel38
            // 
            panel38.Dock = DockStyle.Fill;
            panel38.Location = new Point(1, 1);
            panel38.Margin = new Padding(0);
            panel38.Name = "panel38";
            panel38.Size = new Size(188, 21);
            panel38.TabIndex = 15;
            // 
            // tableLayoutPanel7
            // 
            tableLayoutPanel7.BackColor = Color.White;
            tableLayoutPanel7.CellBorderStyle = TableLayoutPanelCellBorderStyle.Single;
            tableLayoutPanel7.ColumnCount = 1;
            tableLayoutPanel7.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tableLayoutPanel7.Controls.Add(panel31, 0, 3);
            tableLayoutPanel7.Controls.Add(panel32, 0, 2);
            tableLayoutPanel7.Controls.Add(panel33, 0, 1);
            tableLayoutPanel7.Controls.Add(panel34, 0, 0);
            tableLayoutPanel7.Location = new Point(805, 1);
            tableLayoutPanel7.Margin = new Padding(0);
            tableLayoutPanel7.Name = "tableLayoutPanel7";
            tableLayoutPanel7.RowCount = 4;
            tableLayoutPanel7.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel7.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel7.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel7.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel7.Size = new Size(190, 90);
            tableLayoutPanel7.TabIndex = 61;
            // 
            // panel31
            // 
            panel31.Dock = DockStyle.Fill;
            panel31.Location = new Point(1, 67);
            panel31.Margin = new Padding(0);
            panel31.Name = "panel31";
            panel31.Size = new Size(188, 22);
            panel31.TabIndex = 18;
            // 
            // panel32
            // 
            panel32.Dock = DockStyle.Fill;
            panel32.Location = new Point(1, 45);
            panel32.Margin = new Padding(0);
            panel32.Name = "panel32";
            panel32.Size = new Size(188, 21);
            panel32.TabIndex = 17;
            // 
            // panel33
            // 
            panel33.Dock = DockStyle.Fill;
            panel33.Location = new Point(1, 23);
            panel33.Margin = new Padding(0);
            panel33.Name = "panel33";
            panel33.Size = new Size(188, 21);
            panel33.TabIndex = 16;
            // 
            // panel34
            // 
            panel34.Dock = DockStyle.Fill;
            panel34.Location = new Point(1, 1);
            panel34.Margin = new Padding(0);
            panel34.Name = "panel34";
            panel34.Size = new Size(188, 21);
            panel34.TabIndex = 15;
            // 
            // tableLayoutPanel6
            // 
            tableLayoutPanel6.BackColor = Color.White;
            tableLayoutPanel6.CellBorderStyle = TableLayoutPanelCellBorderStyle.Single;
            tableLayoutPanel6.ColumnCount = 1;
            tableLayoutPanel6.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tableLayoutPanel6.Controls.Add(panel27, 0, 3);
            tableLayoutPanel6.Controls.Add(panel28, 0, 2);
            tableLayoutPanel6.Controls.Add(panel29, 0, 1);
            tableLayoutPanel6.Controls.Add(panel30, 0, 0);
            tableLayoutPanel6.Location = new Point(604, 1);
            tableLayoutPanel6.Margin = new Padding(0);
            tableLayoutPanel6.Name = "tableLayoutPanel6";
            tableLayoutPanel6.RowCount = 4;
            tableLayoutPanel6.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel6.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel6.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel6.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel6.Size = new Size(190, 90);
            tableLayoutPanel6.TabIndex = 60;
            // 
            // panel27
            // 
            panel27.Dock = DockStyle.Fill;
            panel27.Location = new Point(1, 67);
            panel27.Margin = new Padding(0);
            panel27.Name = "panel27";
            panel27.Size = new Size(188, 22);
            panel27.TabIndex = 18;
            // 
            // panel28
            // 
            panel28.Dock = DockStyle.Fill;
            panel28.Location = new Point(1, 45);
            panel28.Margin = new Padding(0);
            panel28.Name = "panel28";
            panel28.Size = new Size(188, 21);
            panel28.TabIndex = 17;
            // 
            // panel29
            // 
            panel29.Dock = DockStyle.Fill;
            panel29.Location = new Point(1, 23);
            panel29.Margin = new Padding(0);
            panel29.Name = "panel29";
            panel29.Size = new Size(188, 21);
            panel29.TabIndex = 16;
            // 
            // panel30
            // 
            panel30.Dock = DockStyle.Fill;
            panel30.Location = new Point(1, 1);
            panel30.Margin = new Padding(0);
            panel30.Name = "panel30";
            panel30.Size = new Size(188, 21);
            panel30.TabIndex = 15;
            // 
            // tableLayoutPanel9
            // 
            tableLayoutPanel9.BackColor = Color.White;
            tableLayoutPanel9.CellBorderStyle = TableLayoutPanelCellBorderStyle.Single;
            tableLayoutPanel9.ColumnCount = 1;
            tableLayoutPanel9.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tableLayoutPanel9.Controls.Add(panel19, 0, 3);
            tableLayoutPanel9.Controls.Add(panel20, 0, 2);
            tableLayoutPanel9.Controls.Add(panel21, 0, 1);
            tableLayoutPanel9.Controls.Add(panel22, 0, 0);
            tableLayoutPanel9.Location = new Point(1, 203);
            tableLayoutPanel9.Margin = new Padding(0);
            tableLayoutPanel9.Name = "tableLayoutPanel9";
            tableLayoutPanel9.RowCount = 4;
            tableLayoutPanel9.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel9.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel9.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel9.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel9.Size = new Size(190, 90);
            tableLayoutPanel9.TabIndex = 57;
            // 
            // panel19
            // 
            panel19.Dock = DockStyle.Fill;
            panel19.Location = new Point(1, 67);
            panel19.Margin = new Padding(0);
            panel19.Name = "panel19";
            panel19.Size = new Size(188, 22);
            panel19.TabIndex = 18;
            // 
            // panel20
            // 
            panel20.Dock = DockStyle.Fill;
            panel20.Location = new Point(1, 45);
            panel20.Margin = new Padding(0);
            panel20.Name = "panel20";
            panel20.Size = new Size(188, 21);
            panel20.TabIndex = 17;
            // 
            // panel21
            // 
            panel21.Dock = DockStyle.Fill;
            panel21.Location = new Point(1, 23);
            panel21.Margin = new Padding(0);
            panel21.Name = "panel21";
            panel21.Size = new Size(188, 21);
            panel21.TabIndex = 16;
            // 
            // panel22
            // 
            panel22.Dock = DockStyle.Fill;
            panel22.Location = new Point(1, 1);
            panel22.Margin = new Padding(0);
            panel22.Name = "panel22";
            panel22.Size = new Size(188, 21);
            panel22.TabIndex = 15;
            // 
            // tableLayoutPanel5
            // 
            tableLayoutPanel5.BackColor = Color.White;
            tableLayoutPanel5.CellBorderStyle = TableLayoutPanelCellBorderStyle.Single;
            tableLayoutPanel5.ColumnCount = 1;
            tableLayoutPanel5.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tableLayoutPanel5.Controls.Add(panel4, 0, 3);
            tableLayoutPanel5.Controls.Add(panel3, 0, 2);
            tableLayoutPanel5.Controls.Add(panel2, 0, 1);
            tableLayoutPanel5.Controls.Add(panel1, 0, 0);
            tableLayoutPanel5.Location = new Point(1, 1);
            tableLayoutPanel5.Margin = new Padding(0);
            tableLayoutPanel5.Name = "tableLayoutPanel5";
            tableLayoutPanel5.RowCount = 4;
            tableLayoutPanel5.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel5.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel5.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel5.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel5.Size = new Size(190, 90);
            tableLayoutPanel5.TabIndex = 10;
            // 
            // panel4
            // 
            panel4.Dock = DockStyle.Fill;
            panel4.Location = new Point(1, 67);
            panel4.Margin = new Padding(0);
            panel4.Name = "panel4";
            panel4.Size = new Size(188, 22);
            panel4.TabIndex = 18;
            // 
            // panel3
            // 
            panel3.Dock = DockStyle.Fill;
            panel3.Location = new Point(1, 45);
            panel3.Margin = new Padding(0);
            panel3.Name = "panel3";
            panel3.Size = new Size(188, 21);
            panel3.TabIndex = 17;
            // 
            // panel2
            // 
            panel2.Dock = DockStyle.Fill;
            panel2.Location = new Point(1, 23);
            panel2.Margin = new Padding(0);
            panel2.Name = "panel2";
            panel2.Size = new Size(188, 21);
            panel2.TabIndex = 16;
            // 
            // panel1
            // 
            panel1.Dock = DockStyle.Fill;
            panel1.Location = new Point(1, 1);
            panel1.Margin = new Padding(0);
            panel1.Name = "panel1";
            panel1.Size = new Size(188, 21);
            panel1.TabIndex = 15;
            // 
            // tableLayoutPanel116
            // 
            tableLayoutPanel116.BackColor = Color.White;
            tableLayoutPanel116.CellBorderStyle = TableLayoutPanelCellBorderStyle.Single;
            tableLayoutPanel116.ColumnCount = 1;
            tableLayoutPanel116.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tableLayoutPanel116.Controls.Add(panel15, 0, 3);
            tableLayoutPanel116.Controls.Add(panel16, 0, 2);
            tableLayoutPanel116.Controls.Add(panel17, 0, 1);
            tableLayoutPanel116.Controls.Add(panel18, 0, 0);
            tableLayoutPanel116.Location = new Point(1, 102);
            tableLayoutPanel116.Margin = new Padding(0);
            tableLayoutPanel116.Name = "tableLayoutPanel116";
            tableLayoutPanel116.RowCount = 4;
            tableLayoutPanel116.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel116.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel116.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel116.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel116.Size = new Size(190, 90);
            tableLayoutPanel116.TabIndex = 56;
            // 
            // panel15
            // 
            panel15.Dock = DockStyle.Fill;
            panel15.Location = new Point(1, 67);
            panel15.Margin = new Padding(0);
            panel15.Name = "panel15";
            panel15.Size = new Size(188, 22);
            panel15.TabIndex = 18;
            // 
            // panel16
            // 
            panel16.Dock = DockStyle.Fill;
            panel16.Location = new Point(1, 45);
            panel16.Margin = new Padding(0);
            panel16.Name = "panel16";
            panel16.Size = new Size(188, 21);
            panel16.TabIndex = 17;
            // 
            // panel17
            // 
            panel17.Dock = DockStyle.Fill;
            panel17.Location = new Point(1, 23);
            panel17.Margin = new Padding(0);
            panel17.Name = "panel17";
            panel17.Size = new Size(188, 21);
            panel17.TabIndex = 16;
            // 
            // panel18
            // 
            panel18.Dock = DockStyle.Fill;
            panel18.Location = new Point(1, 1);
            panel18.Margin = new Padding(0);
            panel18.Name = "panel18";
            panel18.Size = new Size(188, 21);
            panel18.TabIndex = 15;
            // 
            // tableLayoutPanel2
            // 
            tableLayoutPanel2.BackColor = Color.White;
            tableLayoutPanel2.CellBorderStyle = TableLayoutPanelCellBorderStyle.Single;
            tableLayoutPanel2.ColumnCount = 1;
            tableLayoutPanel2.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tableLayoutPanel2.Controls.Add(panel11, 0, 3);
            tableLayoutPanel2.Controls.Add(panel12, 0, 2);
            tableLayoutPanel2.Controls.Add(panel13, 0, 1);
            tableLayoutPanel2.Controls.Add(panel14, 0, 0);
            tableLayoutPanel2.Location = new Point(202, 1);
            tableLayoutPanel2.Margin = new Padding(0);
            tableLayoutPanel2.Name = "tableLayoutPanel2";
            tableLayoutPanel2.RowCount = 4;
            tableLayoutPanel2.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel2.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel2.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel2.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel2.Size = new Size(190, 90);
            tableLayoutPanel2.TabIndex = 58;
            // 
            // panel11
            // 
            panel11.Dock = DockStyle.Fill;
            panel11.Location = new Point(1, 67);
            panel11.Margin = new Padding(0);
            panel11.Name = "panel11";
            panel11.Size = new Size(188, 22);
            panel11.TabIndex = 18;
            // 
            // panel12
            // 
            panel12.Dock = DockStyle.Fill;
            panel12.Location = new Point(1, 45);
            panel12.Margin = new Padding(0);
            panel12.Name = "panel12";
            panel12.Size = new Size(188, 21);
            panel12.TabIndex = 17;
            // 
            // panel13
            // 
            panel13.Dock = DockStyle.Fill;
            panel13.Location = new Point(1, 23);
            panel13.Margin = new Padding(0);
            panel13.Name = "panel13";
            panel13.Size = new Size(188, 21);
            panel13.TabIndex = 16;
            panel13.Tag = "";
            // 
            // panel14
            // 
            panel14.Dock = DockStyle.Fill;
            panel14.Location = new Point(1, 1);
            panel14.Margin = new Padding(0);
            panel14.Name = "panel14";
            panel14.Size = new Size(188, 21);
            panel14.TabIndex = 15;
            // 
            // tableLayoutPanel4
            // 
            tableLayoutPanel4.BackColor = Color.White;
            tableLayoutPanel4.CellBorderStyle = TableLayoutPanelCellBorderStyle.Single;
            tableLayoutPanel4.ColumnCount = 1;
            tableLayoutPanel4.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tableLayoutPanel4.Controls.Add(panel23, 0, 3);
            tableLayoutPanel4.Controls.Add(panel24, 0, 2);
            tableLayoutPanel4.Controls.Add(panel25, 0, 1);
            tableLayoutPanel4.Controls.Add(panel26, 0, 0);
            tableLayoutPanel4.Location = new Point(403, 1);
            tableLayoutPanel4.Margin = new Padding(0);
            tableLayoutPanel4.Name = "tableLayoutPanel4";
            tableLayoutPanel4.RowCount = 4;
            tableLayoutPanel4.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel4.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel4.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel4.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel4.Size = new Size(190, 90);
            tableLayoutPanel4.TabIndex = 59;
            // 
            // panel23
            // 
            panel23.Dock = DockStyle.Fill;
            panel23.Location = new Point(1, 67);
            panel23.Margin = new Padding(0);
            panel23.Name = "panel23";
            panel23.Size = new Size(188, 22);
            panel23.TabIndex = 18;
            // 
            // panel24
            // 
            panel24.Dock = DockStyle.Fill;
            panel24.Location = new Point(1, 45);
            panel24.Margin = new Padding(0);
            panel24.Name = "panel24";
            panel24.Size = new Size(188, 21);
            panel24.TabIndex = 17;
            // 
            // panel25
            // 
            panel25.Dock = DockStyle.Fill;
            panel25.Location = new Point(1, 23);
            panel25.Margin = new Padding(0);
            panel25.Name = "panel25";
            panel25.Size = new Size(188, 21);
            panel25.TabIndex = 16;
            // 
            // panel26
            // 
            panel26.Dock = DockStyle.Fill;
            panel26.Location = new Point(1, 1);
            panel26.Margin = new Padding(0);
            panel26.Name = "panel26";
            panel26.Size = new Size(188, 21);
            panel26.TabIndex = 15;
            // 
            // tableLayoutPanel10
            // 
            tableLayoutPanel10.BackColor = Color.White;
            tableLayoutPanel10.CellBorderStyle = TableLayoutPanelCellBorderStyle.Single;
            tableLayoutPanel10.ColumnCount = 1;
            tableLayoutPanel10.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tableLayoutPanel10.Controls.Add(panel39, 0, 3);
            tableLayoutPanel10.Controls.Add(panel40, 0, 2);
            tableLayoutPanel10.Controls.Add(panel41, 0, 1);
            tableLayoutPanel10.Controls.Add(panel42, 0, 0);
            tableLayoutPanel10.Location = new Point(403, 102);
            tableLayoutPanel10.Margin = new Padding(0);
            tableLayoutPanel10.Name = "tableLayoutPanel10";
            tableLayoutPanel10.RowCount = 4;
            tableLayoutPanel10.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel10.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel10.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel10.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel10.Size = new Size(190, 90);
            tableLayoutPanel10.TabIndex = 63;
            // 
            // panel39
            // 
            panel39.Dock = DockStyle.Fill;
            panel39.Location = new Point(1, 67);
            panel39.Margin = new Padding(0);
            panel39.Name = "panel39";
            panel39.Size = new Size(188, 22);
            panel39.TabIndex = 18;
            // 
            // panel40
            // 
            panel40.Dock = DockStyle.Fill;
            panel40.Location = new Point(1, 45);
            panel40.Margin = new Padding(0);
            panel40.Name = "panel40";
            panel40.Size = new Size(188, 21);
            panel40.TabIndex = 17;
            // 
            // panel41
            // 
            panel41.Dock = DockStyle.Fill;
            panel41.Location = new Point(1, 23);
            panel41.Margin = new Padding(0);
            panel41.Name = "panel41";
            panel41.Size = new Size(188, 21);
            panel41.TabIndex = 16;
            // 
            // panel42
            // 
            panel42.Dock = DockStyle.Fill;
            panel42.Location = new Point(1, 1);
            panel42.Margin = new Padding(0);
            panel42.Name = "panel42";
            panel42.Size = new Size(188, 21);
            panel42.TabIndex = 15;
            // 
            // tableLayoutPanel12
            // 
            tableLayoutPanel12.BackColor = Color.White;
            tableLayoutPanel12.CellBorderStyle = TableLayoutPanelCellBorderStyle.Single;
            tableLayoutPanel12.ColumnCount = 1;
            tableLayoutPanel12.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tableLayoutPanel12.Controls.Add(panel45, 0, 3);
            tableLayoutPanel12.Controls.Add(panel46, 0, 2);
            tableLayoutPanel12.Controls.Add(panel47, 0, 1);
            tableLayoutPanel12.Controls.Add(panel48, 0, 0);
            tableLayoutPanel12.Location = new Point(604, 102);
            tableLayoutPanel12.Margin = new Padding(0);
            tableLayoutPanel12.Name = "tableLayoutPanel12";
            tableLayoutPanel12.RowCount = 4;
            tableLayoutPanel12.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel12.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel12.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel12.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel12.Size = new Size(190, 90);
            tableLayoutPanel12.TabIndex = 64;
            // 
            // panel45
            // 
            panel45.Dock = DockStyle.Fill;
            panel45.Location = new Point(1, 67);
            panel45.Margin = new Padding(0);
            panel45.Name = "panel45";
            panel45.Size = new Size(188, 22);
            panel45.TabIndex = 18;
            // 
            // panel46
            // 
            panel46.Dock = DockStyle.Fill;
            panel46.Location = new Point(1, 45);
            panel46.Margin = new Padding(0);
            panel46.Name = "panel46";
            panel46.Size = new Size(188, 21);
            panel46.TabIndex = 17;
            // 
            // panel47
            // 
            panel47.Dock = DockStyle.Fill;
            panel47.Location = new Point(1, 23);
            panel47.Margin = new Padding(0);
            panel47.Name = "panel47";
            panel47.Size = new Size(188, 21);
            panel47.TabIndex = 16;
            // 
            // panel48
            // 
            panel48.Dock = DockStyle.Fill;
            panel48.Location = new Point(1, 1);
            panel48.Margin = new Padding(0);
            panel48.Name = "panel48";
            panel48.Size = new Size(188, 21);
            panel48.TabIndex = 15;
            // 
            // tableLayoutPanel13
            // 
            tableLayoutPanel13.BackColor = Color.White;
            tableLayoutPanel13.CellBorderStyle = TableLayoutPanelCellBorderStyle.Single;
            tableLayoutPanel13.ColumnCount = 1;
            tableLayoutPanel13.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tableLayoutPanel13.Controls.Add(panel49, 0, 3);
            tableLayoutPanel13.Controls.Add(panel50, 0, 2);
            tableLayoutPanel13.Controls.Add(panel51, 0, 1);
            tableLayoutPanel13.Controls.Add(panel52, 0, 0);
            tableLayoutPanel13.Location = new Point(805, 102);
            tableLayoutPanel13.Margin = new Padding(0);
            tableLayoutPanel13.Name = "tableLayoutPanel13";
            tableLayoutPanel13.RowCount = 4;
            tableLayoutPanel13.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel13.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel13.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel13.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel13.Size = new Size(190, 90);
            tableLayoutPanel13.TabIndex = 65;
            // 
            // panel49
            // 
            panel49.Dock = DockStyle.Fill;
            panel49.Location = new Point(1, 67);
            panel49.Margin = new Padding(0);
            panel49.Name = "panel49";
            panel49.Size = new Size(188, 22);
            panel49.TabIndex = 18;
            // 
            // panel50
            // 
            panel50.Dock = DockStyle.Fill;
            panel50.Location = new Point(1, 45);
            panel50.Margin = new Padding(0);
            panel50.Name = "panel50";
            panel50.Size = new Size(188, 21);
            panel50.TabIndex = 17;
            // 
            // panel51
            // 
            panel51.Dock = DockStyle.Fill;
            panel51.Location = new Point(1, 23);
            panel51.Margin = new Padding(0);
            panel51.Name = "panel51";
            panel51.Size = new Size(188, 21);
            panel51.TabIndex = 16;
            // 
            // panel52
            // 
            panel52.Dock = DockStyle.Fill;
            panel52.Location = new Point(1, 1);
            panel52.Margin = new Padding(0);
            panel52.Name = "panel52";
            panel52.Size = new Size(188, 21);
            panel52.TabIndex = 15;
            // 
            // tableLayoutPanel14
            // 
            tableLayoutPanel14.BackColor = Color.White;
            tableLayoutPanel14.CellBorderStyle = TableLayoutPanelCellBorderStyle.Single;
            tableLayoutPanel14.ColumnCount = 1;
            tableLayoutPanel14.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tableLayoutPanel14.Controls.Add(panel53, 0, 3);
            tableLayoutPanel14.Controls.Add(panel54, 0, 2);
            tableLayoutPanel14.Controls.Add(panel55, 0, 1);
            tableLayoutPanel14.Controls.Add(panel56, 0, 0);
            tableLayoutPanel14.Location = new Point(202, 203);
            tableLayoutPanel14.Margin = new Padding(0);
            tableLayoutPanel14.Name = "tableLayoutPanel14";
            tableLayoutPanel14.RowCount = 4;
            tableLayoutPanel14.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel14.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel14.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel14.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel14.Size = new Size(190, 90);
            tableLayoutPanel14.TabIndex = 66;
            // 
            // panel53
            // 
            panel53.Dock = DockStyle.Fill;
            panel53.Location = new Point(1, 67);
            panel53.Margin = new Padding(0);
            panel53.Name = "panel53";
            panel53.Size = new Size(188, 22);
            panel53.TabIndex = 18;
            // 
            // panel54
            // 
            panel54.Dock = DockStyle.Fill;
            panel54.Location = new Point(1, 45);
            panel54.Margin = new Padding(0);
            panel54.Name = "panel54";
            panel54.Size = new Size(188, 21);
            panel54.TabIndex = 17;
            // 
            // panel55
            // 
            panel55.Dock = DockStyle.Fill;
            panel55.Location = new Point(1, 23);
            panel55.Margin = new Padding(0);
            panel55.Name = "panel55";
            panel55.Size = new Size(188, 21);
            panel55.TabIndex = 16;
            // 
            // panel56
            // 
            panel56.Dock = DockStyle.Fill;
            panel56.Location = new Point(1, 1);
            panel56.Margin = new Padding(0);
            panel56.Name = "panel56";
            panel56.Size = new Size(188, 21);
            panel56.TabIndex = 15;
            // 
            // tableLayoutPanel15
            // 
            tableLayoutPanel15.BackColor = Color.White;
            tableLayoutPanel15.CellBorderStyle = TableLayoutPanelCellBorderStyle.Single;
            tableLayoutPanel15.ColumnCount = 1;
            tableLayoutPanel15.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tableLayoutPanel15.Controls.Add(panel57, 0, 3);
            tableLayoutPanel15.Controls.Add(panel58, 0, 2);
            tableLayoutPanel15.Controls.Add(panel59, 0, 1);
            tableLayoutPanel15.Controls.Add(panel60, 0, 0);
            tableLayoutPanel15.Location = new Point(403, 203);
            tableLayoutPanel15.Margin = new Padding(0);
            tableLayoutPanel15.Name = "tableLayoutPanel15";
            tableLayoutPanel15.RowCount = 4;
            tableLayoutPanel15.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel15.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel15.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel15.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel15.Size = new Size(190, 90);
            tableLayoutPanel15.TabIndex = 67;
            // 
            // panel57
            // 
            panel57.Dock = DockStyle.Fill;
            panel57.Location = new Point(1, 67);
            panel57.Margin = new Padding(0);
            panel57.Name = "panel57";
            panel57.Size = new Size(188, 22);
            panel57.TabIndex = 18;
            // 
            // panel58
            // 
            panel58.Dock = DockStyle.Fill;
            panel58.Location = new Point(1, 45);
            panel58.Margin = new Padding(0);
            panel58.Name = "panel58";
            panel58.Size = new Size(188, 21);
            panel58.TabIndex = 17;
            // 
            // panel59
            // 
            panel59.Dock = DockStyle.Fill;
            panel59.Location = new Point(1, 23);
            panel59.Margin = new Padding(0);
            panel59.Name = "panel59";
            panel59.Size = new Size(188, 21);
            panel59.TabIndex = 16;
            // 
            // panel60
            // 
            panel60.Dock = DockStyle.Fill;
            panel60.Location = new Point(1, 1);
            panel60.Margin = new Padding(0);
            panel60.Name = "panel60";
            panel60.Size = new Size(188, 21);
            panel60.TabIndex = 15;
            // 
            // tableLayoutPanel16
            // 
            tableLayoutPanel16.BackColor = Color.White;
            tableLayoutPanel16.CellBorderStyle = TableLayoutPanelCellBorderStyle.Single;
            tableLayoutPanel16.ColumnCount = 1;
            tableLayoutPanel16.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tableLayoutPanel16.Controls.Add(panel61, 0, 3);
            tableLayoutPanel16.Controls.Add(panel62, 0, 2);
            tableLayoutPanel16.Controls.Add(panel63, 0, 1);
            tableLayoutPanel16.Controls.Add(panel64, 0, 0);
            tableLayoutPanel16.Location = new Point(604, 203);
            tableLayoutPanel16.Margin = new Padding(0);
            tableLayoutPanel16.Name = "tableLayoutPanel16";
            tableLayoutPanel16.RowCount = 4;
            tableLayoutPanel16.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel16.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel16.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel16.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel16.Size = new Size(190, 90);
            tableLayoutPanel16.TabIndex = 68;
            // 
            // panel61
            // 
            panel61.Dock = DockStyle.Fill;
            panel61.Location = new Point(1, 67);
            panel61.Margin = new Padding(0);
            panel61.Name = "panel61";
            panel61.Size = new Size(188, 22);
            panel61.TabIndex = 18;
            // 
            // panel62
            // 
            panel62.Dock = DockStyle.Fill;
            panel62.Location = new Point(1, 45);
            panel62.Margin = new Padding(0);
            panel62.Name = "panel62";
            panel62.Size = new Size(188, 21);
            panel62.TabIndex = 17;
            // 
            // panel63
            // 
            panel63.Dock = DockStyle.Fill;
            panel63.Location = new Point(1, 23);
            panel63.Margin = new Padding(0);
            panel63.Name = "panel63";
            panel63.Size = new Size(188, 21);
            panel63.TabIndex = 16;
            // 
            // panel64
            // 
            panel64.Dock = DockStyle.Fill;
            panel64.Location = new Point(1, 1);
            panel64.Margin = new Padding(0);
            panel64.Name = "panel64";
            panel64.Size = new Size(188, 21);
            panel64.TabIndex = 15;
            // 
            // tableLayoutPanel19
            // 
            tableLayoutPanel19.BackColor = Color.White;
            tableLayoutPanel19.CellBorderStyle = TableLayoutPanelCellBorderStyle.Single;
            tableLayoutPanel19.ColumnCount = 1;
            tableLayoutPanel19.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tableLayoutPanel19.Controls.Add(panel69, 0, 3);
            tableLayoutPanel19.Controls.Add(panel70, 0, 2);
            tableLayoutPanel19.Controls.Add(panel71, 0, 1);
            tableLayoutPanel19.Controls.Add(panel72, 0, 0);
            tableLayoutPanel19.Location = new Point(1, 304);
            tableLayoutPanel19.Margin = new Padding(0);
            tableLayoutPanel19.Name = "tableLayoutPanel19";
            tableLayoutPanel19.RowCount = 4;
            tableLayoutPanel19.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel19.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel19.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel19.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel19.Size = new Size(190, 90);
            tableLayoutPanel19.TabIndex = 70;
            // 
            // panel69
            // 
            panel69.Dock = DockStyle.Fill;
            panel69.Location = new Point(1, 67);
            panel69.Margin = new Padding(0);
            panel69.Name = "panel69";
            panel69.Size = new Size(188, 22);
            panel69.TabIndex = 18;
            // 
            // panel70
            // 
            panel70.Dock = DockStyle.Fill;
            panel70.Location = new Point(1, 45);
            panel70.Margin = new Padding(0);
            panel70.Name = "panel70";
            panel70.Size = new Size(188, 21);
            panel70.TabIndex = 17;
            // 
            // panel71
            // 
            panel71.Dock = DockStyle.Fill;
            panel71.Location = new Point(1, 23);
            panel71.Margin = new Padding(0);
            panel71.Name = "panel71";
            panel71.Size = new Size(188, 21);
            panel71.TabIndex = 16;
            // 
            // panel72
            // 
            panel72.Dock = DockStyle.Fill;
            panel72.Location = new Point(1, 1);
            panel72.Margin = new Padding(0);
            panel72.Name = "panel72";
            panel72.Size = new Size(188, 21);
            panel72.TabIndex = 15;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 24F);
            label2.Location = new Point(163, 9);
            label2.Name = "label2";
            label2.Size = new Size(509, 45);
            label2.TabIndex = 9;
            label2.Text = "Veterinary Appointment Scheduler";
            // 
            // searchBar
            // 
            searchBar.Font = new Font("Segoe UI", 11F);
            searchBar.Location = new Point(917, 9);
            searchBar.Name = "searchBar";
            searchBar.Size = new Size(242, 27);
            searchBar.TabIndex = 10;
            searchBar.Text = "Search For Client First or Last Name";
            searchBar.TextChanged += searchBar_TextChanged;
            // 
            // tableLayoutPanel17
            // 
            tableLayoutPanel17.BackColor = Color.White;
            tableLayoutPanel17.CellBorderStyle = TableLayoutPanelCellBorderStyle.Single;
            tableLayoutPanel17.ColumnCount = 1;
            tableLayoutPanel17.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 20F));
            tableLayoutPanel17.Location = new Point(0, 0);
            tableLayoutPanel17.Name = "tableLayoutPanel17";
            tableLayoutPanel17.RowCount = 4;
            tableLayoutPanel17.RowStyles.Add(new RowStyle(SizeType.Absolute, 20F));
            tableLayoutPanel17.RowStyles.Add(new RowStyle(SizeType.Absolute, 20F));
            tableLayoutPanel17.RowStyles.Add(new RowStyle(SizeType.Absolute, 20F));
            tableLayoutPanel17.RowStyles.Add(new RowStyle(SizeType.Absolute, 20F));
            tableLayoutPanel17.Size = new Size(200, 100);
            tableLayoutPanel17.TabIndex = 0;
            // 
            // tableLayoutPanel30
            // 
            tableLayoutPanel30.BackColor = Color.White;
            tableLayoutPanel30.CellBorderStyle = TableLayoutPanelCellBorderStyle.Single;
            tableLayoutPanel30.ColumnCount = 1;
            tableLayoutPanel30.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 20F));
            tableLayoutPanel30.Location = new Point(0, 0);
            tableLayoutPanel30.Name = "tableLayoutPanel30";
            tableLayoutPanel30.RowCount = 4;
            tableLayoutPanel30.RowStyles.Add(new RowStyle(SizeType.Absolute, 20F));
            tableLayoutPanel30.RowStyles.Add(new RowStyle(SizeType.Absolute, 20F));
            tableLayoutPanel30.RowStyles.Add(new RowStyle(SizeType.Absolute, 20F));
            tableLayoutPanel30.RowStyles.Add(new RowStyle(SizeType.Absolute, 20F));
            tableLayoutPanel30.Size = new Size(200, 100);
            tableLayoutPanel30.TabIndex = 0;
            // 
            // tableLayoutPanel59
            // 
            tableLayoutPanel59.CellBorderStyle = TableLayoutPanelCellBorderStyle.Single;
            tableLayoutPanel59.ColumnCount = 1;
            tableLayoutPanel59.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tableLayoutPanel59.Controls.Add(label17, 0, 8);
            tableLayoutPanel59.Controls.Add(label16, 0, 7);
            tableLayoutPanel59.Controls.Add(label15, 0, 6);
            tableLayoutPanel59.Controls.Add(label14, 0, 5);
            tableLayoutPanel59.Controls.Add(label13, 0, 4);
            tableLayoutPanel59.Controls.Add(label12, 0, 3);
            tableLayoutPanel59.Controls.Add(label11, 0, 2);
            tableLayoutPanel59.Controls.Add(label10, 0, 1);
            tableLayoutPanel59.Controls.Add(label9, 0, 0);
            tableLayoutPanel59.Location = new Point(44, 197);
            tableLayoutPanel59.Name = "tableLayoutPanel59";
            tableLayoutPanel59.RowCount = 9;
            tableLayoutPanel59.RowStyles.Add(new RowStyle(SizeType.Absolute, 100F));
            tableLayoutPanel59.RowStyles.Add(new RowStyle(SizeType.Absolute, 100F));
            tableLayoutPanel59.RowStyles.Add(new RowStyle(SizeType.Absolute, 100F));
            tableLayoutPanel59.RowStyles.Add(new RowStyle(SizeType.Absolute, 100F));
            tableLayoutPanel59.RowStyles.Add(new RowStyle(SizeType.Absolute, 100F));
            tableLayoutPanel59.RowStyles.Add(new RowStyle(SizeType.Absolute, 100F));
            tableLayoutPanel59.RowStyles.Add(new RowStyle(SizeType.Absolute, 100F));
            tableLayoutPanel59.RowStyles.Add(new RowStyle(SizeType.Absolute, 100F));
            tableLayoutPanel59.RowStyles.Add(new RowStyle(SizeType.Absolute, 100F));
            tableLayoutPanel59.Size = new Size(67, 902);
            tableLayoutPanel59.TabIndex = 11;
            // 
            // label17
            // 
            label17.AutoSize = true;
            label17.Font = new Font("Segoe UI", 11F);
            label17.Location = new Point(1, 809);
            label17.Margin = new Padding(0);
            label17.Name = "label17";
            label17.Size = new Size(43, 20);
            label17.TabIndex = 20;
            label17.Text = "5 pm";
            // 
            // label16
            // 
            label16.AutoSize = true;
            label16.Font = new Font("Segoe UI", 11F);
            label16.Location = new Point(1, 708);
            label16.Margin = new Padding(0);
            label16.Name = "label16";
            label16.Size = new Size(43, 20);
            label16.TabIndex = 19;
            label16.Text = "4 pm";
            // 
            // label15
            // 
            label15.AutoSize = true;
            label15.Font = new Font("Segoe UI", 11F);
            label15.Location = new Point(1, 607);
            label15.Margin = new Padding(0);
            label15.Name = "label15";
            label15.Size = new Size(43, 20);
            label15.TabIndex = 18;
            label15.Text = "3 pm";
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.Font = new Font("Segoe UI", 11F);
            label14.Location = new Point(1, 506);
            label14.Margin = new Padding(0);
            label14.Name = "label14";
            label14.Size = new Size(43, 20);
            label14.TabIndex = 17;
            label14.Text = "2 pm";
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Font = new Font("Segoe UI", 11F);
            label13.Location = new Point(1, 405);
            label13.Margin = new Padding(0);
            label13.Name = "label13";
            label13.Size = new Size(43, 20);
            label13.TabIndex = 16;
            label13.Text = "1 pm";
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Font = new Font("Segoe UI", 11F);
            label12.Location = new Point(1, 304);
            label12.Margin = new Padding(0);
            label12.Name = "label12";
            label12.Size = new Size(51, 20);
            label12.TabIndex = 15;
            label12.Text = "12 pm";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Font = new Font("Segoe UI", 11F);
            label11.Location = new Point(1, 203);
            label11.Margin = new Padding(0);
            label11.Name = "label11";
            label11.Size = new Size(50, 20);
            label11.TabIndex = 14;
            label11.Text = "11 am";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Font = new Font("Segoe UI", 11F);
            label10.Location = new Point(1, 102);
            label10.Margin = new Padding(0);
            label10.Name = "label10";
            label10.Size = new Size(50, 20);
            label10.TabIndex = 13;
            label10.Text = "10 am";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Segoe UI", 11F);
            label9.Location = new Point(1, 1);
            label9.Margin = new Padding(0);
            label9.Name = "label9";
            label9.Size = new Size(42, 20);
            label9.TabIndex = 12;
            label9.Text = "9 am";
            // 
            // NextButton
            // 
            NextButton.Location = new Point(1048, 139);
            NextButton.Name = "NextButton";
            NextButton.Size = new Size(75, 23);
            NextButton.TabIndex = 12;
            NextButton.Text = "Next";
            NextButton.UseVisualStyleBackColor = true;
            NextButton.Click += NextButton_Click;
            // 
            // PrevButton
            // 
            PrevButton.Location = new Point(967, 139);
            PrevButton.Name = "PrevButton";
            PrevButton.Size = new Size(75, 23);
            PrevButton.TabIndex = 13;
            PrevButton.Text = "Prev";
            PrevButton.UseVisualStyleBackColor = true;
            PrevButton.Click += PrevButton_Click;
            // 
            // CalenderDateLabel
            // 
            CalenderDateLabel.AutoSize = true;
            CalenderDateLabel.Font = new Font("Segoe UI", 11F);
            CalenderDateLabel.Location = new Point(539, 139);
            CalenderDateLabel.Name = "CalenderDateLabel";
            CalenderDateLabel.Size = new Size(167, 20);
            CalenderDateLabel.TabIndex = 14;
            CalenderDateLabel.Text = "Wednesday, Feb 7, 2024";
            // 
            // tableLayoutPanel3
            // 
            tableLayoutPanel3.BackColor = Color.White;
            tableLayoutPanel3.CellBorderStyle = TableLayoutPanelCellBorderStyle.Single;
            tableLayoutPanel3.ColumnCount = 1;
            tableLayoutPanel3.Location = new Point(0, 0);
            tableLayoutPanel3.Margin = new Padding(5);
            tableLayoutPanel3.Name = "tableLayoutPanel3";
            tableLayoutPanel3.RowCount = 4;
            tableLayoutPanel3.Size = new Size(200, 100);
            tableLayoutPanel3.TabIndex = 0;
            // 
            // tableLayoutPanel22
            // 
            tableLayoutPanel22.CellBorderStyle = TableLayoutPanelCellBorderStyle.Single;
            tableLayoutPanel22.ColumnCount = 6;
            tableLayoutPanel22.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 200F));
            tableLayoutPanel22.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 200F));
            tableLayoutPanel22.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 200F));
            tableLayoutPanel22.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 200F));
            tableLayoutPanel22.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 200F));
            tableLayoutPanel22.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 200F));
            tableLayoutPanel22.Controls.Add(tableLayoutPanel61, 0, 0);
            tableLayoutPanel22.Controls.Add(tableLayoutPanel62, 2, 1);
            tableLayoutPanel22.Controls.Add(tableLayoutPanel63, 0, 8);
            tableLayoutPanel22.Controls.Add(tableLayoutPanel64, 0, 8);
            tableLayoutPanel22.Controls.Add(tableLayoutPanel65, 0, 8);
            tableLayoutPanel22.Controls.Add(tableLayoutPanel66, 0, 8);
            tableLayoutPanel22.Controls.Add(tableLayoutPanel67, 0, 8);
            tableLayoutPanel22.Controls.Add(tableLayoutPanel68, 0, 8);
            tableLayoutPanel22.Controls.Add(tableLayoutPanel69, 0, 3);
            tableLayoutPanel22.Controls.Add(tableLayoutPanel70, 0, 3);
            tableLayoutPanel22.Controls.Add(tableLayoutPanel71, 0, 3);
            tableLayoutPanel22.Controls.Add(tableLayoutPanel72, 0, 2);
            tableLayoutPanel22.Controls.Add(tableLayoutPanel73, 0, 3);
            tableLayoutPanel22.Controls.Add(tableLayoutPanel74, 0, 3);
            tableLayoutPanel22.Controls.Add(tableLayoutPanel75, 4, 0);
            tableLayoutPanel22.Controls.Add(tableLayoutPanel76, 4, 1);
            tableLayoutPanel22.Controls.Add(tableLayoutPanel77, 1, 1);
            tableLayoutPanel22.Controls.Add(tableLayoutPanel78, 3, 0);
            tableLayoutPanel22.Controls.Add(tableLayoutPanel79, 3, 1);
            tableLayoutPanel22.Controls.Add(tableLayoutPanel80, 0, 2);
            tableLayoutPanel22.Controls.Add(tableLayoutPanel81, 3, 2);
            tableLayoutPanel22.Controls.Add(tableLayoutPanel82, 2, 2);
            tableLayoutPanel22.Controls.Add(tableLayoutPanel83, 1, 2);
            tableLayoutPanel22.Controls.Add(tableLayoutPanel84, 5, 0);
            tableLayoutPanel22.Controls.Add(tableLayoutPanel85, 5, 1);
            tableLayoutPanel22.Controls.Add(tableLayoutPanel86, 5, 2);
            tableLayoutPanel22.Controls.Add(tableLayoutPanel87, 0, 4);
            tableLayoutPanel22.Controls.Add(tableLayoutPanel88, 1, 4);
            tableLayoutPanel22.Controls.Add(tableLayoutPanel89, 2, 4);
            tableLayoutPanel22.Controls.Add(tableLayoutPanel90, 3, 3);
            tableLayoutPanel22.Controls.Add(tableLayoutPanel91, 3, 4);
            tableLayoutPanel22.Controls.Add(tableLayoutPanel92, 4, 4);
            tableLayoutPanel22.Controls.Add(tableLayoutPanel93, 5, 4);
            tableLayoutPanel22.Controls.Add(tableLayoutPanel94, 0, 5);
            tableLayoutPanel22.Controls.Add(tableLayoutPanel95, 1, 5);
            tableLayoutPanel22.Controls.Add(tableLayoutPanel96, 3, 5);
            tableLayoutPanel22.Controls.Add(tableLayoutPanel97, 4, 5);
            tableLayoutPanel22.Controls.Add(tableLayoutPanel98, 5, 5);
            tableLayoutPanel22.Controls.Add(tableLayoutPanel99, 1, 6);
            tableLayoutPanel22.Controls.Add(tableLayoutPanel100, 2, 5);
            tableLayoutPanel22.Controls.Add(tableLayoutPanel101, 2, 6);
            tableLayoutPanel22.Controls.Add(tableLayoutPanel102, 3, 6);
            tableLayoutPanel22.Controls.Add(tableLayoutPanel103, 4, 6);
            tableLayoutPanel22.Controls.Add(tableLayoutPanel104, 5, 6);
            tableLayoutPanel22.Controls.Add(tableLayoutPanel105, 0, 6);
            tableLayoutPanel22.Controls.Add(tableLayoutPanel106, 0, 7);
            tableLayoutPanel22.Controls.Add(tableLayoutPanel107, 1, 7);
            tableLayoutPanel22.Controls.Add(tableLayoutPanel108, 2, 7);
            tableLayoutPanel22.Controls.Add(tableLayoutPanel109, 3, 7);
            tableLayoutPanel22.Controls.Add(tableLayoutPanel110, 4, 7);
            tableLayoutPanel22.Controls.Add(tableLayoutPanel111, 5, 7);
            tableLayoutPanel22.Controls.Add(tableLayoutPanel112, 2, 0);
            tableLayoutPanel22.Location = new Point(0, 0);
            tableLayoutPanel22.Name = "tableLayoutPanel22";
            tableLayoutPanel22.RowCount = 9;
            tableLayoutPanel22.Size = new Size(200, 100);
            tableLayoutPanel22.TabIndex = 0;
            // 
            // tableLayoutPanel61
            // 
            tableLayoutPanel61.BackColor = Color.White;
            tableLayoutPanel61.CellBorderStyle = TableLayoutPanelCellBorderStyle.Single;
            tableLayoutPanel61.ColumnCount = 1;
            tableLayoutPanel61.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tableLayoutPanel61.Controls.Add(panel5, 0, 3);
            tableLayoutPanel61.Controls.Add(panel6, 0, 2);
            tableLayoutPanel61.Controls.Add(panel7, 0, 1);
            tableLayoutPanel61.Controls.Add(panel8, 0, 0);
            tableLayoutPanel61.Dock = DockStyle.Fill;
            tableLayoutPanel61.Location = new Point(1, 1);
            tableLayoutPanel61.Margin = new Padding(0);
            tableLayoutPanel61.Name = "tableLayoutPanel61";
            tableLayoutPanel61.RowCount = 4;
            tableLayoutPanel61.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel61.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel61.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel61.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel61.Size = new Size(200, 100);
            tableLayoutPanel61.TabIndex = 10;
            // 
            // panel5
            // 
            panel5.Dock = DockStyle.Fill;
            panel5.Location = new Point(1, 73);
            panel5.Margin = new Padding(0);
            panel5.Name = "panel5";
            panel5.Size = new Size(198, 26);
            panel5.TabIndex = 18;
            // 
            // panel6
            // 
            panel6.Dock = DockStyle.Fill;
            panel6.Location = new Point(1, 49);
            panel6.Margin = new Padding(0);
            panel6.Name = "panel6";
            panel6.Size = new Size(198, 23);
            panel6.TabIndex = 17;
            // 
            // panel7
            // 
            panel7.Dock = DockStyle.Fill;
            panel7.Location = new Point(1, 25);
            panel7.Margin = new Padding(0);
            panel7.Name = "panel7";
            panel7.Size = new Size(198, 23);
            panel7.TabIndex = 16;
            // 
            // panel8
            // 
            panel8.Dock = DockStyle.Fill;
            panel8.Location = new Point(1, 1);
            panel8.Margin = new Padding(0);
            panel8.Name = "panel8";
            panel8.Size = new Size(198, 23);
            panel8.TabIndex = 15;
            // 
            // tableLayoutPanel62
            // 
            tableLayoutPanel62.BackColor = Color.White;
            tableLayoutPanel62.CellBorderStyle = TableLayoutPanelCellBorderStyle.Single;
            tableLayoutPanel62.ColumnCount = 1;
            tableLayoutPanel62.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tableLayoutPanel62.Location = new Point(408, 107);
            tableLayoutPanel62.Margin = new Padding(5);
            tableLayoutPanel62.Name = "tableLayoutPanel62";
            tableLayoutPanel62.RowCount = 4;
            tableLayoutPanel62.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel62.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel62.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel62.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel62.Size = new Size(190, 90);
            tableLayoutPanel62.TabIndex = 11;
            // 
            // tableLayoutPanel63
            // 
            tableLayoutPanel63.BackColor = Color.White;
            tableLayoutPanel63.CellBorderStyle = TableLayoutPanelCellBorderStyle.Single;
            tableLayoutPanel63.ColumnCount = 1;
            tableLayoutPanel63.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tableLayoutPanel63.Dock = DockStyle.Fill;
            tableLayoutPanel63.Location = new Point(1, 809);
            tableLayoutPanel63.Margin = new Padding(0);
            tableLayoutPanel63.Name = "tableLayoutPanel63";
            tableLayoutPanel63.RowCount = 4;
            tableLayoutPanel63.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel63.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel63.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel63.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel63.Size = new Size(200, 104);
            tableLayoutPanel63.TabIndex = 54;
            // 
            // tableLayoutPanel64
            // 
            tableLayoutPanel64.BackColor = Color.White;
            tableLayoutPanel64.CellBorderStyle = TableLayoutPanelCellBorderStyle.Single;
            tableLayoutPanel64.ColumnCount = 1;
            tableLayoutPanel64.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tableLayoutPanel64.Dock = DockStyle.Fill;
            tableLayoutPanel64.Location = new Point(1006, 809);
            tableLayoutPanel64.Margin = new Padding(0);
            tableLayoutPanel64.Name = "tableLayoutPanel64";
            tableLayoutPanel64.RowCount = 4;
            tableLayoutPanel64.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel64.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel64.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel64.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel64.Size = new Size(200, 104);
            tableLayoutPanel64.TabIndex = 53;
            // 
            // tableLayoutPanel65
            // 
            tableLayoutPanel65.BackColor = Color.White;
            tableLayoutPanel65.CellBorderStyle = TableLayoutPanelCellBorderStyle.Single;
            tableLayoutPanel65.ColumnCount = 1;
            tableLayoutPanel65.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tableLayoutPanel65.Dock = DockStyle.Fill;
            tableLayoutPanel65.Location = new Point(604, 809);
            tableLayoutPanel65.Margin = new Padding(0);
            tableLayoutPanel65.Name = "tableLayoutPanel65";
            tableLayoutPanel65.RowCount = 4;
            tableLayoutPanel65.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel65.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel65.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel65.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel65.Size = new Size(200, 104);
            tableLayoutPanel65.TabIndex = 52;
            // 
            // tableLayoutPanel66
            // 
            tableLayoutPanel66.BackColor = Color.White;
            tableLayoutPanel66.CellBorderStyle = TableLayoutPanelCellBorderStyle.Single;
            tableLayoutPanel66.ColumnCount = 1;
            tableLayoutPanel66.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tableLayoutPanel66.Location = new Point(202, 809);
            tableLayoutPanel66.Margin = new Padding(0);
            tableLayoutPanel66.Name = "tableLayoutPanel66";
            tableLayoutPanel66.RowCount = 4;
            tableLayoutPanel66.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel66.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel66.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel66.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel66.Size = new Size(179, 104);
            tableLayoutPanel66.TabIndex = 51;
            // 
            // tableLayoutPanel67
            // 
            tableLayoutPanel67.BackColor = Color.White;
            tableLayoutPanel67.CellBorderStyle = TableLayoutPanelCellBorderStyle.Single;
            tableLayoutPanel67.ColumnCount = 1;
            tableLayoutPanel67.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tableLayoutPanel67.Dock = DockStyle.Fill;
            tableLayoutPanel67.Location = new Point(403, 809);
            tableLayoutPanel67.Margin = new Padding(0);
            tableLayoutPanel67.Name = "tableLayoutPanel67";
            tableLayoutPanel67.RowCount = 4;
            tableLayoutPanel67.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel67.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel67.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel67.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel67.Size = new Size(200, 104);
            tableLayoutPanel67.TabIndex = 50;
            // 
            // tableLayoutPanel68
            // 
            tableLayoutPanel68.BackColor = Color.White;
            tableLayoutPanel68.CellBorderStyle = TableLayoutPanelCellBorderStyle.Single;
            tableLayoutPanel68.ColumnCount = 1;
            tableLayoutPanel68.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tableLayoutPanel68.Dock = DockStyle.Fill;
            tableLayoutPanel68.Location = new Point(805, 809);
            tableLayoutPanel68.Margin = new Padding(0);
            tableLayoutPanel68.Name = "tableLayoutPanel68";
            tableLayoutPanel68.RowCount = 4;
            tableLayoutPanel68.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel68.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel68.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel68.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel68.Size = new Size(200, 104);
            tableLayoutPanel68.TabIndex = 49;
            // 
            // tableLayoutPanel69
            // 
            tableLayoutPanel69.BackColor = Color.White;
            tableLayoutPanel69.CellBorderStyle = TableLayoutPanelCellBorderStyle.Single;
            tableLayoutPanel69.ColumnCount = 1;
            tableLayoutPanel69.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tableLayoutPanel69.Dock = DockStyle.Fill;
            tableLayoutPanel69.Location = new Point(1, 304);
            tableLayoutPanel69.Margin = new Padding(0);
            tableLayoutPanel69.Name = "tableLayoutPanel69";
            tableLayoutPanel69.RowCount = 4;
            tableLayoutPanel69.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel69.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel69.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel69.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel69.Size = new Size(200, 100);
            tableLayoutPanel69.TabIndex = 24;
            // 
            // tableLayoutPanel70
            // 
            tableLayoutPanel70.BackColor = Color.White;
            tableLayoutPanel70.CellBorderStyle = TableLayoutPanelCellBorderStyle.Single;
            tableLayoutPanel70.ColumnCount = 1;
            tableLayoutPanel70.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tableLayoutPanel70.Dock = DockStyle.Fill;
            tableLayoutPanel70.Location = new Point(403, 304);
            tableLayoutPanel70.Margin = new Padding(0);
            tableLayoutPanel70.Name = "tableLayoutPanel70";
            tableLayoutPanel70.RowCount = 4;
            tableLayoutPanel70.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel70.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel70.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel70.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel70.Size = new Size(200, 100);
            tableLayoutPanel70.TabIndex = 22;
            // 
            // tableLayoutPanel71
            // 
            tableLayoutPanel71.BackColor = Color.White;
            tableLayoutPanel71.CellBorderStyle = TableLayoutPanelCellBorderStyle.Single;
            tableLayoutPanel71.ColumnCount = 1;
            tableLayoutPanel71.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tableLayoutPanel71.Dock = DockStyle.Fill;
            tableLayoutPanel71.Location = new Point(805, 304);
            tableLayoutPanel71.Margin = new Padding(0);
            tableLayoutPanel71.Name = "tableLayoutPanel71";
            tableLayoutPanel71.RowCount = 4;
            tableLayoutPanel71.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel71.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel71.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel71.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel71.Size = new Size(200, 100);
            tableLayoutPanel71.TabIndex = 21;
            // 
            // tableLayoutPanel72
            // 
            tableLayoutPanel72.BackColor = Color.White;
            tableLayoutPanel72.CellBorderStyle = TableLayoutPanelCellBorderStyle.Single;
            tableLayoutPanel72.ColumnCount = 1;
            tableLayoutPanel72.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tableLayoutPanel72.Dock = DockStyle.Fill;
            tableLayoutPanel72.Location = new Point(1, 203);
            tableLayoutPanel72.Margin = new Padding(0);
            tableLayoutPanel72.Name = "tableLayoutPanel72";
            tableLayoutPanel72.RowCount = 4;
            tableLayoutPanel72.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel72.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel72.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel72.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel72.Size = new Size(200, 100);
            tableLayoutPanel72.TabIndex = 20;
            // 
            // tableLayoutPanel73
            // 
            tableLayoutPanel73.BackColor = Color.White;
            tableLayoutPanel73.CellBorderStyle = TableLayoutPanelCellBorderStyle.Single;
            tableLayoutPanel73.ColumnCount = 1;
            tableLayoutPanel73.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tableLayoutPanel73.Dock = DockStyle.Fill;
            tableLayoutPanel73.Location = new Point(202, 304);
            tableLayoutPanel73.Margin = new Padding(0);
            tableLayoutPanel73.Name = "tableLayoutPanel73";
            tableLayoutPanel73.RowCount = 4;
            tableLayoutPanel73.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel73.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel73.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel73.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel73.Size = new Size(200, 100);
            tableLayoutPanel73.TabIndex = 18;
            // 
            // tableLayoutPanel74
            // 
            tableLayoutPanel74.BackColor = Color.White;
            tableLayoutPanel74.CellBorderStyle = TableLayoutPanelCellBorderStyle.Single;
            tableLayoutPanel74.ColumnCount = 1;
            tableLayoutPanel74.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tableLayoutPanel74.Dock = DockStyle.Fill;
            tableLayoutPanel74.Location = new Point(604, 304);
            tableLayoutPanel74.Margin = new Padding(0);
            tableLayoutPanel74.Name = "tableLayoutPanel74";
            tableLayoutPanel74.RowCount = 4;
            tableLayoutPanel74.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel74.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel74.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel74.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel74.Size = new Size(200, 100);
            tableLayoutPanel74.TabIndex = 15;
            // 
            // tableLayoutPanel75
            // 
            tableLayoutPanel75.BackColor = Color.White;
            tableLayoutPanel75.CellBorderStyle = TableLayoutPanelCellBorderStyle.Single;
            tableLayoutPanel75.ColumnCount = 1;
            tableLayoutPanel75.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tableLayoutPanel75.Location = new Point(810, 6);
            tableLayoutPanel75.Margin = new Padding(5);
            tableLayoutPanel75.Name = "tableLayoutPanel75";
            tableLayoutPanel75.RowCount = 4;
            tableLayoutPanel75.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel75.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel75.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel75.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel75.Size = new Size(190, 90);
            tableLayoutPanel75.TabIndex = 3;
            // 
            // tableLayoutPanel76
            // 
            tableLayoutPanel76.BackColor = Color.White;
            tableLayoutPanel76.CellBorderStyle = TableLayoutPanelCellBorderStyle.Single;
            tableLayoutPanel76.ColumnCount = 1;
            tableLayoutPanel76.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tableLayoutPanel76.Location = new Point(810, 107);
            tableLayoutPanel76.Margin = new Padding(5);
            tableLayoutPanel76.Name = "tableLayoutPanel76";
            tableLayoutPanel76.RowCount = 4;
            tableLayoutPanel76.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel76.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel76.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel76.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel76.Size = new Size(190, 90);
            tableLayoutPanel76.TabIndex = 2;
            // 
            // tableLayoutPanel77
            // 
            tableLayoutPanel77.BackColor = Color.White;
            tableLayoutPanel77.CellBorderStyle = TableLayoutPanelCellBorderStyle.Single;
            tableLayoutPanel77.ColumnCount = 1;
            tableLayoutPanel77.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tableLayoutPanel77.Location = new Point(207, 107);
            tableLayoutPanel77.Margin = new Padding(5);
            tableLayoutPanel77.Name = "tableLayoutPanel77";
            tableLayoutPanel77.RowCount = 4;
            tableLayoutPanel77.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel77.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel77.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel77.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel77.Size = new Size(190, 90);
            tableLayoutPanel77.TabIndex = 4;
            // 
            // tableLayoutPanel78
            // 
            tableLayoutPanel78.BackColor = Color.White;
            tableLayoutPanel78.CellBorderStyle = TableLayoutPanelCellBorderStyle.Single;
            tableLayoutPanel78.ColumnCount = 1;
            tableLayoutPanel78.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tableLayoutPanel78.Location = new Point(609, 6);
            tableLayoutPanel78.Margin = new Padding(5);
            tableLayoutPanel78.Name = "tableLayoutPanel78";
            tableLayoutPanel78.RowCount = 4;
            tableLayoutPanel78.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel78.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel78.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel78.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel78.Size = new Size(190, 90);
            tableLayoutPanel78.TabIndex = 6;
            // 
            // tableLayoutPanel79
            // 
            tableLayoutPanel79.BackColor = Color.White;
            tableLayoutPanel79.CellBorderStyle = TableLayoutPanelCellBorderStyle.Single;
            tableLayoutPanel79.ColumnCount = 1;
            tableLayoutPanel79.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tableLayoutPanel79.Location = new Point(609, 107);
            tableLayoutPanel79.Margin = new Padding(5);
            tableLayoutPanel79.Name = "tableLayoutPanel79";
            tableLayoutPanel79.RowCount = 4;
            tableLayoutPanel79.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel79.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel79.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel79.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel79.Size = new Size(190, 90);
            tableLayoutPanel79.TabIndex = 7;
            // 
            // tableLayoutPanel80
            // 
            tableLayoutPanel80.BackColor = Color.White;
            tableLayoutPanel80.CellBorderStyle = TableLayoutPanelCellBorderStyle.Single;
            tableLayoutPanel80.ColumnCount = 1;
            tableLayoutPanel80.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tableLayoutPanel80.Dock = DockStyle.Fill;
            tableLayoutPanel80.Location = new Point(202, 203);
            tableLayoutPanel80.Margin = new Padding(0);
            tableLayoutPanel80.Name = "tableLayoutPanel80";
            tableLayoutPanel80.RowCount = 4;
            tableLayoutPanel80.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel80.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel80.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel80.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel80.Size = new Size(200, 100);
            tableLayoutPanel80.TabIndex = 8;
            // 
            // tableLayoutPanel81
            // 
            tableLayoutPanel81.BackColor = Color.White;
            tableLayoutPanel81.CellBorderStyle = TableLayoutPanelCellBorderStyle.Single;
            tableLayoutPanel81.ColumnCount = 1;
            tableLayoutPanel81.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tableLayoutPanel81.Dock = DockStyle.Fill;
            tableLayoutPanel81.Location = new Point(805, 203);
            tableLayoutPanel81.Margin = new Padding(0);
            tableLayoutPanel81.Name = "tableLayoutPanel81";
            tableLayoutPanel81.RowCount = 4;
            tableLayoutPanel81.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel81.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel81.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel81.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel81.Size = new Size(200, 100);
            tableLayoutPanel81.TabIndex = 13;
            // 
            // tableLayoutPanel82
            // 
            tableLayoutPanel82.BackColor = Color.White;
            tableLayoutPanel82.CellBorderStyle = TableLayoutPanelCellBorderStyle.Single;
            tableLayoutPanel82.ColumnCount = 1;
            tableLayoutPanel82.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tableLayoutPanel82.Dock = DockStyle.Fill;
            tableLayoutPanel82.Location = new Point(604, 203);
            tableLayoutPanel82.Margin = new Padding(0);
            tableLayoutPanel82.Name = "tableLayoutPanel82";
            tableLayoutPanel82.RowCount = 4;
            tableLayoutPanel82.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel82.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel82.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel82.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel82.Size = new Size(200, 100);
            tableLayoutPanel82.TabIndex = 14;
            // 
            // tableLayoutPanel83
            // 
            tableLayoutPanel83.BackColor = Color.White;
            tableLayoutPanel83.CellBorderStyle = TableLayoutPanelCellBorderStyle.Single;
            tableLayoutPanel83.ColumnCount = 1;
            tableLayoutPanel83.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tableLayoutPanel83.Dock = DockStyle.Fill;
            tableLayoutPanel83.Location = new Point(403, 203);
            tableLayoutPanel83.Margin = new Padding(0);
            tableLayoutPanel83.Name = "tableLayoutPanel83";
            tableLayoutPanel83.RowCount = 4;
            tableLayoutPanel83.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel83.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel83.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel83.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel83.Size = new Size(200, 100);
            tableLayoutPanel83.TabIndex = 11;
            // 
            // tableLayoutPanel84
            // 
            tableLayoutPanel84.BackColor = Color.White;
            tableLayoutPanel84.CellBorderStyle = TableLayoutPanelCellBorderStyle.Single;
            tableLayoutPanel84.ColumnCount = 1;
            tableLayoutPanel84.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tableLayoutPanel84.Location = new Point(1011, 6);
            tableLayoutPanel84.Margin = new Padding(5);
            tableLayoutPanel84.Name = "tableLayoutPanel84";
            tableLayoutPanel84.RowCount = 4;
            tableLayoutPanel84.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel84.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel84.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel84.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel84.Size = new Size(190, 90);
            tableLayoutPanel84.TabIndex = 12;
            // 
            // tableLayoutPanel85
            // 
            tableLayoutPanel85.BackColor = Color.White;
            tableLayoutPanel85.CellBorderStyle = TableLayoutPanelCellBorderStyle.Single;
            tableLayoutPanel85.ColumnCount = 1;
            tableLayoutPanel85.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tableLayoutPanel85.Location = new Point(1011, 107);
            tableLayoutPanel85.Margin = new Padding(5);
            tableLayoutPanel85.Name = "tableLayoutPanel85";
            tableLayoutPanel85.RowCount = 4;
            tableLayoutPanel85.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel85.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel85.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel85.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel85.Size = new Size(190, 90);
            tableLayoutPanel85.TabIndex = 19;
            // 
            // tableLayoutPanel86
            // 
            tableLayoutPanel86.BackColor = Color.White;
            tableLayoutPanel86.CellBorderStyle = TableLayoutPanelCellBorderStyle.Single;
            tableLayoutPanel86.ColumnCount = 1;
            tableLayoutPanel86.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tableLayoutPanel86.Dock = DockStyle.Fill;
            tableLayoutPanel86.Location = new Point(1006, 203);
            tableLayoutPanel86.Margin = new Padding(0);
            tableLayoutPanel86.Name = "tableLayoutPanel86";
            tableLayoutPanel86.RowCount = 4;
            tableLayoutPanel86.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel86.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel86.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel86.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel86.Size = new Size(200, 100);
            tableLayoutPanel86.TabIndex = 16;
            // 
            // tableLayoutPanel87
            // 
            tableLayoutPanel87.BackColor = Color.White;
            tableLayoutPanel87.CellBorderStyle = TableLayoutPanelCellBorderStyle.Single;
            tableLayoutPanel87.ColumnCount = 1;
            tableLayoutPanel87.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tableLayoutPanel87.Dock = DockStyle.Fill;
            tableLayoutPanel87.Location = new Point(1, 405);
            tableLayoutPanel87.Margin = new Padding(0);
            tableLayoutPanel87.Name = "tableLayoutPanel87";
            tableLayoutPanel87.RowCount = 4;
            tableLayoutPanel87.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel87.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel87.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel87.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel87.Size = new Size(200, 100);
            tableLayoutPanel87.TabIndex = 28;
            // 
            // tableLayoutPanel88
            // 
            tableLayoutPanel88.BackColor = Color.White;
            tableLayoutPanel88.CellBorderStyle = TableLayoutPanelCellBorderStyle.Single;
            tableLayoutPanel88.ColumnCount = 1;
            tableLayoutPanel88.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tableLayoutPanel88.Dock = DockStyle.Fill;
            tableLayoutPanel88.Location = new Point(202, 405);
            tableLayoutPanel88.Margin = new Padding(0);
            tableLayoutPanel88.Name = "tableLayoutPanel88";
            tableLayoutPanel88.RowCount = 4;
            tableLayoutPanel88.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel88.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel88.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel88.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel88.Size = new Size(200, 100);
            tableLayoutPanel88.TabIndex = 29;
            // 
            // tableLayoutPanel89
            // 
            tableLayoutPanel89.BackColor = Color.White;
            tableLayoutPanel89.CellBorderStyle = TableLayoutPanelCellBorderStyle.Single;
            tableLayoutPanel89.ColumnCount = 1;
            tableLayoutPanel89.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tableLayoutPanel89.Dock = DockStyle.Fill;
            tableLayoutPanel89.Location = new Point(403, 405);
            tableLayoutPanel89.Margin = new Padding(0);
            tableLayoutPanel89.Name = "tableLayoutPanel89";
            tableLayoutPanel89.RowCount = 4;
            tableLayoutPanel89.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel89.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel89.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel89.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel89.Size = new Size(200, 100);
            tableLayoutPanel89.TabIndex = 27;
            // 
            // tableLayoutPanel90
            // 
            tableLayoutPanel90.BackColor = Color.White;
            tableLayoutPanel90.CellBorderStyle = TableLayoutPanelCellBorderStyle.Single;
            tableLayoutPanel90.ColumnCount = 1;
            tableLayoutPanel90.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tableLayoutPanel90.Dock = DockStyle.Fill;
            tableLayoutPanel90.Location = new Point(1006, 304);
            tableLayoutPanel90.Margin = new Padding(0);
            tableLayoutPanel90.Name = "tableLayoutPanel90";
            tableLayoutPanel90.RowCount = 4;
            tableLayoutPanel90.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel90.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel90.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel90.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel90.Size = new Size(200, 100);
            tableLayoutPanel90.TabIndex = 30;
            // 
            // tableLayoutPanel91
            // 
            tableLayoutPanel91.BackColor = Color.White;
            tableLayoutPanel91.CellBorderStyle = TableLayoutPanelCellBorderStyle.Single;
            tableLayoutPanel91.ColumnCount = 1;
            tableLayoutPanel91.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tableLayoutPanel91.Dock = DockStyle.Fill;
            tableLayoutPanel91.Location = new Point(604, 405);
            tableLayoutPanel91.Margin = new Padding(0);
            tableLayoutPanel91.Name = "tableLayoutPanel91";
            tableLayoutPanel91.RowCount = 4;
            tableLayoutPanel91.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel91.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel91.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel91.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel91.Size = new Size(200, 100);
            tableLayoutPanel91.TabIndex = 26;
            // 
            // tableLayoutPanel92
            // 
            tableLayoutPanel92.BackColor = Color.White;
            tableLayoutPanel92.CellBorderStyle = TableLayoutPanelCellBorderStyle.Single;
            tableLayoutPanel92.ColumnCount = 1;
            tableLayoutPanel92.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tableLayoutPanel92.Dock = DockStyle.Fill;
            tableLayoutPanel92.Location = new Point(805, 405);
            tableLayoutPanel92.Margin = new Padding(0);
            tableLayoutPanel92.Name = "tableLayoutPanel92";
            tableLayoutPanel92.RowCount = 4;
            tableLayoutPanel92.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel92.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel92.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel92.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel92.Size = new Size(200, 100);
            tableLayoutPanel92.TabIndex = 25;
            // 
            // tableLayoutPanel93
            // 
            tableLayoutPanel93.BackColor = Color.White;
            tableLayoutPanel93.CellBorderStyle = TableLayoutPanelCellBorderStyle.Single;
            tableLayoutPanel93.ColumnCount = 1;
            tableLayoutPanel93.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tableLayoutPanel93.Dock = DockStyle.Fill;
            tableLayoutPanel93.Location = new Point(1006, 405);
            tableLayoutPanel93.Margin = new Padding(0);
            tableLayoutPanel93.Name = "tableLayoutPanel93";
            tableLayoutPanel93.RowCount = 4;
            tableLayoutPanel93.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel93.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel93.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel93.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel93.Size = new Size(200, 100);
            tableLayoutPanel93.TabIndex = 23;
            // 
            // tableLayoutPanel94
            // 
            tableLayoutPanel94.BackColor = Color.White;
            tableLayoutPanel94.CellBorderStyle = TableLayoutPanelCellBorderStyle.Single;
            tableLayoutPanel94.ColumnCount = 1;
            tableLayoutPanel94.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tableLayoutPanel94.Dock = DockStyle.Fill;
            tableLayoutPanel94.Location = new Point(1, 506);
            tableLayoutPanel94.Margin = new Padding(0);
            tableLayoutPanel94.Name = "tableLayoutPanel94";
            tableLayoutPanel94.RowCount = 4;
            tableLayoutPanel94.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel94.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel94.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel94.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel94.Size = new Size(200, 100);
            tableLayoutPanel94.TabIndex = 34;
            // 
            // tableLayoutPanel95
            // 
            tableLayoutPanel95.BackColor = Color.White;
            tableLayoutPanel95.CellBorderStyle = TableLayoutPanelCellBorderStyle.Single;
            tableLayoutPanel95.ColumnCount = 1;
            tableLayoutPanel95.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tableLayoutPanel95.Dock = DockStyle.Fill;
            tableLayoutPanel95.Location = new Point(202, 506);
            tableLayoutPanel95.Margin = new Padding(0);
            tableLayoutPanel95.Name = "tableLayoutPanel95";
            tableLayoutPanel95.RowCount = 4;
            tableLayoutPanel95.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel95.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel95.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel95.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel95.Size = new Size(200, 100);
            tableLayoutPanel95.TabIndex = 35;
            // 
            // tableLayoutPanel96
            // 
            tableLayoutPanel96.BackColor = Color.White;
            tableLayoutPanel96.CellBorderStyle = TableLayoutPanelCellBorderStyle.Single;
            tableLayoutPanel96.ColumnCount = 1;
            tableLayoutPanel96.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tableLayoutPanel96.Dock = DockStyle.Fill;
            tableLayoutPanel96.Location = new Point(604, 506);
            tableLayoutPanel96.Margin = new Padding(0);
            tableLayoutPanel96.Name = "tableLayoutPanel96";
            tableLayoutPanel96.RowCount = 4;
            tableLayoutPanel96.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel96.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel96.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel96.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel96.Size = new Size(200, 100);
            tableLayoutPanel96.TabIndex = 36;
            // 
            // tableLayoutPanel97
            // 
            tableLayoutPanel97.BackColor = Color.White;
            tableLayoutPanel97.CellBorderStyle = TableLayoutPanelCellBorderStyle.Single;
            tableLayoutPanel97.ColumnCount = 1;
            tableLayoutPanel97.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tableLayoutPanel97.Dock = DockStyle.Fill;
            tableLayoutPanel97.Location = new Point(805, 506);
            tableLayoutPanel97.Margin = new Padding(0);
            tableLayoutPanel97.Name = "tableLayoutPanel97";
            tableLayoutPanel97.RowCount = 4;
            tableLayoutPanel97.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel97.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel97.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel97.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel97.Size = new Size(200, 100);
            tableLayoutPanel97.TabIndex = 32;
            // 
            // tableLayoutPanel98
            // 
            tableLayoutPanel98.BackColor = Color.White;
            tableLayoutPanel98.CellBorderStyle = TableLayoutPanelCellBorderStyle.Single;
            tableLayoutPanel98.ColumnCount = 1;
            tableLayoutPanel98.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tableLayoutPanel98.Dock = DockStyle.Fill;
            tableLayoutPanel98.Location = new Point(1006, 506);
            tableLayoutPanel98.Margin = new Padding(0);
            tableLayoutPanel98.Name = "tableLayoutPanel98";
            tableLayoutPanel98.RowCount = 4;
            tableLayoutPanel98.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel98.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel98.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel98.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel98.Size = new Size(200, 100);
            tableLayoutPanel98.TabIndex = 31;
            // 
            // tableLayoutPanel99
            // 
            tableLayoutPanel99.BackColor = Color.White;
            tableLayoutPanel99.CellBorderStyle = TableLayoutPanelCellBorderStyle.Single;
            tableLayoutPanel99.ColumnCount = 1;
            tableLayoutPanel99.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tableLayoutPanel99.Dock = DockStyle.Fill;
            tableLayoutPanel99.Location = new Point(202, 607);
            tableLayoutPanel99.Margin = new Padding(0);
            tableLayoutPanel99.Name = "tableLayoutPanel99";
            tableLayoutPanel99.RowCount = 4;
            tableLayoutPanel99.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel99.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel99.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel99.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel99.Size = new Size(200, 100);
            tableLayoutPanel99.TabIndex = 41;
            // 
            // tableLayoutPanel100
            // 
            tableLayoutPanel100.BackColor = Color.White;
            tableLayoutPanel100.CellBorderStyle = TableLayoutPanelCellBorderStyle.Single;
            tableLayoutPanel100.ColumnCount = 1;
            tableLayoutPanel100.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tableLayoutPanel100.Dock = DockStyle.Fill;
            tableLayoutPanel100.Location = new Point(403, 506);
            tableLayoutPanel100.Margin = new Padding(0);
            tableLayoutPanel100.Name = "tableLayoutPanel100";
            tableLayoutPanel100.RowCount = 4;
            tableLayoutPanel100.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel100.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel100.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel100.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel100.Size = new Size(200, 100);
            tableLayoutPanel100.TabIndex = 39;
            // 
            // tableLayoutPanel101
            // 
            tableLayoutPanel101.BackColor = Color.White;
            tableLayoutPanel101.CellBorderStyle = TableLayoutPanelCellBorderStyle.Single;
            tableLayoutPanel101.ColumnCount = 1;
            tableLayoutPanel101.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tableLayoutPanel101.Dock = DockStyle.Fill;
            tableLayoutPanel101.Location = new Point(403, 607);
            tableLayoutPanel101.Margin = new Padding(0);
            tableLayoutPanel101.Name = "tableLayoutPanel101";
            tableLayoutPanel101.RowCount = 4;
            tableLayoutPanel101.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel101.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel101.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel101.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel101.Size = new Size(200, 100);
            tableLayoutPanel101.TabIndex = 42;
            // 
            // tableLayoutPanel102
            // 
            tableLayoutPanel102.BackColor = Color.White;
            tableLayoutPanel102.CellBorderStyle = TableLayoutPanelCellBorderStyle.Single;
            tableLayoutPanel102.ColumnCount = 1;
            tableLayoutPanel102.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tableLayoutPanel102.Dock = DockStyle.Fill;
            tableLayoutPanel102.Location = new Point(604, 607);
            tableLayoutPanel102.Margin = new Padding(0);
            tableLayoutPanel102.Name = "tableLayoutPanel102";
            tableLayoutPanel102.RowCount = 4;
            tableLayoutPanel102.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel102.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel102.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel102.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel102.Size = new Size(200, 100);
            tableLayoutPanel102.TabIndex = 38;
            // 
            // tableLayoutPanel103
            // 
            tableLayoutPanel103.BackColor = Color.White;
            tableLayoutPanel103.CellBorderStyle = TableLayoutPanelCellBorderStyle.Single;
            tableLayoutPanel103.ColumnCount = 1;
            tableLayoutPanel103.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tableLayoutPanel103.Dock = DockStyle.Fill;
            tableLayoutPanel103.Location = new Point(805, 607);
            tableLayoutPanel103.Margin = new Padding(0);
            tableLayoutPanel103.Name = "tableLayoutPanel103";
            tableLayoutPanel103.RowCount = 4;
            tableLayoutPanel103.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel103.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel103.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel103.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel103.Size = new Size(200, 100);
            tableLayoutPanel103.TabIndex = 37;
            // 
            // tableLayoutPanel104
            // 
            tableLayoutPanel104.BackColor = Color.White;
            tableLayoutPanel104.CellBorderStyle = TableLayoutPanelCellBorderStyle.Single;
            tableLayoutPanel104.ColumnCount = 1;
            tableLayoutPanel104.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tableLayoutPanel104.Dock = DockStyle.Fill;
            tableLayoutPanel104.Location = new Point(1006, 607);
            tableLayoutPanel104.Margin = new Padding(0);
            tableLayoutPanel104.Name = "tableLayoutPanel104";
            tableLayoutPanel104.RowCount = 4;
            tableLayoutPanel104.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel104.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel104.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel104.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel104.Size = new Size(200, 100);
            tableLayoutPanel104.TabIndex = 33;
            // 
            // tableLayoutPanel105
            // 
            tableLayoutPanel105.BackColor = Color.White;
            tableLayoutPanel105.CellBorderStyle = TableLayoutPanelCellBorderStyle.Single;
            tableLayoutPanel105.ColumnCount = 1;
            tableLayoutPanel105.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tableLayoutPanel105.Dock = DockStyle.Fill;
            tableLayoutPanel105.Location = new Point(1, 607);
            tableLayoutPanel105.Margin = new Padding(0);
            tableLayoutPanel105.Name = "tableLayoutPanel105";
            tableLayoutPanel105.RowCount = 4;
            tableLayoutPanel105.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel105.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel105.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel105.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel105.Size = new Size(200, 100);
            tableLayoutPanel105.TabIndex = 46;
            // 
            // tableLayoutPanel106
            // 
            tableLayoutPanel106.BackColor = Color.White;
            tableLayoutPanel106.CellBorderStyle = TableLayoutPanelCellBorderStyle.Single;
            tableLayoutPanel106.ColumnCount = 1;
            tableLayoutPanel106.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tableLayoutPanel106.Dock = DockStyle.Fill;
            tableLayoutPanel106.Location = new Point(1, 708);
            tableLayoutPanel106.Margin = new Padding(0);
            tableLayoutPanel106.Name = "tableLayoutPanel106";
            tableLayoutPanel106.RowCount = 4;
            tableLayoutPanel106.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel106.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel106.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel106.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel106.Size = new Size(200, 100);
            tableLayoutPanel106.TabIndex = 48;
            // 
            // tableLayoutPanel107
            // 
            tableLayoutPanel107.BackColor = Color.White;
            tableLayoutPanel107.CellBorderStyle = TableLayoutPanelCellBorderStyle.Single;
            tableLayoutPanel107.ColumnCount = 1;
            tableLayoutPanel107.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tableLayoutPanel107.Dock = DockStyle.Fill;
            tableLayoutPanel107.Location = new Point(202, 708);
            tableLayoutPanel107.Margin = new Padding(0);
            tableLayoutPanel107.Name = "tableLayoutPanel107";
            tableLayoutPanel107.RowCount = 4;
            tableLayoutPanel107.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel107.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel107.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel107.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel107.Size = new Size(200, 100);
            tableLayoutPanel107.TabIndex = 45;
            // 
            // tableLayoutPanel108
            // 
            tableLayoutPanel108.BackColor = Color.White;
            tableLayoutPanel108.CellBorderStyle = TableLayoutPanelCellBorderStyle.Single;
            tableLayoutPanel108.ColumnCount = 1;
            tableLayoutPanel108.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tableLayoutPanel108.Dock = DockStyle.Fill;
            tableLayoutPanel108.Location = new Point(403, 708);
            tableLayoutPanel108.Margin = new Padding(0);
            tableLayoutPanel108.Name = "tableLayoutPanel108";
            tableLayoutPanel108.RowCount = 4;
            tableLayoutPanel108.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel108.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel108.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel108.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel108.Size = new Size(200, 100);
            tableLayoutPanel108.TabIndex = 47;
            // 
            // tableLayoutPanel109
            // 
            tableLayoutPanel109.BackColor = Color.White;
            tableLayoutPanel109.CellBorderStyle = TableLayoutPanelCellBorderStyle.Single;
            tableLayoutPanel109.ColumnCount = 1;
            tableLayoutPanel109.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tableLayoutPanel109.Dock = DockStyle.Fill;
            tableLayoutPanel109.Location = new Point(604, 708);
            tableLayoutPanel109.Margin = new Padding(0);
            tableLayoutPanel109.Name = "tableLayoutPanel109";
            tableLayoutPanel109.RowCount = 4;
            tableLayoutPanel109.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel109.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel109.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel109.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel109.Size = new Size(200, 100);
            tableLayoutPanel109.TabIndex = 43;
            // 
            // tableLayoutPanel110
            // 
            tableLayoutPanel110.BackColor = Color.White;
            tableLayoutPanel110.CellBorderStyle = TableLayoutPanelCellBorderStyle.Single;
            tableLayoutPanel110.ColumnCount = 1;
            tableLayoutPanel110.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tableLayoutPanel110.Dock = DockStyle.Fill;
            tableLayoutPanel110.Location = new Point(805, 708);
            tableLayoutPanel110.Margin = new Padding(0);
            tableLayoutPanel110.Name = "tableLayoutPanel110";
            tableLayoutPanel110.RowCount = 4;
            tableLayoutPanel110.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel110.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel110.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel110.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel110.Size = new Size(200, 100);
            tableLayoutPanel110.TabIndex = 40;
            // 
            // tableLayoutPanel111
            // 
            tableLayoutPanel111.BackColor = Color.White;
            tableLayoutPanel111.CellBorderStyle = TableLayoutPanelCellBorderStyle.Single;
            tableLayoutPanel111.ColumnCount = 1;
            tableLayoutPanel111.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tableLayoutPanel111.Dock = DockStyle.Fill;
            tableLayoutPanel111.Location = new Point(1006, 708);
            tableLayoutPanel111.Margin = new Padding(0);
            tableLayoutPanel111.Name = "tableLayoutPanel111";
            tableLayoutPanel111.RowCount = 4;
            tableLayoutPanel111.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel111.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel111.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel111.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel111.Size = new Size(200, 100);
            tableLayoutPanel111.TabIndex = 44;
            // 
            // tableLayoutPanel112
            // 
            tableLayoutPanel112.BackColor = Color.White;
            tableLayoutPanel112.CellBorderStyle = TableLayoutPanelCellBorderStyle.Single;
            tableLayoutPanel112.ColumnCount = 1;
            tableLayoutPanel112.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tableLayoutPanel112.Location = new Point(408, 6);
            tableLayoutPanel112.Margin = new Padding(5);
            tableLayoutPanel112.Name = "tableLayoutPanel112";
            tableLayoutPanel112.RowCount = 4;
            tableLayoutPanel112.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel112.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel112.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel112.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel112.Size = new Size(190, 90);
            tableLayoutPanel112.TabIndex = 10;
            // 
            // tableLayoutPanel113
            // 
            tableLayoutPanel113.BackColor = Color.White;
            tableLayoutPanel113.CellBorderStyle = TableLayoutPanelCellBorderStyle.Single;
            tableLayoutPanel113.ColumnCount = 1;
            tableLayoutPanel113.Location = new Point(0, 0);
            tableLayoutPanel113.Margin = new Padding(5);
            tableLayoutPanel113.Name = "tableLayoutPanel113";
            tableLayoutPanel113.RowCount = 4;
            tableLayoutPanel113.Size = new Size(200, 100);
            tableLayoutPanel113.TabIndex = 0;
            // 
            // tableLayoutPanel114
            // 
            tableLayoutPanel114.BackColor = Color.White;
            tableLayoutPanel114.CellBorderStyle = TableLayoutPanelCellBorderStyle.Single;
            tableLayoutPanel114.ColumnCount = 1;
            tableLayoutPanel114.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tableLayoutPanel114.Controls.Add(panel9, 0, 3);
            tableLayoutPanel114.Location = new Point(0, 0);
            tableLayoutPanel114.Name = "tableLayoutPanel114";
            tableLayoutPanel114.RowCount = 4;
            tableLayoutPanel114.RowStyles.Add(new RowStyle(SizeType.Absolute, 20F));
            tableLayoutPanel114.RowStyles.Add(new RowStyle(SizeType.Absolute, 20F));
            tableLayoutPanel114.RowStyles.Add(new RowStyle(SizeType.Absolute, 20F));
            tableLayoutPanel114.RowStyles.Add(new RowStyle(SizeType.Absolute, 20F));
            tableLayoutPanel114.Size = new Size(200, 100);
            tableLayoutPanel114.TabIndex = 0;
            // 
            // panel9
            // 
            panel9.Dock = DockStyle.Fill;
            panel9.Location = new Point(1, 64);
            panel9.Margin = new Padding(0);
            panel9.Name = "panel9";
            panel9.Size = new Size(198, 35);
            panel9.TabIndex = 18;
            // 
            // panel10
            // 
            panel10.Dock = DockStyle.Fill;
            panel10.Location = new Point(1, 3);
            panel10.Margin = new Padding(0);
            panel10.Name = "panel10";
            panel10.Size = new Size(198, 23);
            panel10.TabIndex = 17;
            // 
            // tableLayoutPanel11
            // 
            tableLayoutPanel11.BackColor = Color.White;
            tableLayoutPanel11.CellBorderStyle = TableLayoutPanelCellBorderStyle.Single;
            tableLayoutPanel11.ColumnCount = 1;
            tableLayoutPanel11.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tableLayoutPanel11.Controls.Add(panel43, 0, 3);
            tableLayoutPanel11.Location = new Point(0, 0);
            tableLayoutPanel11.Name = "tableLayoutPanel11";
            tableLayoutPanel11.RowCount = 4;
            tableLayoutPanel11.Size = new Size(200, 100);
            tableLayoutPanel11.TabIndex = 0;
            // 
            // panel43
            // 
            panel43.Dock = DockStyle.Fill;
            panel43.Location = new Point(1, 4);
            panel43.Margin = new Padding(0);
            panel43.Name = "panel43";
            panel43.Size = new Size(198, 95);
            panel43.TabIndex = 18;
            // 
            // panel44
            // 
            panel44.Dock = DockStyle.Fill;
            panel44.Location = new Point(1, 3);
            panel44.Margin = new Padding(0);
            panel44.Name = "panel44";
            panel44.Size = new Size(198, 21);
            panel44.TabIndex = 17;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1187, 1359);
            Controls.Add(CalenderDateLabel);
            Controls.Add(PrevButton);
            Controls.Add(NextButton);
            Controls.Add(tableLayoutPanel59);
            Controls.Add(searchBar);
            Controls.Add(label2);
            Controls.Add(tableLayoutPanel26);
            Controls.Add(MainSchedulerTable);
            Controls.Add(label1);
            Controls.Add(button2);
            Controls.Add(button1);
            Name = "Form1";
            Text = "Form1";
            tableLayoutPanel26.ResumeLayout(false);
            tableLayoutPanel26.PerformLayout();
            MainSchedulerTable.ResumeLayout(false);
            tableLayoutPanel51.ResumeLayout(false);
            tableLayoutPanel50.ResumeLayout(false);
            tableLayoutPanel49.ResumeLayout(false);
            tableLayoutPanel48.ResumeLayout(false);
            tableLayoutPanel47.ResumeLayout(false);
            tableLayoutPanel46.ResumeLayout(false);
            tableLayoutPanel45.ResumeLayout(false);
            tableLayoutPanel44.ResumeLayout(false);
            tableLayoutPanel43.ResumeLayout(false);
            tableLayoutPanel42.ResumeLayout(false);
            tableLayoutPanel41.ResumeLayout(false);
            tableLayoutPanel40.ResumeLayout(false);
            tableLayoutPanel39.ResumeLayout(false);
            tableLayoutPanel38.ResumeLayout(false);
            tableLayoutPanel37.ResumeLayout(false);
            tableLayoutPanel36.ResumeLayout(false);
            tableLayoutPanel35.ResumeLayout(false);
            tableLayoutPanel34.ResumeLayout(false);
            tableLayoutPanel33.ResumeLayout(false);
            tableLayoutPanel32.ResumeLayout(false);
            tableLayoutPanel31.ResumeLayout(false);
            tableLayoutPanel29.ResumeLayout(false);
            tableLayoutPanel28.ResumeLayout(false);
            tableLayoutPanel27.ResumeLayout(false);
            tableLayoutPanel25.ResumeLayout(false);
            tableLayoutPanel18.ResumeLayout(false);
            tableLayoutPanel24.ResumeLayout(false);
            tableLayoutPanel23.ResumeLayout(false);
            tableLayoutPanel21.ResumeLayout(false);
            tableLayoutPanel20.ResumeLayout(false);
            tableLayoutPanel8.ResumeLayout(false);
            tableLayoutPanel7.ResumeLayout(false);
            tableLayoutPanel6.ResumeLayout(false);
            tableLayoutPanel9.ResumeLayout(false);
            tableLayoutPanel5.ResumeLayout(false);
            tableLayoutPanel116.ResumeLayout(false);
            tableLayoutPanel2.ResumeLayout(false);
            tableLayoutPanel4.ResumeLayout(false);
            tableLayoutPanel10.ResumeLayout(false);
            tableLayoutPanel12.ResumeLayout(false);
            tableLayoutPanel13.ResumeLayout(false);
            tableLayoutPanel14.ResumeLayout(false);
            tableLayoutPanel15.ResumeLayout(false);
            tableLayoutPanel16.ResumeLayout(false);
            tableLayoutPanel19.ResumeLayout(false);
            tableLayoutPanel59.ResumeLayout(false);
            tableLayoutPanel59.PerformLayout();
            tableLayoutPanel22.ResumeLayout(false);
            tableLayoutPanel61.ResumeLayout(false);
            tableLayoutPanel114.ResumeLayout(false);
            tableLayoutPanel11.ResumeLayout(false);
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Button button1;
        private Button button2;
        private Label label1;
        private TableLayoutPanel tableLayoutPanel26;
        private TableLayoutPanel MainSchedulerTable;
        private TableLayoutPanel tableLayoutPanel5;
        private Label label2;
        private TextBox searchBar;
        private TableLayoutPanel tableLayoutPanel17;
        private TableLayoutPanel tableLayoutPanel30;
        private Label label3;
        private TableLayoutPanel tableLayoutPanel59;
        private Label label8;
        private Label label7;
        private Label label6;
        private Label label5;
        private Label label4;
        private Label label17;
        private Label label16;
        private Label label15;
        private Label label14;
        private Label label13;
        private Label label12;
        private Label label11;
        private Label label10;
        private Label label9;
        private Button NextButton;
        private Button PrevButton;
        private Label CalenderDateLabel;
        private TableLayoutPanel tableLayoutPanel3;
        private Panel panel4;
        private Panel panel3;
        private Panel panel2;
        private Panel panel1;
        private TableLayoutPanel tableLayoutPanel22;
        private TableLayoutPanel tableLayoutPanel61;
        private Panel panel5;
        private Panel panel6;
        private Panel panel7;
        private Panel panel8;
        private TableLayoutPanel tableLayoutPanel62;
        private TableLayoutPanel tableLayoutPanel63;
        private TableLayoutPanel tableLayoutPanel64;
        private TableLayoutPanel tableLayoutPanel65;
        private TableLayoutPanel tableLayoutPanel66;
        private TableLayoutPanel tableLayoutPanel67;
        private TableLayoutPanel tableLayoutPanel68;
        private TableLayoutPanel tableLayoutPanel69;
        private TableLayoutPanel tableLayoutPanel70;
        private TableLayoutPanel tableLayoutPanel71;
        private TableLayoutPanel tableLayoutPanel72;
        private TableLayoutPanel tableLayoutPanel73;
        private TableLayoutPanel tableLayoutPanel74;
        private TableLayoutPanel tableLayoutPanel75;
        private TableLayoutPanel tableLayoutPanel76;
        private TableLayoutPanel tableLayoutPanel77;
        private TableLayoutPanel tableLayoutPanel78;
        private TableLayoutPanel tableLayoutPanel79;
        private TableLayoutPanel tableLayoutPanel80;
        private TableLayoutPanel tableLayoutPanel81;
        private TableLayoutPanel tableLayoutPanel82;
        private TableLayoutPanel tableLayoutPanel83;
        private TableLayoutPanel tableLayoutPanel84;
        private TableLayoutPanel tableLayoutPanel85;
        private TableLayoutPanel tableLayoutPanel86;
        private TableLayoutPanel tableLayoutPanel87;
        private TableLayoutPanel tableLayoutPanel88;
        private TableLayoutPanel tableLayoutPanel89;
        private TableLayoutPanel tableLayoutPanel90;
        private TableLayoutPanel tableLayoutPanel91;
        private TableLayoutPanel tableLayoutPanel92;
        private TableLayoutPanel tableLayoutPanel93;
        private TableLayoutPanel tableLayoutPanel94;
        private TableLayoutPanel tableLayoutPanel95;
        private TableLayoutPanel tableLayoutPanel96;
        private TableLayoutPanel tableLayoutPanel97;
        private TableLayoutPanel tableLayoutPanel98;
        private TableLayoutPanel tableLayoutPanel99;
        private TableLayoutPanel tableLayoutPanel100;
        private TableLayoutPanel tableLayoutPanel101;
        private TableLayoutPanel tableLayoutPanel102;
        private TableLayoutPanel tableLayoutPanel103;
        private TableLayoutPanel tableLayoutPanel104;
        private TableLayoutPanel tableLayoutPanel105;
        private TableLayoutPanel tableLayoutPanel106;
        private TableLayoutPanel tableLayoutPanel107;
        private TableLayoutPanel tableLayoutPanel108;
        private TableLayoutPanel tableLayoutPanel109;
        private TableLayoutPanel tableLayoutPanel110;
        private TableLayoutPanel tableLayoutPanel111;
        private TableLayoutPanel tableLayoutPanel112;
        private TableLayoutPanel tableLayoutPanel113;
        private TableLayoutPanel tableLayoutPanel114;
        private Panel panel9;
        private Panel panel10;
        private TableLayoutPanel tableLayoutPanel116;
        private Panel panel15;
        private Panel panel16;
        private Panel panel17;
        private Panel panel18;
        private TableLayoutPanel tableLayoutPanel9;
        private Panel panel19;
        private Panel panel20;
        private Panel panel21;
        private Panel panel22;
        private TableLayoutPanel tableLayoutPanel8;
        private Panel panel35;
        private Panel panel36;
        private Panel panel37;
        private Panel panel38;
        private TableLayoutPanel tableLayoutPanel7;
        private Panel panel31;
        private Panel panel32;
        private Panel panel33;
        private Panel panel34;
        private TableLayoutPanel tableLayoutPanel6;
        private Panel panel27;
        private Panel panel28;
        private Panel panel29;
        private Panel panel30;
        private TableLayoutPanel tableLayoutPanel2;
        private Panel panel11;
        private Panel panel12;
        private Panel panel13;
        private Panel panel14;
        private TableLayoutPanel tableLayoutPanel4;
        private Panel panel23;
        private Panel panel24;
        private Panel panel25;
        private Panel panel26;
        private TableLayoutPanel tableLayoutPanel10;
        private Panel panel39;
        private Panel panel40;
        private Panel panel41;
        private Panel panel42;
        private TableLayoutPanel tableLayoutPanel12;
        private Panel panel45;
        private Panel panel46;
        private Panel panel47;
        private Panel panel48;
        private TableLayoutPanel tableLayoutPanel13;
        private Panel panel49;
        private Panel panel50;
        private Panel panel51;
        private Panel panel52;
        private TableLayoutPanel tableLayoutPanel14;
        private Panel panel53;
        private Panel panel54;
        private Panel panel55;
        private Panel panel56;
        private TableLayoutPanel tableLayoutPanel15;
        private Panel panel57;
        private Panel panel58;
        private Panel panel59;
        private Panel panel60;
        private TableLayoutPanel tableLayoutPanel16;
        private Panel panel61;
        private Panel panel62;
        private Panel panel63;
        private Panel panel64;
        private TableLayoutPanel tableLayoutPanel19;
        private Panel panel69;
        private Panel panel70;
        private Panel panel71;
        private Panel panel72;
        private TableLayoutPanel tableLayoutPanel11;
        private Panel panel43;
        private Panel panel44;
        private TableLayoutPanel tableLayoutPanel34;
        private Panel panel117;
        private Panel panel118;
        private Panel panel119;
        private Panel panel120;
        private TableLayoutPanel tableLayoutPanel33;
        private Panel panel113;
        private Panel panel114;
        private Panel panel115;
        private Panel panel116;
        private TableLayoutPanel tableLayoutPanel32;
        private Panel panel109;
        private Panel panel110;
        private Panel panel111;
        private Panel panel112;
        private TableLayoutPanel tableLayoutPanel31;
        private Panel panel105;
        private Panel panel106;
        private Panel panel107;
        private Panel panel108;
        private TableLayoutPanel tableLayoutPanel29;
        private Panel panel101;
        private Panel panel102;
        private Panel panel103;
        private Panel panel104;
        private TableLayoutPanel tableLayoutPanel28;
        private Panel panel97;
        private Panel panel98;
        private Panel panel99;
        private Panel panel100;
        private TableLayoutPanel tableLayoutPanel27;
        private Panel panel93;
        private Panel panel94;
        private Panel panel95;
        private Panel panel96;
        private TableLayoutPanel tableLayoutPanel25;
        private Panel panel89;
        private Panel panel90;
        private Panel panel91;
        private Panel panel92;
        private TableLayoutPanel tableLayoutPanel18;
        private Panel panel65;
        private Panel panel66;
        private Panel panel67;
        private Panel panel68;
        private TableLayoutPanel tableLayoutPanel24;
        private Panel panel85;
        private Panel panel86;
        private Panel panel87;
        private Panel panel88;
        private TableLayoutPanel tableLayoutPanel23;
        private Panel panel81;
        private Panel panel82;
        private Panel panel83;
        private Panel panel84;
        private TableLayoutPanel tableLayoutPanel21;
        private Panel panel77;
        private Panel panel78;
        private Panel panel79;
        private Panel panel80;
        private TableLayoutPanel tableLayoutPanel20;
        private Panel panel73;
        private Panel panel74;
        private Panel panel75;
        private Panel panel76;
        private TableLayoutPanel tableLayoutPanel49;
        private Panel panel177;
        private Panel panel178;
        private Panel panel179;
        private Panel panel180;
        private TableLayoutPanel tableLayoutPanel48;
        private Panel panel173;
        private Panel panel174;
        private Panel panel175;
        private Panel panel176;
        private TableLayoutPanel tableLayoutPanel47;
        private Panel panel169;
        private Panel panel170;
        private Panel panel171;
        private Panel panel172;
        private TableLayoutPanel tableLayoutPanel46;
        private Panel panel165;
        private Panel panel166;
        private Panel panel167;
        private Panel panel168;
        private TableLayoutPanel tableLayoutPanel45;
        private Panel panel161;
        private Panel panel162;
        private Panel panel163;
        private Panel panel164;
        private TableLayoutPanel tableLayoutPanel44;
        private Panel panel157;
        private Panel panel158;
        private Panel panel159;
        private Panel panel160;
        private TableLayoutPanel tableLayoutPanel43;
        private Panel panel153;
        private Panel panel154;
        private Panel panel155;
        private Panel panel156;
        private TableLayoutPanel tableLayoutPanel42;
        private Panel panel149;
        private Panel panel150;
        private Panel panel151;
        private Panel panel152;
        private TableLayoutPanel tableLayoutPanel41;
        private Panel panel145;
        private Panel panel146;
        private Panel panel147;
        private Panel panel148;
        private TableLayoutPanel tableLayoutPanel40;
        private Panel panel141;
        private Panel panel142;
        private Panel panel143;
        private Panel panel144;
        private TableLayoutPanel tableLayoutPanel39;
        private Panel panel137;
        private Panel panel138;
        private Panel panel139;
        private Panel panel140;
        private TableLayoutPanel tableLayoutPanel38;
        private Panel panel133;
        private Panel panel134;
        private Panel panel135;
        private Panel panel136;
        private TableLayoutPanel tableLayoutPanel37;
        private Panel panel129;
        private Panel panel130;
        private Panel panel131;
        private Panel panel132;
        private TableLayoutPanel tableLayoutPanel36;
        private Panel panel125;
        private Panel panel126;
        private Panel panel127;
        private Panel panel128;
        private TableLayoutPanel tableLayoutPanel35;
        private Panel panel121;
        private Panel panel122;
        private Panel panel123;
        private Panel panel124;
        private TableLayoutPanel tableLayoutPanel51;
        private Panel panel185;
        private Panel panel186;
        private Panel panel187;
        private Panel panel188;
        private TableLayoutPanel tableLayoutPanel50;
        private Panel panel181;
        private Panel panel182;
        private Panel panel183;
        private Panel panel184;
    }
}
